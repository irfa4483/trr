const path = require('path');
const fs = require('fs');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const bcrypt = require('bcrypt');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const cors = require('cors');
const { generateToken, createMethodHash } = require('./src/lib/crypto');
const { sanitize, stripControlChars, hasUnsafeText } = require('./src/lib/sanitize');
const {
  PORT,
  CLIENT_ORIGIN,
  SESSION_SECRET,
  DB_PATH,
  DEFAULT_PLAN,
  MAX_LOGIN_HISTORY,
  MAX_ONGOING_RUNS,
  DEFAULT_BALANCE,
  DELETE_DELAY_MS,
  FALLBACK_METHOD_MAX_SECONDS,
  FALLBACK_USER_MAX_SECONDS,
  DEFAULT_NEWS_TITLE,
  DEFAULT_NEWS_MESSAGE,
  DEFAULT_NEWS_AUTHOR,
  FRONTEND_DIST,
  USERNAME_REGEX,
  CAPTCHA_REGEX,
  METHOD_HASH_REGEX,
  METHOD_NAME_REGEX,
  METHOD_LABEL_REGEX,
  TARGET_REGEX,
  DURATION_REGEX,
  RUN_TARGET_MAX,
  RUN_DURATION_MAX,
  JOB_ID_REGEX,
  TOKEN_REGEX,
} = require('./src/config');
const {
  run,
  get,
  all,
  initDb,
  addColumnIfMissing,
  getDefaultUserMaxSeconds,
  getDefaultMethodMaxSeconds,
  generateUniqueToken,
  generateUniqueUniqCode,
} = require('./src/db');

const app = express();
app.disable('x-powered-by');
const hasFrontendDist = fs.existsSync(FRONTEND_DIST);
if (!process.env.SESSION_SECRET) {
  console.warn('SESSION_SECRET is not set. Use a strong secret in production.');
}

const dbDir = path.dirname(DB_PATH);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}
const ensureMethodColumns = async () => {
  await addColumnIfMissing(
    'methods',
    'display_name',
    'TEXT NOT NULL DEFAULT ""'
  );
  await addColumnIfMissing(
    'methods',
    'access_level',
    "TEXT NOT NULL DEFAULT 'Basic'"
  );
  await addColumnIfMissing(
    'methods',
    'api_access',
    'INTEGER NOT NULL DEFAULT 0'
  );
  await addColumnIfMissing(
    'methods',
    'layer',
    "TEXT NOT NULL DEFAULT 'Layer 7'"
  );
  await run(
    'UPDATE methods SET display_name = name WHERE display_name IS NULL OR display_name = ""'
  );
};

const startup = initDb()
  .then(async () => {
    await ensureMethodColumns();
    await cleanupDefaultMethods();
    await migrateUserPlans();
  })
  .catch((error) => {
    console.error('DB init error:', error);
  });

const ensureSessionToken = (req, forceNew = false) => {
  if (!req.session) return '';
  const current = sanitize(req.session.sessionToken || '');
  if (forceNew || !TOKEN_REGEX.test(current)) {
    req.session.sessionToken = generateToken();
  }
  return req.session.sessionToken;
};
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const parseDurationSeconds = (value) => {
  const text = sanitize(value).toLowerCase();
  if (!text) return 0;
  const match = text.match(/(\d+(?:\.\d+)?)/);
  if (!match) return 0;
  const number = Number(match[1]);
  if (!Number.isFinite(number) || number < 0) return 0;

  const hasHours =
    /\bhour\b|\bhours\b|\bhr\b|\bhrs\b|\d+\s*h\b|\d+h\b/.test(text);
  const hasMinutes =
    /\bmin\b|\bmins\b|\bminute\b|\bminutes\b|\d+\s*m\b|\d+m\b/.test(text);
  const hasSeconds =
    /\bsec\b|\bsecs\b|\bsecond\b|\bseconds\b|\d+\s*s\b|\d+s\b/.test(text);

  let seconds = number;
  if (hasHours) {
    seconds = number * 3600;
  } else if (hasMinutes) {
    seconds = number * 60;
  } else if (hasSeconds) {
    seconds = number;
  }
  return Math.max(0, Math.round(seconds));
};

const getActiveRunsCount = async () => {
  const rows = await all(
    'SELECT duration, duration_seconds, created_at, engine FROM ongoing_runs'
  );
  const now = Date.now();
  let activeRuns = 0;
  for (const row of rows) {
    const storedSeconds = Number(row.duration_seconds);
    const durationSeconds =
      Number.isFinite(storedSeconds) && storedSeconds > 0
        ? storedSeconds
        : parseDurationSeconds(row.duration);
    if (!durationSeconds) continue;
    const createdAtMs = Date.parse(row.created_at);
    const safeCreatedAt = Number.isFinite(createdAtMs) ? createdAtMs : now;
    if (safeCreatedAt + durationSeconds * 1000 > now) {
      activeRuns += Math.max(1, Math.trunc(Number(row.engine) || 1));
    }
  }
  return activeRuns;
};

const getUserActiveConcurrency = async (userId) => {
  if (!userId) return 0;
  const rows = await all(
    `SELECT job_id, duration, duration_seconds, created_at, engine
     FROM ongoing_runs
     WHERE user_id = ?`,
    [userId]
  );
  const now = Date.now();
  const expiredIds = [];
  let activeConc = 0;

  for (const row of rows) {
    const storedSeconds = Number(row.duration_seconds);
    const durationSeconds =
      Number.isFinite(storedSeconds) && storedSeconds > 0
        ? storedSeconds
        : parseDurationSeconds(row.duration);
    if (!durationSeconds) {
      expiredIds.push(row.job_id);
      continue;
    }
    if (
      (!Number.isFinite(storedSeconds) || storedSeconds <= 0) &&
      durationSeconds > 0
    ) {
      run('UPDATE ongoing_runs SET duration_seconds = ? WHERE job_id = ?', [
        durationSeconds,
        row.job_id,
      ]).catch((error) => console.error(error));
    }
    const createdAtMs = Date.parse(row.created_at);
    const safeCreatedAt = Number.isFinite(createdAtMs) ? createdAtMs : now;
    const elapsedSeconds = Math.max(
      0,
      Math.floor((now - safeCreatedAt) / 1000)
    );
    const remainingSeconds = Math.max(0, durationSeconds - elapsedSeconds);
    if (remainingSeconds <= 0) {
      expiredIds.push(row.job_id);
      continue;
    }
    const engine = Math.max(0, Math.trunc(Number(row.engine) || 0));
    activeConc += engine;
  }

  if (expiredIds.length) {
    const placeholders = expiredIds.map(() => '?').join(',');
    await run(
      `DELETE FROM ongoing_runs WHERE job_id IN (${placeholders})`,
      expiredIds
    );
  }

  return activeConc;
};

const isStrongPassword = (password) => {
  if (password.length < 12 || password.length > 72) {
    return false;
  }
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSymbol = /[^A-Za-z0-9]/.test(password);
  return hasUpper && hasLower && hasNumber && hasSymbol;
};

const normalizeBalance = (value) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0) {
    return DEFAULT_BALANCE;
  }
  return Math.trunc(parsed);
};

const normalizeAdminFlag = (value) => {
  if (typeof value === 'boolean') return value;
  if (typeof value === 'number') return value === 1;
  if (typeof value === 'string') {
    const normalized = value.trim().toLowerCase();
    return ['1', 'true', 'yes', 'on'].includes(normalized);
  }
  return false;
};

const PLAN_ACCESS_LEVELS = new Set(['Basic', 'Premium']);

// Function to record usage history
const recordUsageHistory = async () => {
  try {
    const row = await get('SELECT SUM(engine) as totalTargets FROM ongoing_runs');
    const activeTargets = Number(row?.totalTargets) || 0;

    const serverRows = await all('SELECT SUM(engine) as totalEngine FROM servers WHERE status = "Online"');
    const totalEngine = Number(serverRows[0]?.totalEngine) || 0;

    await run(
      'INSERT INTO usage_history (total_targets, total_engine, timestamp) VALUES (?, ?, ?)',
      [activeTargets, totalEngine, new Date().toISOString()]
    );

    // Keep only last 24 hours (300 records)
    await run('DELETE FROM usage_history WHERE id NOT IN (SELECT id FROM usage_history ORDER BY id DESC LIMIT 300)');
  } catch (e) {
    console.error('Error recording usage history:', e);
  }
};

// Seed dummy history if empty
const seedUsageHistory = async () => {
  try {
    const row = await get('SELECT COUNT(*) as total FROM usage_history');
    if (row && row.total === 0) {
      const now = new Date();
      for (let i = 24; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 5 * 60 * 1000);
        const targets = Math.floor(Math.random() * 40) + 10;
        const engine = 100;
        await run('INSERT INTO usage_history (total_targets, total_engine, timestamp) VALUES (?, ?, ?)', [targets, engine, time.toISOString()]);
      }
    }
  } catch (e) { }
};

seedUsageHistory().then(() => {
  setInterval(recordUsageHistory, 5 * 60 * 1000);
  recordUsageHistory();
});

const normalizePlanId = (value) => {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) return null;
  return parsed;
};

const normalizePlanNumber = (value, fallback = 0, min = 0, max = null) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return fallback;
  const rounded = Math.trunc(parsed);
  if (rounded < min) return fallback;
  if (typeof max === 'number' && rounded > max) return max;
  return rounded;
};

const normalizePlanText = (value, maxLength = 64) => {
  const raw = stripControlChars(String(value || '')).trim();
  if (!raw || hasUnsafeText(raw)) return '';
  return raw.slice(0, maxLength);
};

const normalizePlanAccess = (value) => {
  const raw = normalizePlanText(value, 16);
  if (!raw) return 'Basic';
  const normalized =
    raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
  return PLAN_ACCESS_LEVELS.has(normalized) ? normalized : 'Basic';
};

const normalizeMethodText = (value, maxLength = 64) => {
  const raw = stripControlChars(String(value || '')).trim();
  if (!raw || hasUnsafeText(raw)) return '';
  const trimmed = raw.slice(0, maxLength);
  if (!METHOD_LABEL_REGEX.test(trimmed)) return '';
  return trimmed;
};

const normalizeMethodNameInput = (value) => normalizeMethodText(value, 64);

const normalizeMethodDisplay = (value) => normalizeMethodText(value, 64);

const normalizeMethodLabelForApi = (value) =>
  normalizeMethodText(value, 64) || sanitize(value).slice(0, 64);

const normalizeRunTarget = (value) => {
  const raw = stripControlChars(String(value || '')).trim();
  if (!raw || hasUnsafeText(raw)) return '';
  const trimmed = raw.slice(0, RUN_TARGET_MAX);
  if (!TARGET_REGEX.test(trimmed)) return '';
  return trimmed;
};

const normalizeRunDuration = (value) => {
  const raw = stripControlChars(String(value || '')).trim();
  if (!raw || hasUnsafeText(raw)) return '';
  const trimmed = raw.slice(0, RUN_DURATION_MAX);
  if (!DURATION_REGEX.test(trimmed)) return '';
  return trimmed;
};

const normalizeNewsId = (value) => {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0) return null;
  return parsed;
};

const stripControlCharsPreserveNewlines = (value) =>
  value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '');

const normalizeNewsText = (value, maxLength = 160) => {
  const raw = stripControlChars(String(value || '')).trim();
  if (!raw || hasUnsafeText(raw)) return '';
  return raw.slice(0, maxLength);
};

const normalizeNewsMessage = (value, maxLength = 320) => {
  const raw = stripControlCharsPreserveNewlines(String(value || ''));
  const trimmed = raw.trim().replace(/\r\n/g, '\n');
  if (!trimmed || hasUnsafeText(trimmed)) return '';
  return trimmed.slice(0, maxLength);
};

const normalizeServerText = (value, maxLength = 64) => {
  const raw = stripControlChars(String(value || '')).trim();
  if (!raw || hasUnsafeText(raw)) return '';
  return raw.slice(0, maxLength);
};

const normalizeServerUrl = (value) => {
  const raw = stripControlChars(String(value || '')).trim();
  if (!raw || hasUnsafeText(raw)) return '';
  if (!/^https?:\/\//i.test(raw)) return '';
  try {
    new URL(raw);
  } catch (error) {
    return '';
  }
  return raw.slice(0, 200);
};

const normalizeServerNumber = (value, min = 0, max = null) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return null;
  const rounded = Math.trunc(parsed);
  if (rounded < min) return null;
  if (typeof max === 'number' && rounded > max) return max;
  return rounded;
};

const SERVER_STATUSES = new Set(['Online', 'Offline', 'Maintenance']);

const normalizeServerStatus = (value) => {
  const raw = normalizeServerText(value, 24);
  if (!raw) return 'Offline';
  const normalized =
    raw.charAt(0).toUpperCase() + raw.slice(1).toLowerCase();
  return SERVER_STATUSES.has(normalized) ? normalized : 'Offline';
};

const normalizeServerMethods = (value) => {
  let list = [];
  if (Array.isArray(value)) {
    list = value;
  } else if (typeof value === 'string') {
    const trimmed = value.trim();
    if (trimmed.startsWith('[')) {
      try {
        const parsed = JSON.parse(trimmed);
        if (Array.isArray(parsed)) {
          list = parsed;
        }
      } catch (error) {
        list = [];
      }
    } else if (trimmed) {
      list = trimmed.split(',').map((entry) => entry.trim());
    }
  }
  const seen = new Set();
  const output = [];
  let hasAll = false;
  list.forEach((entry) => {
    const token = stripControlChars(String(entry || '')).trim();
    if (!token) return;
    const upper = token.toUpperCase();
    if (upper === 'ALL' || upper === '*') {
      hasAll = true;
      return;
    }
    if (!METHOD_HASH_REGEX.test(token)) {
      return;
    }
    const normalized = token.toLowerCase();
    if (seen.has(normalized)) return;
    seen.add(normalized);
    output.push(normalized);
  });
  if (hasAll) return ['ALL'];
  return output;
};

const parseServerMethods = (value) => {
  if (Array.isArray(value)) return value;
  if (!value) return [];
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) {
        return parsed.filter((entry) => typeof entry === 'string');
      }
    } catch (error) {
      return [];
    }
  }
  return [];
};

const parseServerIds = (value) => {
  if (!value) return [];
  let list = [];
  if (Array.isArray(value)) {
    list = value;
  } else if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      if (Array.isArray(parsed)) {
        list = parsed;
      }
    } catch (error) {
      list = [];
    }
  }
  const ids = list
    .map((entry) => Math.trunc(Number(entry)))
    .filter((id) => Number.isInteger(id) && id > 0);
  return Array.from(new Set(ids));
};

const serverSupportsMethod = (server, methodHash) => {
  if (!server || !methodHash) return false;
  const methods = Array.isArray(server.methods) ? server.methods : [];
  const normalized = methodHash.toLowerCase();
  return methods.some((entry) => {
    if (typeof entry !== 'string') return false;
    const upper = entry.toUpperCase();
    if (upper === 'ALL' || upper === '*') return true;
    return entry.toLowerCase() === normalized;
  });
};

const serverAllowsDuration = (server, durationSeconds) => {
  if (!server) return false;
  const maxDuration = normalizePlanNumber(server.durationMax, 0, 0);
  if (maxDuration <= 0) return true;
  return durationSeconds <= maxDuration;
};

const buildServerUrl = (template, { target, port, durationSeconds, methodLabel }) => {
  if (!template) return '';
  const replaced = String(template)
    .replace(/\[(host|url|target)\]/gi, target)
    .replace(/\[(port)\]/gi, String(port || 0))
    .replace(/\[(time|duration)\]/gi, String(durationSeconds))
    .replace(/\[(method)\]/gi, methodLabel);
  try {
    const url = new URL(replaced);
    return url.toString();
  } catch (error) {
    return '';
  }
};

const sendServerRequest = (url, timeoutMs = 10000) =>
  new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(url);
    } catch (error) {
      reject(error);
      return;
    }
    const client = parsed.protocol === 'https:' ? https : http;
    const req = client.request(parsed, { method: 'GET' }, (res) => {
      res.resume();
      res.on('end', () => {
        resolve({ statusCode: res.statusCode || 0 });
      });
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error('timeout'));
    });
    req.end();
  });

const getServerOccupancyMap = async () => {
  const occupancyMap = {};
  try {
    const rows = await all(
      'SELECT duration, duration_seconds, created_at, engine, servers FROM ongoing_runs'
    );
    const now = Date.now();
    for (const row of rows) {
      const storedSeconds = Number(row.duration_seconds);
      const durationSeconds =
        Number.isFinite(storedSeconds) && storedSeconds > 0
          ? storedSeconds
          : parseDurationSeconds(row.duration);
      if (!durationSeconds) continue;

      const createdAtMs = Date.parse(row.created_at);
      const safeCreatedAt = Number.isFinite(createdAtMs) ? createdAtMs : now;

      if (safeCreatedAt + durationSeconds * 1000 > now) {
        const serverList = JSON.parse(row.servers || '[]');
        const engine = Number(row.engine) || 0;
        serverList.forEach((srvId) => {
          occupancyMap[srvId] = (occupancyMap[srvId] || 0) + engine;
        });
      }
    }
  } catch (error) {
    console.error('getServerOccupancyMap error:', error);
  }
  return occupancyMap;
};

const allocateServerEngines = (servers, engineRequested, occupancyMap = {}) => {
  const assignments = [];
  // Broadcast mode: Every server gets the requested slots, capped by its remaining capacity.
  for (const server of servers) {
    const totalCapacity = normalizePlanNumber(server.engine, 1, 1);
    const currentOccupancy = occupancyMap[server.id] || 0;
    const remainingCapacity = Math.max(0, totalCapacity - currentOccupancy);

    // Give this server the requested slots, but don't exceed what's left on IT.
    const count = Math.min(engineRequested, remainingCapacity);
    if (count > 0) {
      assignments.push({ server, count });
    }
  }
  // Return assignments. Since it's broadcast, "remaining" isn't a global counter,
  // but we return it as 0 if we assigned to AT LEAST one server, or engineRequested if none.
  return { assignments, remaining: assignments.length > 0 ? 0 : engineRequested };
};

const requireAdmin = async (req, res) => {
  if (!req.session?.userId) {
    res.status(401).json({ error: 'unauthorized' });
    return false;
  }
  const row = await get('SELECT is_admin FROM users WHERE id = ?', [
    req.session.userId,
  ]);
  if (!row || Number(row.is_admin) !== 1) {
    res.status(403).json({ error: 'forbidden' });
    return false;
  }
  return true;
};

const getClientMeta = (req) => {
  const forwarded = req.headers['x-forwarded-for'];
  let ipAddress = 'Unknown';
  if (typeof forwarded === 'string' && forwarded.length > 0) {
    ipAddress = forwarded.split(',')[0].trim();
  } else if (Array.isArray(forwarded) && forwarded.length > 0) {
    ipAddress = forwarded[0];
  } else if (req.ip) {
    ipAddress = req.ip;
  } else if (req.connection?.remoteAddress) {
    ipAddress = req.connection.remoteAddress;
  }

  const userAgent = sanitize(req.get('user-agent') || 'Unknown').slice(0, 255);
  const rawLocale = sanitize(req.get('accept-language') || 'Unknown');
  const locale = rawLocale.split(',')[0]?.trim() || 'Unknown';

  return { ipAddress, userAgent, locale };
};

const parsePlanDate = (value) => {
  if (!value) return null;
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return null;
  return parsed;
};

const mapPlanRow = (row) => {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    display: row.display_name,
    time: normalizePlanNumber(row.time_seconds, 0, 0),
    conc: normalizePlanNumber(row.conc, 1, 1),
    apiAccess: Number(row.api_access) === 1,
    expired: normalizePlanNumber(row.expired_days, 0, 0),
    stock: normalizePlanNumber(row.stock, 0, 0),
    access: normalizePlanAccess(row.access_level),
    private: Number(row.is_private) === 1,
    price: normalizePlanNumber(row.price, 0, 0),
    cooldown: normalizePlanNumber(row.cooldown_seconds, 0, 0),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
};

const mapPlanSummary = (plan) => {
  if (!plan) return null;
  return {
    id: plan.id,
    name: plan.name,
    display: plan.display,
    time: plan.time,
    conc: plan.conc,
    apiAccess: plan.apiAccess,
    expired: plan.expired,
    access: plan.access,
  };
};

const mapMethodRow = (row) => {
  if (!row) return null;
  const display = normalizeMethodDisplay(row.display_name) || row.name;
  return {
    id: row.id,
    hash: row.hash,
    name: row.name,
    display,
    description: row.description || '',
    maxDuration: normalizePlanNumber(row.max_duration_seconds, 0, 0),
    access: normalizePlanAccess(row.access_level),
    apiAccess: Number(row.api_access) === 1,
    layer: row.layer || 'Layer 7',
    enabled: Number(row.enabled) === 1,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
};

const mapServerRow = (row) => {
  if (!row) return null;
  const methods = parseServerMethods(row.methods);
  return {
    id: row.id,
    name: row.name,
    apiUrl: row.api_url,
    durationMax: normalizePlanNumber(row.duration_max, 0, 0),
    engine: normalizePlanNumber(row.engine, 1, 1),
    methods,
    status: normalizeServerStatus(row.status),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
};

const clearPlanCache = () => { };

const METHOD_DEFAULT_CLEANUP_KEY = 'cleanup_default_methods_v1';

const cleanupDefaultMethods = async () => {
  const marker = await get('SELECT value FROM settings WHERE key = ?', [
    METHOD_DEFAULT_CLEANUP_KEY,
  ]);
  if (marker?.value === '1') {
    return;
  }
  const rows = await all('SELECT id, name FROM methods');
  const ids = rows
    .filter(
      (row) =>
        String(row?.name || '').trim().toUpperCase() === 'HTTP-CONNECT'
    )
    .map((row) => row.id);
  if (ids.length) {
    const placeholders = ids.map(() => '?').join(',');
    await run(`DELETE FROM methods WHERE id IN (${placeholders})`, ids);
  }
  const nowIso = new Date().toISOString();
  await run(
    'INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
    [METHOD_DEFAULT_CLEANUP_KEY, '1', nowIso]
  );
};

const fetchPlanById = async (planId) => {
  if (!planId) return null;
  const row = await get('SELECT * FROM plans WHERE id = ?', [planId]);
  return mapPlanRow(row);
};

const ensurePlanFromLegacyName = async (legacyName) => {
  const normalized = normalizePlanText(legacyName, 64);
  if (!normalized || normalized === DEFAULT_PLAN) return null;
  const existing = await get(
    'SELECT * FROM plans WHERE name = ? OR display_name = ?',
    [normalized, normalized]
  );
  if (existing) return mapPlanRow(existing);
  const nowIso = new Date().toISOString();
  await run(
    `INSERT INTO plans
     (name, display_name, time_seconds, conc, api_access, expired_days, stock, access_level, is_private, price, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      normalized,
      normalized,
      FALLBACK_USER_MAX_SECONDS,
      1,
      0,
      0,
      0,
      'Basic',
      1,
      0,
      nowIso,
      nowIso,
    ]
  );
  const created = await get('SELECT * FROM plans WHERE name = ?', [
    normalized,
  ]);
  return mapPlanRow(created);
};

const resolveUserPlan = async (userRow) => {
  if (!userRow) return null;
  const rawPlan = userRow.plan || '';
  let planId = normalizePlanId(rawPlan);
  let plan = null;

  if (planId) {
    plan = await fetchPlanById(planId);
  }

  if (!plan) {
    const legacyPlan = normalizePlanText(rawPlan, 64);
    const legacyPlanRow = legacyPlan
      ? await ensurePlanFromLegacyName(legacyPlan)
      : null;
    plan = legacyPlanRow || null;
    planId = plan?.id || null;
    if (plan) {
      await run(
        'UPDATE users SET plan = ?, plan_started_at = NULL, plan_expires_at = NULL WHERE id = ?',
        [planId, userRow.id]
      );
    } else if (rawPlan) {
      await run(
        'UPDATE users SET plan = ?, plan_started_at = NULL, plan_expires_at = NULL WHERE id = ?',
        ['', userRow.id]
      );
    }
  }

  const expiresAt = parsePlanDate(userRow.plan_expires_at);
  let planStartedAt = userRow.plan_started_at || null;
  let planExpiresAt = userRow.plan_expires_at || null;
  if (expiresAt && expiresAt.getTime() <= Date.now()) {
    await run(
      'UPDATE users SET plan = ?, plan_started_at = NULL, plan_expires_at = NULL WHERE id = ?',
      ['', userRow.id]
    );
    planId = null;
    plan = null;
    planStartedAt = null;
    planExpiresAt = null;
  }

  if (!planId) {
    if (planStartedAt || planExpiresAt) {
      await run(
        'UPDATE users SET plan_started_at = NULL, plan_expires_at = NULL WHERE id = ?',
        [userRow.id]
      );
    }
    planStartedAt = null;
    planExpiresAt = null;
  }

  return {
    planId,
    plan,
    planStartedAt,
    planExpiresAt,
  };
};

const computePlanExpiry = (days) => {
  const normalized = normalizePlanNumber(days, 0, 0);
  if (normalized <= 0) return null;
  const expiresAt = new Date(Date.now() + normalized * 24 * 60 * 60 * 1000);
  return expiresAt.toISOString();
};

const migrateUserPlans = async () => {
  await addColumnIfMissing('users', 'plan_started_at', 'TEXT');
  await addColumnIfMissing('users', 'plan_expires_at', 'TEXT');
  const defaultPlanRow = await get('SELECT id FROM plans WHERE name = ?', [
    DEFAULT_PLAN,
  ]);
  const defaultPlanId = defaultPlanRow?.id || null;
  if (defaultPlanId) {
    await run(
      'UPDATE users SET plan = ?, plan_started_at = NULL, plan_expires_at = NULL WHERE plan = ? OR plan = ?',
      ['', defaultPlanId, DEFAULT_PLAN]
    );
  } else {
    await run(
      'UPDATE users SET plan = ?, plan_started_at = NULL, plan_expires_at = NULL WHERE plan = ?',
      ['', DEFAULT_PLAN]
    );
  }
  const users = await all(
    'SELECT id, plan, plan_started_at, plan_expires_at FROM users'
  );
  for (const user of users) {
    await resolveUserPlan(user);
  }
};

const resolvePlanLimitsForUser = async (userId) => {
  const fallbackMax = await getDefaultUserMaxSeconds();
  if (!userId) {
    return {
      plan: null,
      planId: null,
      maxTime: 0,
      maxConc: 0,
    };
  }
  const userRow = await get(
    'SELECT id, plan, plan_started_at, plan_expires_at FROM users WHERE id = ?',
    [userId]
  );
  if (!userRow) {
    return {
      plan: null,
      planId: null,
      maxTime: 0,
      maxConc: 0,
    };
  }
  const snapshot = await resolveUserPlan(userRow);
  if (!snapshot?.plan || !snapshot?.planId) {
    return {
      plan: null,
      planId: null,
      maxTime: 0,
      maxConc: 0,
      planSnapshot: snapshot,
    };
  }
  const plan = snapshot.plan;
  const planTime = normalizePlanNumber(plan?.time, 0, 0);
  const planConc = normalizePlanNumber(plan?.conc, 1, 1);
  return {
    plan,
    planId: snapshot.planId,
    maxTime: planTime > 0 ? planTime : fallbackMax,
    maxConc: planConc,
    planSnapshot: snapshot,
  };
};

const parsePlanPayload = (payload) => {
  const name = normalizePlanText(payload?.name, 64);
  const display = normalizePlanText(payload?.display, 64);
  if (!name) {
    return { error: 'invalid_name' };
  }
  if (!display) {
    return { error: 'invalid_display' };
  }
  const time = normalizePlanNumber(
    payload?.time,
    FALLBACK_USER_MAX_SECONDS,
    0,
    1_000_000_000
  );
  const conc = normalizePlanNumber(payload?.conc, 1, 1, 10_000);
  const apiAccess = normalizeAdminFlag(payload?.apiAccess);
  const expired = normalizePlanNumber(payload?.expired, 0, 0, 36500);
  const stock = normalizePlanNumber(payload?.stock, 0, 0, 1_000_000_000);
  const access = normalizePlanAccess(payload?.access);
  const isPrivate = normalizeAdminFlag(payload?.private);
  const price = normalizePlanNumber(payload?.price, 0, 0, 1_000_000_000);
  const cooldown = normalizePlanNumber(payload?.cooldown, 0, 0, 1_000_000_000);

  return {
    name,
    display,
    time,
    conc,
    apiAccess,
    expired,
    stock,
    access,
    isPrivate,
    price,
    cooldown,
  };
};

const randomInt = (min, max) =>
  Math.floor(Math.random() * (max - min + 1)) + min;

const buildCaptchaSvg = (text) => {
  const width = 220;
  const height = 64;
  const chars = text.toUpperCase().split('');
  const padding = 18;
  const spacing = (width - padding * 2) / chars.length;

  const noiseLines = Array.from({ length: 6 })
    .map(() => {
      const x1 = randomInt(0, width);
      const y1 = randomInt(0, height);
      const x2 = randomInt(0, width);
      const y2 = randomInt(0, height);
      const opacity = (Math.random() * 0.2 + 0.08).toFixed(2);
      return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="rgba(0,0,0,${opacity})" stroke-width="1" />`;
    })
    .join('');

  const noiseDots = Array.from({ length: 16 })
    .map(() => {
      const cx = randomInt(6, width - 6);
      const cy = randomInt(6, height - 6);
      const r = randomInt(1, 2);
      const opacity = (Math.random() * 0.2 + 0.1).toFixed(2);
      return `<circle cx="${cx}" cy="${cy}" r="${r}" fill="rgba(0,0,0,${opacity})" />`;
    })
    .join('');

  const textSvg = chars
    .map((char, index) => {
      const x = padding + index * spacing + randomInt(-4, 4);
      const y = 42 + randomInt(-6, 6);
      const rotate = randomInt(-12, 12);
      return `<text x="${x}" y="${y}" transform="rotate(${rotate} ${x} ${y})" font-size="24" font-weight="700" font-family="Inter, Arial, sans-serif" fill="#1c1c1e">${char}</text>`;
    })
    .join('');

  return `<?xml version="1.0" encoding="UTF-8"?>\n<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">\n  <rect width=\"100%\" height=\"100%\" rx=\"14\" ry=\"14\" fill=\"#f5f6fb\" stroke=\"#d8dde8\" />\n  ${noiseLines}\n  ${noiseDots}\n  ${textSvg}\n</svg>`;
};

const issueCaptcha = (req) => {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ0123456789';
  const token = Array.from({ length: 6 })
    .map(() => alphabet[Math.floor(Math.random() * alphabet.length)])
    .join('');
  const answer = token.toUpperCase();
  req.session.captcha = {
    answer,
    expiresAt: Date.now() + 5 * 60 * 1000,
  };

  const svg = buildCaptchaSvg(answer);
  const image = `data:image/svg+xml;base64,${Buffer.from(svg).toString(
    'base64'
  )}`;
  return { image };
};

const validateCaptcha = (req, input) => {
  const captcha = req.session.captcha;
  if (!captcha) {
    return false;
  }
  if (Date.now() > captcha.expiresAt) {
    req.session.captcha = null;
    return false;
  }
  const normalized = input.toUpperCase();
  const isValid = captcha.answer === normalized;
  req.session.captcha = null;
  return isValid;
};

const trimLoginHistory = async (userId) =>
  run(
    `DELETE FROM login_history
     WHERE user_id = ?
       AND id NOT IN (
         SELECT id FROM login_history
         WHERE user_id = ?
         ORDER BY datetime(created_at) DESC, id DESC
         LIMIT ?
       )`,
    [userId, userId, MAX_LOGIN_HISTORY]
  );

const recordLoginHistory = async (req, userId) => {
  const { ipAddress, userAgent, locale } = getClientMeta(req);
  const createdAt = new Date().toISOString();

  await run(
    `INSERT INTO login_history (user_id, ip_address, user_agent, locale, created_at)
     VALUES (?, ?, ?, ?, ?)`,
    [userId, ipAddress, userAgent, locale, createdAt]
  );

  await trimLoginHistory(userId);
};

const checkUserCooldown = async (userId, cooldownSeconds) => {
  if (!cooldownSeconds || cooldownSeconds <= 0) return { ok: true };
  try {
    // Check most recent attack in logs_run (persistent history)
    const lastAttack = await get(
      'SELECT created_at FROM logs_run WHERE user_id = ? ORDER BY datetime(created_at) DESC LIMIT 1',
      [userId]
    );
    if (!lastAttack) return { ok: true };

    const lastTime = new Date(lastAttack.created_at).getTime();
    const now = Date.now();
    const elapsed = Math.trunc((now - lastTime) / 1000);

    if (elapsed < cooldownSeconds) {
      return {
        ok: false,
        remaining: cooldownSeconds - elapsed,
      };
    }
  } catch (error) {
    console.error('Cooldown check error:', error);
  }
  return { ok: true };
};

const logAttack = async (userId, jobId, method, target, port, duration, durationSeconds, engine, status, createdAt) => {
  try {
    await run(
      `INSERT INTO logs_run (user_id, job_id, method, target, port, duration, duration_seconds, engine, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [userId, jobId, method, target, port, duration, durationSeconds, engine, status, createdAt]
    );

    // Increment global persistent total attacks counter
    await run(
      `INSERT INTO settings (key, value, updated_at) 
       VALUES ('total_attacks_count', '1', ?)
       ON CONFLICT(key) DO UPDATE SET 
       value = CAST(CAST(value AS INTEGER) + 1 AS TEXT),
       updated_at = ?`,
      [createdAt, createdAt]
    );

    await trimLogsRun(userId);
  } catch (error) {
    console.error('Log Attack Error:', error);
  }
};

const trimLogsRun = async (userId) => {
  try {
    await run(
      `DELETE FROM logs_run 
       WHERE user_id = ? 
         AND id NOT IN (
           SELECT id FROM logs_run 
           WHERE user_id = ? 
           ORDER BY datetime(created_at) DESC, id DESC 
           LIMIT 1000
         )`,
      [userId, userId]
    );
  } catch (error) {
    console.error('Trim logs_run Error:', error);
  }
};

const trimOngoingRuns = async (userId) =>
  run(
    `DELETE FROM ongoing_runs
     WHERE user_id = ?
       AND id NOT IN (
         SELECT id FROM ongoing_runs
         WHERE user_id = ?
         ORDER BY datetime(created_at) DESC, id DESC
         LIMIT ?
       )`,
    [userId, userId, MAX_ONGOING_RUNS]
  );

app.set('trust proxy', 1);

app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
  })
);

app.use(
  cors({
    origin: CLIENT_ORIGIN,
    credentials: true,
  })
);

app.use(express.json({ limit: '10kb' }));

app.use(
  session({
    name: 'sid',
    secret: SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    store: new SQLiteStore({
      db: 'sessions.sqlite',
      dir: path.join(__dirname, 'data'),
    }),
    cookie: {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000,
    },
  })
);

const loginLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'rate_limited' },
});

const registerLimiter = rateLimit({
  windowMs: 30 * 60 * 1000,
  max: 6,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'rate_limited' },
});

const changePasswordLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'rate_limited' },
});

const deleteAccountLimiter = rateLimit({
  windowMs: 30 * 60 * 1000,
  max: 4,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'rate_limited' },
});

app.get('/api/captcha', (req, res) => {
  const captcha = issueCaptcha(req);
  res.set('Cache-Control', 'no-store');
  res.json({ image: captcha.image });
});

app.post('/api/register', registerLimiter, async (req, res) => {
  try {
    const username = sanitize(req.body.username);
    const password = sanitize(req.body.password);
    const confirmPassword = sanitize(req.body.confirmPassword);
    const captcha = sanitize(req.body.captcha);

    if (!USERNAME_REGEX.test(username)) {
      return res.status(400).json({ error: 'invalid_username' });
    }
    if (password.length < 8 || password.length > 72) {
      return res.status(400).json({ error: 'invalid_password' });
    }
    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'password_mismatch' });
    }
    if (!CAPTCHA_REGEX.test(captcha) || !validateCaptcha(req, captcha)) {
      return res.status(400).json({ error: 'invalid_captcha' });
    }

    const existing = await get(
      'SELECT id FROM users WHERE username = ?',
      [username]
    );
    if (existing) {
      return res.status(409).json({ error: 'user_exists' });
    }
    const passwordHash = await bcrypt.hash(password, 12);
    const createdAt = new Date().toISOString();
    const token = await generateUniqueToken();
    const uniqCode = await generateUniqueUniqCode();
    const planId = null;
    const planLabel = '';
    const result = await run(
      'INSERT INTO users (username, password_hash, telegram_chat_id, plan, token, uniq_code, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [
        username,
        passwordHash,
        '',
        '',
        token,
        uniqCode,
        createdAt,
      ]
    );

    req.session.userId = result.lastID;
    req.session.username = username;
    req.session.plan = planLabel;
    req.session.createdAt = createdAt;
    req.session.token = token;
    const sessionToken = ensureSessionToken(req, true);
    recordLoginHistory(req, result.lastID).catch((historyErr) => {
      console.error('Login history error:', historyErr);
    });

    return res.status(201).json({
      user: {
        id: result.lastID,
        username,
        isAdmin: false,
        plan: planLabel,
        planId,
        planDetails: null,
        planStartedAt: null,
        planExpiresAt: null,
        balance: DEFAULT_BALANCE,
        token: sessionToken,
        uniqCode,
        created_at: createdAt,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/login', loginLimiter, async (req, res) => {
  try {
    const username = sanitize(req.body.username);
    const password = sanitize(req.body.password);

    if (!USERNAME_REGEX.test(username)) {
      return res.status(400).json({ error: 'invalid_username' });
    }
    if (password.length < 8 || password.length > 72) {
      return res.status(400).json({ error: 'invalid_password' });
    }

    const user = await get(
      `SELECT id, username, password_hash, plan, balance, token, uniq_code, created_at,
              plan_started_at, plan_expires_at, is_admin
       FROM users WHERE username = ?`,
      [username]
    );
    if (!user) {
      return res.status(401).json({ error: 'invalid_credentials' });
    }

    const matches = await bcrypt.compare(password, user.password_hash);
    if (!matches) {
      return res.status(401).json({ error: 'invalid_credentials' });
    }

    const planSnapshot = await resolveUserPlan(user);
    const planLabel = planSnapshot?.plan?.display || '';
    const planDetails = mapPlanSummary(planSnapshot?.plan);
    const rawBalance = Number(user.balance);
    const balance = normalizeBalance(user.balance);
    let token = user.token;
    let uniqCode = user.uniq_code;
    if (!token) {
      token = await generateUniqueToken();
      const updateResult = await run(
        'UPDATE users SET token = ? WHERE id = ? AND (token IS NULL OR token = "")',
        [token, user.id]
      );
      if (updateResult.changes === 0) {
        const refreshed = await get('SELECT token FROM users WHERE id = ?', [
          user.id,
        ]);
        token = refreshed?.token || token;
      }
    }
    if (!uniqCode) {
      uniqCode = await generateUniqueUniqCode();
      const updateResult = await run(
        'UPDATE users SET uniq_code = ? WHERE id = ? AND (uniq_code IS NULL OR uniq_code = "")',
        [uniqCode, user.id]
      );
      if (updateResult.changes === 0) {
        const refreshed = await get(
          'SELECT uniq_code FROM users WHERE id = ?',
          [user.id]
        );
        uniqCode = refreshed?.uniq_code || uniqCode;
      }
    }
    const isAdmin = Number(user.is_admin) === 1;

    req.session.userId = user.id;
    req.session.username = user.username;
    req.session.plan = planLabel;
    req.session.createdAt = user.created_at;
    req.session.token = token;
    const sessionToken = ensureSessionToken(req, true);
    recordLoginHistory(req, user.id).catch((historyErr) => {
      console.error('Login history error:', historyErr);
    });
    if (!Number.isFinite(rawBalance) || rawBalance < 0) {
      run('UPDATE users SET balance = ? WHERE id = ?', [
        balance,
        user.id,
      ]).catch((updateErr) => console.error(updateErr));
    } else if (Math.trunc(rawBalance) !== balance) {
      run('UPDATE users SET balance = ? WHERE id = ?', [
        balance,
        user.id,
      ]).catch((updateErr) => console.error(updateErr));
    }
    return res.json({
      user: {
        id: user.id,
        username: user.username,
        isAdmin,
        plan: planLabel,
        planId: planSnapshot?.planId ?? null,
        planDetails,
        planStartedAt: planSnapshot?.planStartedAt ?? null,
        planExpiresAt: planSnapshot?.planExpiresAt ?? null,
        balance,
        token: sessionToken,
        uniqCode,
        created_at: user.created_at,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/change-password', changePasswordLimiter, async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    const currentPassword = sanitize(req.body.currentPassword);
    const nextPassword = sanitize(req.body.nextPassword);
    const confirmPassword = sanitize(req.body.confirmPassword);

    if (
      nextPassword.length < 1 ||
      currentPassword.length < 1 ||
      currentPassword.length > 72
    ) {
      return res.status(400).json({ error: 'invalid_password' });
    }
    if (nextPassword !== confirmPassword) {
      return res.status(400).json({ error: 'password_mismatch' });
    }
    if (!isStrongPassword(nextPassword)) {
      return res.status(400).json({ error: 'weak_password' });
    }

    const sessionToken = ensureSessionToken(req);
    const user = await get(
      `SELECT id, username, password_hash, plan, plan_started_at, plan_expires_at, token
       FROM users WHERE id = ?`,
      [req.session.userId]
    );
    if (!user) {
      return res.status(401).json({ error: 'unauthorized' });
    }

    const matches = await bcrypt.compare(currentPassword, user.password_hash);
    if (!matches) {
      return res.status(401).json({ error: 'invalid_current_password' });
    }

    const sameAsOld = await bcrypt.compare(nextPassword, user.password_hash);
    if (sameAsOld) {
      return res.status(400).json({ error: 'password_same' });
    }

    const passwordHash = await bcrypt.hash(nextPassword, 12);
    await run('UPDATE users SET password_hash = ? WHERE id = ?', [
      passwordHash,
      user.id,
    ]);

    const planSnapshot = await resolveUserPlan(user);
    const planLabel = planSnapshot?.plan?.display || '';

    const sessionSnapshot = {
      userId: user.id,
      username: user.username,
      plan: planLabel,
      token: user.token,
      sessionToken,
    };

    req.session.regenerate((err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'server_error' });
      }
      req.session.userId = sessionSnapshot.userId;
      req.session.username = sessionSnapshot.username;
      req.session.plan = sessionSnapshot.plan;
      req.session.token = sessionSnapshot.token;
      req.session.sessionToken =
        sessionSnapshot.sessionToken || generateToken();
      return res.json({ ok: true });
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/delete-account', deleteAccountLimiter, async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    const password = sanitize(req.body.password);
    const captcha = sanitize(req.body.captcha);

    if (password.length < 8 || password.length > 72) {
      return res.status(400).json({ error: 'invalid_password' });
    }
    if (!CAPTCHA_REGEX.test(captcha) || !validateCaptcha(req, captcha)) {
      return res.status(400).json({ error: 'invalid_captcha' });
    }

    const user = await get(
      'SELECT id, password_hash FROM users WHERE id = ?',
      [req.session.userId]
    );
    if (!user) {
      return res.status(401).json({ error: 'unauthorized' });
    }

    const matches = await bcrypt.compare(password, user.password_hash);
    if (!matches) {
      return res.status(401).json({ error: 'invalid_password' });
    }

    await delay(DELETE_DELAY_MS);
    await run('DELETE FROM login_history WHERE user_id = ?', [user.id]);
    await run('DELETE FROM users WHERE id = ?', [user.id]);

    req.session.destroy((err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: 'server_error' });
      }
      res.clearCookie('sid');
      return res.json({ ok: true });
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/profile', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ user: null });
  }

  try {
    const user = await get(
      `SELECT id, username, plan, balance,
              plan_started_at, plan_expires_at,
              token, uniq_code, created_at, is_admin
       FROM users WHERE id = ?`,
      [req.session.userId]
    );
    if (!user) {
      return res.status(401).json({ user: null });
    }
    const planSnapshot = await resolveUserPlan(user);
    const planLabel = planSnapshot?.plan?.display || '';
    const planDetails = mapPlanSummary(planSnapshot?.plan);
    const rawBalance = Number(user.balance);
    const balance = normalizeBalance(user.balance);
    const isAdmin = Number(user.is_admin) === 1;
    if (!Number.isFinite(rawBalance) || rawBalance < 0) {
      run('UPDATE users SET balance = ? WHERE id = ?', [
        balance,
        user.id,
      ]).catch((updateErr) => console.error(updateErr));
    } else if (Math.trunc(rawBalance) !== balance) {
      run('UPDATE users SET balance = ? WHERE id = ?', [
        balance,
        user.id,
      ]).catch((updateErr) => console.error(updateErr));
    }
    req.session.username = user.username;
    req.session.plan = planLabel;
    req.session.createdAt = user.created_at;
    req.session.token = user.token;
    const sessionToken = ensureSessionToken(req);

    let uniqCode = user.uniq_code;
    if (!uniqCode) {
      uniqCode = await generateUniqueUniqCode();
      const updateResult = await run(
        'UPDATE users SET uniq_code = ? WHERE id = ? AND (uniq_code IS NULL OR uniq_code = "")',
        [uniqCode, user.id]
      );
      if (updateResult.changes === 0) {
        const refreshed = await get(
          'SELECT uniq_code FROM users WHERE id = ?',
          [user.id]
        );
        uniqCode = refreshed?.uniq_code || uniqCode;
      }
    }

    return res.json({
      user: {
        id: user.id,
        username: user.username,
        isAdmin,
        plan: planLabel,
        planId: planSnapshot?.planId ?? null,
        planDetails,
        planStartedAt: planSnapshot?.planStartedAt ?? null,
        planExpiresAt: planSnapshot?.planExpiresAt ?? null,
        balance,
        token: sessionToken,
        uniqCode,
        created_at: user.created_at,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/admin/users', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const rawQuery = sanitize(req.query?.q || '');
    const limit = Math.min(200, Math.max(1, Number(req.query?.limit) || 200));
    const params = [];
    let where = '';
    if (rawQuery) {
      const like = `%${rawQuery}%`;
      where = 'WHERE username LIKE ?';
      params.push(like);
    }

    const rows = await all(
      `SELECT id, username, plan, plan_started_at, plan_expires_at, balance,
              is_admin, created_at
       FROM users
       ${where}
       ORDER BY datetime(created_at) DESC, id DESC
       LIMIT ?`,
      [...params, limit]
    );

    const users = await Promise.all(
      rows.map(async (row) => {
        const planSnapshot = await resolveUserPlan(row);
        const planLabel = planSnapshot?.plan?.display || '';
        return {
          id: row.id,
          username: row.username,
          plan: planLabel,
          planId: planSnapshot?.planId ?? null,
          planExpiresAt: planSnapshot?.planExpiresAt ?? null,
          balance: normalizeBalance(row.balance),
          isAdmin: Number(row.is_admin) === 1,
          createdAt: row.created_at,
        };
      })
    );

    return res.json({ users });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/admin/users/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const userId = Number(req.params.id);
    if (!Number.isInteger(userId)) {
      return res.status(400).json({ error: 'invalid_user' });
    }
    const row = await get(
      `SELECT id, username, plan, balance,
              plan_started_at, plan_expires_at,
              is_admin, created_at
       FROM users
       WHERE id = ?`,
      [userId]
    );
    if (!row) {
      return res.status(404).json({ error: 'not_found' });
    }
    const planSnapshot = await resolveUserPlan(row);
    const planLabel = planSnapshot?.plan?.display || '';
    return res.json({
      user: {
        id: row.id,
        username: row.username,
        plan: planLabel,
        planId: planSnapshot?.planId ?? null,
        planStartedAt: planSnapshot?.planStartedAt ?? null,
        planExpiresAt: planSnapshot?.planExpiresAt ?? null,
        balance: normalizeBalance(row.balance),
        isAdmin: Number(row.is_admin) === 1,
        createdAt: row.created_at,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/admin/users/admin', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const userId = Number(req.body?.userId);
    if (!Number.isInteger(userId)) {
      return res.status(400).json({ error: 'invalid_user' });
    }
    const isAdmin = normalizeAdminFlag(req.body?.isAdmin);
    const target = await get(
      'SELECT id, is_admin FROM users WHERE id = ?',
      [userId]
    );
    if (!target) {
      return res.status(404).json({ error: 'not_found' });
    }
    if (userId === req.session.userId && !isAdmin) {
      return res.status(400).json({ error: 'cannot_demote_self' });
    }
    if (!isAdmin && Number(target.is_admin) === 1) {
      const adminCount = await get(
        'SELECT COUNT(*) AS total FROM users WHERE is_admin = 1'
      );
      if (Number(adminCount?.total) <= 1) {
        return res.status(400).json({ error: 'last_admin' });
      }
    }

    await run('UPDATE users SET is_admin = ? WHERE id = ?', [
      isAdmin ? 1 : 0,
      userId,
    ]);

    return res.json({ ok: true, userId, isAdmin });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/admin/users/password', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const userId = Number(req.body?.userId);
    const nextPassword = sanitize(req.body?.password);
    const confirmPassword = sanitize(req.body?.confirmPassword);

    if (!Number.isInteger(userId)) {
      return res.status(400).json({ error: 'invalid_user' });
    }
    if (!nextPassword || nextPassword.length > 72) {
      return res.status(400).json({ error: 'invalid_password' });
    }
    if (nextPassword !== confirmPassword) {
      return res.status(400).json({ error: 'password_mismatch' });
    }
    if (!isStrongPassword(nextPassword)) {
      return res.status(400).json({ error: 'weak_password' });
    }

    const target = await get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!target) {
      return res.status(404).json({ error: 'not_found' });
    }

    const passwordHash = await bcrypt.hash(nextPassword, 12);
    await run('UPDATE users SET password_hash = ? WHERE id = ?', [
      passwordHash,
      userId,
    ]);

    return res.json({ ok: true });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/admin/users/balance', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const userId = Number(req.body?.userId);
    const rawAmount = Number(req.body?.amount);
    const amount = Math.trunc(rawAmount);
    if (!Number.isInteger(userId)) {
      return res.status(400).json({ error: 'invalid_user' });
    }
    if (!Number.isFinite(rawAmount) || rawAmount <= 0 || amount !== rawAmount) {
      return res.status(400).json({ error: 'invalid_amount' });
    }
    if (amount > 1_000_000_000) {
      return res.status(400).json({ error: 'amount_too_large' });
    }

    const target = await get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!target) {
      return res.status(404).json({ error: 'not_found' });
    }

    await run('UPDATE users SET balance = balance + ? WHERE id = ?', [
      amount,
      userId,
    ]);
    const updated = await get('SELECT balance FROM users WHERE id = ?', [
      userId,
    ]);

    return res.json({
      ok: true,
      userId,
      amountAdded: amount,
      balance: normalizeBalance(updated?.balance),
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/admin/users/plan', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const userId = Number(req.body?.userId);
    const rawPlanId = req.body?.planId;
    const planId = normalizePlanId(rawPlanId);
    const hasRawPlan =
      rawPlanId !== undefined &&
      rawPlanId !== null &&
      String(rawPlanId).trim() !== '';
    if (!Number.isInteger(userId)) {
      return res.status(400).json({ error: 'invalid_user' });
    }
    if (!planId) {
      if (hasRawPlan) {
        return res.status(400).json({ error: 'invalid_plan' });
      }
      await run(
        'UPDATE users SET plan = ?, plan_started_at = NULL, plan_expires_at = NULL WHERE id = ?',
        ['', userId]
      );
      if (req.session.userId === userId) {
        req.session.plan = '';
      }
      return res.json({
        ok: true,
        userId,
        planId: null,
        plan: '',
        planStartedAt: null,
        planExpiresAt: null,
      });
    }
    const target = await get('SELECT id FROM users WHERE id = ?', [userId]);
    if (!target) {
      return res.status(404).json({ error: 'not_found' });
    }
    const plan = await fetchPlanById(planId);
    if (!plan) {
      return res.status(404).json({ error: 'plan_not_found' });
    }
    const nowIso = new Date().toISOString();
    const startedAt = nowIso;
    const expiresAt = computePlanExpiry(plan.expired);

    await run(
      'UPDATE users SET plan = ?, plan_started_at = ?, plan_expires_at = ? WHERE id = ?',
      [planId, startedAt, expiresAt, userId]
    );
    if (req.session.userId === userId) {
      req.session.plan = plan.display;
    }

    return res.json({
      ok: true,
      userId,
      planId,
      plan: plan.display,
      planStartedAt: startedAt,
      planExpiresAt: expiresAt,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/admin/plans', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const rawQuery = sanitize(req.query?.q || '');
    const limit = Math.min(200, Math.max(1, Number(req.query?.limit) || 200));
    const params = [];
    let where = '';
    if (rawQuery) {
      const like = `%${rawQuery}%`;
      where = 'WHERE name LIKE ? OR display_name LIKE ?';
      params.push(like, like);
    }
    const rows = await all(
      `SELECT * FROM plans
       ${where}
       ORDER BY datetime(created_at) DESC, id DESC
       LIMIT ?`,
      [...params, limit]
    );
    return res.json({ plans: rows.map(mapPlanRow) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/admin/plans/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const planId = normalizePlanId(req.params.id);
    if (!planId) {
      return res.status(400).json({ error: 'invalid_plan' });
    }
    const row = await get('SELECT * FROM plans WHERE id = ?', [planId]);
    if (!row) {
      return res.status(404).json({ error: 'not_found' });
    }
    return res.json({ plan: mapPlanRow(row) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/admin/plans', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const payload = parsePlanPayload(req.body);
    if (payload.error) {
      return res.status(400).json({ error: payload.error });
    }
    const nowIso = new Date().toISOString();
    await run(
      `INSERT INTO plans
       (name, display_name, time_seconds, conc, api_access, expired_days, stock, access_level, is_private, price, cooldown_seconds, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        payload.name,
        payload.display,
        payload.time,
        payload.conc,
        payload.apiAccess ? 1 : 0,
        payload.expired,
        payload.stock,
        payload.access,
        payload.isPrivate ? 1 : 0,
        payload.price,
        payload.cooldown,
        nowIso,
        nowIso,
      ]
    );
    const row = await get('SELECT * FROM plans WHERE name = ?', [
      payload.name,
    ]);
    clearPlanCache();
    return res.status(201).json({ plan: mapPlanRow(row) });
  } catch (error) {
    if (String(error?.message || '').includes('UNIQUE')) {
      return res.status(409).json({ error: 'plan_exists' });
    }
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.put('/api/admin/plans/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const planId = normalizePlanId(req.params.id);
    if (!planId) {
      return res.status(400).json({ error: 'invalid_plan' });
    }
    const payload = parsePlanPayload(req.body);
    if (payload.error) {
      return res.status(400).json({ error: payload.error });
    }
    const existing = await get('SELECT id, name FROM plans WHERE id = ?', [
      planId,
    ]);
    if (!existing) {
      return res.status(404).json({ error: 'not_found' });
    }
    const nowIso = new Date().toISOString();
    await run(
      `UPDATE plans
       SET name = ?, display_name = ?, time_seconds = ?, conc = ?, api_access = ?,
           expired_days = ?, stock = ?, access_level = ?, is_private = ?, price = ?, cooldown_seconds = ?, updated_at = ?
       WHERE id = ?`,
      [
        payload.name,
        payload.display,
        payload.time,
        payload.conc,
        payload.apiAccess ? 1 : 0,
        payload.expired,
        payload.stock,
        payload.access,
        payload.isPrivate ? 1 : 0,
        payload.price,
        payload.cooldown,
        nowIso,
        planId,
      ]
    );
    const updated = await get('SELECT * FROM plans WHERE id = ?', [planId]);
    clearPlanCache();
    return res.json({ plan: mapPlanRow(updated) });
  } catch (error) {
    if (String(error?.message || '').includes('UNIQUE')) {
      return res.status(409).json({ error: 'plan_exists' });
    }
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.delete('/api/admin/plans/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const planId = normalizePlanId(req.params.id);
    if (!planId) {
      return res.status(400).json({ error: 'invalid_plan' });
    }
    const existing = await get('SELECT id FROM plans WHERE id = ?', [planId]);
    if (!existing) {
      return res.status(404).json({ error: 'not_found' });
    }
    const userCount = await get(
      'SELECT COUNT(*) AS total FROM users WHERE plan = ?',
      [planId]
    );
    if (Number(userCount?.total) > 0) {
      return res.status(400).json({ error: 'plan_in_use' });
    }
    await run('DELETE FROM plans WHERE id = ?', [planId]);
    clearPlanCache();
    return res.json({ ok: true });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/admin/news', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const rawQuery = sanitize(req.query?.q || '');
    const limit = Math.min(50, Math.max(1, Number(req.query?.limit) || 50));
    const params = [];
    let where = '';
    if (rawQuery) {
      const like = `%${rawQuery}%`;
      where = 'WHERE title LIKE ? OR message LIKE ? OR author LIKE ?';
      params.push(like, like, like);
    }
    const rows = await all(
      `SELECT id, title, message, author, created_at
       FROM news
       ${where}
       ORDER BY datetime(created_at) DESC, id DESC
       LIMIT ?`,
      [...params, limit]
    );
    return res.json({
      items: rows.map((row) => ({
        id: row.id,
        title: row.title,
        message: row.message,
        author: row.author,
        createdAt: row.created_at,
      })),
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/admin/news', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const title = normalizeNewsText(req.body?.title, 80);
    const message = normalizeNewsMessage(req.body?.message, 320);
    let author = normalizeNewsText(req.body?.author, 48);
    if (!title) {
      return res.status(400).json({ error: 'invalid_title' });
    }
    if (!message) {
      return res.status(400).json({ error: 'invalid_message' });
    }
    if (!author) {
      const user = await get('SELECT username FROM users WHERE id = ?', [
        req.session.userId,
      ]);
      author =
        normalizeNewsText(user?.username, 48) || DEFAULT_NEWS_AUTHOR;
    }
    const nowIso = new Date().toISOString();
    const result = await run(
      'INSERT INTO news (title, message, author, created_at) VALUES (?, ?, ?, ?)',
      [title, message, author, nowIso]
    );
    return res.status(201).json({
      item: {
        id: result?.lastID,
        title,
        message,
        author,
        createdAt: nowIso,
      },
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.delete('/api/admin/news/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const newsId = normalizeNewsId(req.params?.id);
    if (!newsId) {
      return res.status(400).json({ error: 'invalid_id' });
    }
    const result = await run('DELETE FROM news WHERE id = ?', [newsId]);
    if (!result?.changes) {
      return res.status(404).json({ error: 'not_found' });
    }
    return res.json({ ok: true, id: newsId });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/admin/methods', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const rawQuery = sanitize(req.query?.q || '');
    const limit = Math.min(100, Math.max(1, Number(req.query?.limit) || 100));
    const params = [];
    let where = '';
    if (rawQuery) {
      const like = `%${rawQuery}%`;
      where = 'WHERE name LIKE ? OR display_name LIKE ?';
      params.push(like, like);
    }
    const rows = await all(
      `SELECT id, hash, name, display_name, description, max_duration_seconds, access_level,
              api_access, layer, enabled, created_at, updated_at
       FROM methods
       ${where}
       ORDER BY name ASC, id ASC
       LIMIT ?`,
      [...params, limit]
    );
    return res.json({ methods: rows.map(mapMethodRow) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/admin/methods', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const name = normalizeMethodNameInput(req.body?.name);
    const display = normalizeMethodDisplay(req.body?.display);
    const access = normalizePlanAccess(req.body?.access);
    const apiAccess = normalizeAdminFlag(req.body?.apiAccess);
    const layer = req.body?.layer === 'Layer 4' ? 'Layer 4' : 'Layer 7';

    if (!name) {
      return res.status(400).json({ error: 'invalid_name' });
    }
    if (!display) {
      return res.status(400).json({ error: 'invalid_display' });
    }

    const hash = createMethodHash(name);
    if (!hash) {
      return res.status(400).json({ error: 'invalid_name' });
    }

    const existing = await get(
      'SELECT id FROM methods WHERE hash = ? OR LOWER(name) = LOWER(?)',
      [hash, name]
    );
    if (existing) {
      return res.status(409).json({ error: 'method_exists' });
    }

    let maxDuration = FALLBACK_METHOD_MAX_SECONDS;
    try {
      maxDuration = await getDefaultMethodMaxSeconds();
    } catch (maxError) {
      console.error('Method max lookup error:', maxError);
    }

    const nowIso = new Date().toISOString();
    const description = String(req.body?.description || '').trim();
    const result = await run(
      `INSERT INTO methods
       (hash, name, display_name, description, max_duration_seconds, exclusive_host, enabled, access_level, api_access, layer, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        hash,
        name,
        display,
        description,
        maxDuration,
        0,
        1,
        access,
        apiAccess ? 1 : 0,
        layer,
        nowIso,
        nowIso,
      ]
    );
    const row = await get('SELECT * FROM methods WHERE id = ?', [
      result?.lastID,
    ]);
    return res.status(201).json({ method: mapMethodRow(row) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.put('/api/admin/methods/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const methodId = normalizeNewsId(req.params?.id);
    if (!methodId) {
      return res.status(400).json({ error: 'invalid_id' });
    }

    const { display, description, access, apiAccess, layer } = req.body;
    const nowIso = new Date().toISOString();

    const result = await run(
      `UPDATE methods 
       SET display_name = ?, description = ?, access_level = ?, api_access = ?, layer = ?, updated_at = ?
       WHERE id = ?`,
      [
        String(display || '').trim(),
        String(description || '').trim(),
        normalizePlanAccess(access),
        normalizeAdminFlag(apiAccess) ? 1 : 0,
        layer === 'Layer 4' ? 'Layer 4' : 'Layer 7',
        nowIso,
        methodId
      ]
    );

    console.log('[DEBUG] Method update result:', { methodId, changes: result?.changes });

    const row = await get('SELECT * FROM methods WHERE id = ?', [methodId]);
    if (!row) {
      console.log('[DEBUG] Method not found after update attempt:', { methodId });
      return res.status(404).json({ error: 'not_found' });
    }
    return res.json({ method: mapMethodRow(row) });
  } catch (error) {
    console.error('[DEBUG] Method update error:', error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.delete('/api/admin/methods/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const methodId = normalizeNewsId(req.params?.id);
    if (!methodId) {
      return res.status(400).json({ error: 'invalid_id' });
    }
    const result = await run('DELETE FROM methods WHERE id = ?', [methodId]);
    if (!result?.changes) {
      return res.status(404).json({ error: 'not_found' });
    }
    return res.json({ ok: true, id: methodId });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/keys', async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'unauthorized' });
  try {
    const rows = await all(
      `SELECT id, api_key, name, whitelist_ips, auto_bind, allowed_methods, max_time, max_engine, last_ip, last_used_at, created_at 
       FROM api_keys WHERE user_id = ? ORDER BY id DESC`,
      [req.session.userId]
    );
    const keys = rows.map(r => ({
      id: r.id,
      key: r.api_key,
      name: r.name,
      whitelistIps: JSON.parse(r.whitelist_ips || '[]'),
      autoBind: Number(r.auto_bind) === 1,
      allowedMethods: JSON.parse(r.allowed_methods || '[]'),
      maxTime: r.max_time || 0,
      maxEngine: r.max_engine || 0,
      lastIp: r.last_ip,
      lastUsedAt: r.last_used_at,
      createdAt: r.created_at
    }));
    return res.json({ keys });
  } catch (error) {
    console.error('Fetch keys error:', error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/keys', async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'unauthorized' });
  try {
    const name = sanitize(req.body?.name || '').trim().slice(0, 50) || 'API Key';
    const autoBind = req.body?.autoBind ? 1 : 0;
    const maxTime = Math.max(0, parseInt(req.body?.maxTime) || 0);
    const maxEngine = Math.max(0, parseInt(req.body?.maxEngine) || 0);

    let allowedMethods = [];
    if (Array.isArray(req.body?.allowedMethods)) {
      allowedMethods = req.body.allowedMethods.map(m => sanitize(m));
    }

    let whitelistIps = [];
    if (Array.isArray(req.body?.whitelistIps)) {
      whitelistIps = req.body.whitelistIps.map(ip => sanitize(ip).trim()).filter(Boolean);
    }

    const count = await get('SELECT COUNT(*) as c FROM api_keys WHERE user_id = ?', [req.session.userId]);
    if (count && count.c >= 10) return res.status(400).json({ error: 'max_keys_reached' });

    const rawKey = require('crypto').randomBytes(32).toString('hex');
    const apiKey = `flash_${rawKey}`;
    const nowIso = new Date().toISOString();

    await run(
      `INSERT INTO api_keys (user_id, api_key, name, whitelist_ips, auto_bind, allowed_methods, max_time, max_engine, created_at, updated_at) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.session.userId, apiKey, name, JSON.stringify(whitelistIps), autoBind, JSON.stringify(allowedMethods), maxTime, maxEngine, nowIso, nowIso]
    );

    return res.status(201).json({ ok: true, key: apiKey });
  } catch (error) {
    console.error('Create key error:', error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.put('/api/keys/:id', async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'unauthorized' });
  try {
    const keyId = parseInt(req.params.id, 10);
    const name = sanitize(req.body?.name || '').trim().slice(0, 50);
    const autoBind = req.body?.autoBind ? 1 : 0;
    const maxTime = req.body?.maxTime !== undefined ? Math.max(0, parseInt(req.body.maxTime) || 0) : null;
    const maxEngine = req.body?.maxEngine !== undefined ? Math.max(0, parseInt(req.body.maxEngine) || 0) : null;

    let whitelistIps = [];
    if (Array.isArray(req.body?.whitelistIps)) {
      whitelistIps = req.body.whitelistIps.map(ip => sanitize(ip).trim()).filter(Boolean);
    }

    let allowedMethods = [];
    if (Array.isArray(req.body?.allowedMethods)) {
      allowedMethods = req.body.allowedMethods.map(m => sanitize(m));
    }

    const nowIso = new Date().toISOString();

    let query = `UPDATE api_keys SET name = ?, auto_bind = ?, whitelist_ips = ?, allowed_methods = ?, updated_at = ?`;
    const params = [name, autoBind, JSON.stringify(whitelistIps), JSON.stringify(allowedMethods), nowIso];

    if (maxTime !== null) {
      query += `, max_time = ?`;
      params.push(maxTime);
    }
    if (maxEngine !== null) {
      query += `, max_engine = ?`;
      params.push(maxEngine);
    }

    query += ` WHERE id = ? AND user_id = ?`;
    params.push(keyId, req.session.userId);

    const result = await run(query, params);

    if (!result?.changes) return res.status(404).json({ error: 'not_found' });
    return res.json({ ok: true });
  } catch (error) {
    console.error('Update key error:', error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.delete('/api/keys/:id', async (req, res) => {
  if (!req.session.userId) return res.status(401).json({ error: 'unauthorized' });
  try {
    const keyId = parseInt(req.params.id, 10);
    const result = await run('DELETE FROM api_keys WHERE id = ? AND user_id = ?', [keyId, req.session.userId]);
    if (!result?.changes) return res.status(404).json({ error: 'not_found' });
    return res.json({ ok: true });
  } catch (error) {
    console.error('Delete key error:', error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/admin/servers', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const rawQuery = sanitize(req.query?.q || '');
    const limit = Math.min(100, Math.max(1, Number(req.query?.limit) || 100));
    const params = [];
    let where = '';
    if (rawQuery) {
      const like = `%${rawQuery}%`;
      where = 'WHERE name LIKE ? OR api_url LIKE ?';
      params.push(like, like);
    }
    const rows = await all(
      `SELECT id, name, api_url, duration_max, engine, methods, status,
              created_at, updated_at
       FROM servers
       ${where}
       ORDER BY datetime(created_at) DESC, id DESC
       LIMIT ?`,
      [...params, limit]
    );
    return res.json({ servers: rows.map(mapServerRow) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/admin/servers/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const serverId = normalizeNewsId(req.params?.id);
    if (!serverId) {
      return res.status(400).json({ error: 'invalid_id' });
    }
    const row = await get(
      `SELECT id, name, api_url, duration_max, engine, methods, status,
              created_at, updated_at
       FROM servers
       WHERE id = ?`,
      [serverId]
    );
    if (!row) {
      return res.status(404).json({ error: 'not_found' });
    }
    return res.json({ server: mapServerRow(row) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/admin/servers', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const name = normalizeServerText(req.body?.name, 64);
    const apiUrl = normalizeServerUrl(req.body?.apiUrl);
    const durationMax = normalizeServerNumber(req.body?.durationMax, 1);
    const engineInput = req.body?.concurrent ?? req.body?.engine;
    const engine = normalizeServerNumber(engineInput, 1);
    const status = normalizeServerStatus(req.body?.status);
    const methods = normalizeServerMethods(req.body?.methods);

    if (!name) {
      return res.status(400).json({ error: 'invalid_name' });
    }
    if (!apiUrl) {
      return res.status(400).json({ error: 'invalid_url' });
    }
    if (!durationMax) {
      return res.status(400).json({ error: 'invalid_duration' });
    }
    if (!engine) {
      return res.status(400).json({ error: 'invalid_engine' });
    }
    if (!methods.length) {
      return res.status(400).json({ error: 'invalid_methods' });
    }

    const nowIso = new Date().toISOString();
    const result = await run(
      `INSERT INTO servers
       (name, api_url, duration_max, engine, methods, status, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        name,
        apiUrl,
        durationMax,
        engine,
        JSON.stringify(methods),
        status,
        nowIso,
        nowIso,
      ]
    );
    const row = await get('SELECT * FROM servers WHERE id = ?', [
      result?.lastID,
    ]);
    return res.status(201).json({ server: mapServerRow(row) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.put('/api/admin/servers/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const serverId = normalizeNewsId(req.params?.id);
    if (!serverId) {
      return res.status(400).json({ error: 'invalid_id' });
    }
    const name = normalizeServerText(req.body?.name, 64);
    const apiUrlRaw = req.body?.apiUrl;
    const apiUrlProvided =
      typeof apiUrlRaw === 'string' && apiUrlRaw.trim() !== '';
    const apiUrl = apiUrlProvided ? normalizeServerUrl(apiUrlRaw) : '';
    const durationMax = normalizeServerNumber(req.body?.durationMax, 1);
    const engineInput = req.body?.concurrent ?? req.body?.engine;
    const engine = normalizeServerNumber(engineInput, 1);
    const status = normalizeServerStatus(req.body?.status);
    const methods = normalizeServerMethods(req.body?.methods);

    if (!name) {
      return res.status(400).json({ error: 'invalid_name' });
    }
    if (apiUrlProvided && !apiUrl) {
      return res.status(400).json({ error: 'invalid_url' });
    }
    const existing = await get('SELECT api_url FROM servers WHERE id = ?', [
      serverId,
    ]);
    if (!existing) {
      return res.status(404).json({ error: 'not_found' });
    }
    const finalApiUrl = apiUrlProvided ? apiUrl : existing.api_url;
    if (!finalApiUrl) {
      return res.status(400).json({ error: 'invalid_url' });
    }
    if (!durationMax) {
      return res.status(400).json({ error: 'invalid_duration' });
    }
    if (!engine) {
      return res.status(400).json({ error: 'invalid_engine' });
    }
    if (!methods.length) {
      return res.status(400).json({ error: 'invalid_methods' });
    }

    const nowIso = new Date().toISOString();
    await run(
      `UPDATE servers
       SET name = ?, api_url = ?, duration_max = ?, engine = ?, methods = ?,
           status = ?, updated_at = ?
       WHERE id = ?`,
      [
        name,
        finalApiUrl,
        durationMax,
        engine,
        JSON.stringify(methods),
        status,
        nowIso,
        serverId,
      ]
    );
    const row = await get('SELECT * FROM servers WHERE id = ?', [serverId]);
    if (!row) {
      return res.status(404).json({ error: 'not_found' });
    }
    return res.json({ server: mapServerRow(row) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.delete('/api/admin/servers/:id', async (req, res) => {
  try {
    if (!(await requireAdmin(req, res))) {
      return;
    }
    const serverId = normalizeNewsId(req.params?.id);
    if (!serverId) {
      return res.status(400).json({ error: 'invalid_id' });
    }
    const result = await run('DELETE FROM servers WHERE id = ?', [serverId]);
    if (!result?.changes) {
      return res.status(404).json({ error: 'not_found' });
    }
    return res.json({ ok: true, id: serverId });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/public/plans', async (req, res) => {
  try {
    const rows = await all(
      `SELECT * FROM plans
       WHERE is_private = 0
       ORDER BY price ASC, id ASC`
    );
    return res.json({ plans: rows.map(mapPlanRow) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/plans', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    const rows = await all(
      `SELECT * FROM plans
       WHERE is_private = 0
       ORDER BY price ASC, id ASC`
    );
    return res.json({ plans: rows.map(mapPlanRow) });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/plans/buy', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    const planId = normalizePlanId(req.body?.planId);
    if (!planId) {
      return res.status(400).json({ error: 'invalid_plan' });
    }

    await run('BEGIN IMMEDIATE');
    const planRow = await get('SELECT * FROM plans WHERE id = ?', [planId]);
    if (!planRow) {
      await run('ROLLBACK');
      return res.status(404).json({ error: 'plan_not_found' });
    }
    const plan = mapPlanRow(planRow);
    if (plan.private) {
      await run('ROLLBACK');
      return res.status(403).json({ error: 'plan_private' });
    }
    if (plan.stock <= 0) {
      await run('ROLLBACK');
      return res.status(409).json({ error: 'out_of_stock' });
    }
    const user = await get(
      'SELECT id, balance FROM users WHERE id = ?',
      [req.session.userId]
    );
    if (!user) {
      await run('ROLLBACK');
      return res.status(401).json({ error: 'unauthorized' });
    }
    const balance = normalizeBalance(user.balance);
    if (balance < plan.price) {
      await run('ROLLBACK');
      return res.status(400).json({ error: 'insufficient_balance' });
    }

    const nextBalance = balance - plan.price;
    const nowIso = new Date().toISOString();
    const startedAt = nowIso;
    const expiresAt = computePlanExpiry(plan.expired);

    await run(
      'UPDATE users SET plan = ?, balance = ?, plan_started_at = ?, plan_expires_at = ? WHERE id = ?',
      [planId, nextBalance, startedAt, expiresAt, user.id]
    );
    await run(
      'UPDATE plans SET stock = ?, updated_at = ? WHERE id = ?',
      [plan.stock - 1, nowIso, planId]
    );
    await run('COMMIT');
    clearPlanCache();
    req.session.plan = plan.display;
    return res.json({
      ok: true,
      plan: plan.display,
      planId,
      planStartedAt: startedAt,
      planExpiresAt: expiresAt,
      balance: nextBalance,
    });
  } catch (error) {
    try {
      await run('ROLLBACK');
    } catch (rollbackError) {
      console.error('Plan purchase rollback error:', rollbackError);
    }
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/stats', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    const userRow = await get('SELECT COUNT(*) AS total FROM users');
    const totalClients = Number(userRow?.total) || 0;

    const occupancyMap = await getServerOccupancyMap();

    // Global cleanup and Calculate active runs
    const rows = await all('SELECT job_id, duration, duration_seconds, created_at FROM ongoing_runs');
    const now = Date.now();
    const expiredIds = [];
    let activeRuns = 0;

    for (const row of rows) {
      const storedSeconds = Number(row.duration_seconds);
      const durationSeconds = Number.isFinite(storedSeconds) && storedSeconds > 0
        ? storedSeconds
        : parseDurationSeconds(row.duration);
      
      const createdAtMs = Date.parse(row.created_at);
      const safeCreatedAt = Number.isFinite(createdAtMs) ? createdAtMs : now;
      const elapsed = Math.floor((now - safeCreatedAt) / 1000);

      if (elapsed < (durationSeconds || 0)) {
        activeRuns += 1;
      } else {
        expiredIds.push(row.job_id);
      }
    }

    if (expiredIds.length) {
      const placeholders = expiredIds.map(() => '?').join(',');
      await run(`DELETE FROM ongoing_runs WHERE job_id IN (${placeholders})`, expiredIds);
    }

    // Get all servers to include 0-count servers are included
    const allServers = await all('SELECT id, name, status, engine FROM servers');
    const serverUsage = allServers.map(s => ({
      name: s.name,
      status: s.status,
      maxEngine: s.engine,
      targets: occupancyMap[s.id] || 0
    }));

    const attackCountRow = await get("SELECT value FROM settings WHERE key = 'total_attacks_count'");
    const totalAttacksLegacy = await get("SELECT COUNT(*) AS total FROM logs_run");
    const totalAttacksPersistent = Number(attackCountRow?.value) || 0;
    const totalAttacks = Math.max(totalAttacksPersistent, Number(totalAttacksLegacy?.total) || 0);

    return res.json({ totalClients, activeRuns, totalAttacks, serverUsage });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/stats/history', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  try {
    const rows = await all('SELECT total_targets as targets, total_engine as engine, timestamp FROM usage_history ORDER BY id DESC LIMIT 48');
    return res.json(rows.reverse());
  } catch (e) {
    return res.status(500).json({ error: 'failed_to_fetch_history' });
  }
});

app.get('/api/engines/active', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    return res.json({ engines: [] });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/news', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    const rows = await all(
      `SELECT id, title, message, author, created_at
       FROM news
       ORDER BY datetime(created_at) DESC, id DESC
       LIMIT 10`
    );
    return res.json({
      items: rows.map((row) => ({
        id: row.id,
        title: row.title,
        message: row.message,
        author: row.author,
        createdAt: row.created_at,
      })),
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/attack', async (req, res) => {
  try {
    const keyInput = sanitize(req.query?.key || '');
    if (!keyInput) return res.status(401).json({ error: 'missing_key' });

    const keyRow = await get('SELECT * FROM api_keys WHERE api_key = ?', [keyInput]);
    if (!keyRow) return res.status(401).json({ error: 'invalid_key' });

    const clientIp = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress;
    let allowedIps = [];
    try { allowedIps = JSON.parse(keyRow.whitelist_ips || '[]'); } catch (e) { }
    if (allowedIps.length > 0 && !allowedIps.includes(clientIp)) {
      return res.status(401).json({ error: 'ip_not_whitelisted' });
    }

    const nowIso = new Date().toISOString();
    run('UPDATE api_keys SET last_ip = ?, last_used_at = ?, updated_at = ? WHERE id = ?', [clientIp, nowIso, nowIso, keyRow.id]).catch(() => { });

    const userId = keyRow.user_id;
    const planLimits = await resolvePlanLimitsForUser(userId);
    if (!planLimits.planId) {
      return res.status(403).json({ error: 'plan_required' });
    }

    const planCooldown = normalizePlanNumber(planLimits.plan?.cooldown, 0, 0);
    const cooldownResult = await checkUserCooldown(userId, planCooldown);
    if (!cooldownResult.ok) {
      return res.status(409).json({
        error: 'cooldown_active',
        remaining: cooldownResult.remaining,
      });
    }

    const methodInput = sanitize(req.query?.method).toLowerCase();
    if (!METHOD_HASH_REGEX.test(methodInput) && !METHOD_NAME_REGEX.test(methodInput)) {
      return res.status(400).json({ error: 'method_unavailable' });
    }

    let allowedMethods = [];
    try { allowedMethods = JSON.parse(keyRow.allowed_methods || '[]'); } catch (e) { }

    const target = normalizeRunTarget(req.query?.host || req.query?.target);
    if (!target) {
      return res.status(400).json({ error: 'invalid_target' });
    }
    const port = parseInt(req.query?.port, 10) || 0;
    const durationInput = normalizeRunDuration(req.query?.time || req.query?.duration);
    if (!durationInput) {
      return res.status(400).json({ error: 'invalid_duration' });
    }
    const durationSeconds = parseDurationSeconds(durationInput);
    if (!durationSeconds) {
      return res.status(400).json({ error: 'invalid_duration' });
    }
    const engineInput = req.query?.concurrent ?? req.query?.engine ?? 1;
    const engineRequested = Math.trunc(Number(engineInput));
    if (!Number.isFinite(engineRequested) || engineRequested < 1) {
      return res.status(400).json({ error: 'invalid_engine' });
    }

    const methodRow = await get(
      'SELECT * FROM methods WHERE (hash = ? OR name = ?) AND enabled = 1',
      [methodInput, methodInput]
    );
    if (!methodRow) {
      return res.status(409).json({ error: 'method_unavailable' });
    }
    const method = mapMethodRow(methodRow);

    if (allowedMethods.length > 0 && !allowedMethods.includes(method.hash) && !allowedMethods.includes(methodInput)) {
      return res.status(403).json({ error: 'method_not_allowed_by_key' });
    }

    if (!method.apiAccess) {
      return res.status(403).json({ error: 'method_not_allowed_via_api' });
    }

    const planAccess = planLimits.plan?.access || 'Basic';
    if (planAccess !== 'Premium' && method.access !== 'Basic') {
      return res.status(401).json({ error: 'requires_premium' });
    }

    if (method.layer === 'Layer 4' && (port <= 0 || port > 65535)) {
      return res.status(400).json({ error: 'invalid_port' });
    }

    const planMax = normalizePlanNumber(planLimits.maxTime, FALLBACK_USER_MAX_SECONDS, 1);
    const rawMethodMax = Number(method.maxDuration) || 0;
    const methodMax = rawMethodMax > 0 ? Math.min(planMax, rawMethodMax) : planMax;
    let maxSeconds = methodMax;

    const keyMaxTime = Number(keyRow.max_time) || 0;
    if (keyMaxTime > 0) {
      maxSeconds = Math.min(maxSeconds, keyMaxTime);
    }

    if (durationSeconds > maxSeconds) {
      return res.status(400).json({ error: 'duration_limit', maxSeconds });
    }

    const maxConc = normalizePlanNumber(planLimits.maxConc, 1, 1);
    const activeConc = await getUserActiveConcurrency(userId);
    let remainingConc = Math.max(0, maxConc - activeConc);

    const keyMaxEngine = Number(keyRow.max_engine) || 0;
    if (keyMaxEngine > 0) {
      remainingConc = Math.min(remainingConc, keyMaxEngine);
    }

    if (remainingConc <= 0) {
      return res.status(409).json({ error: 'concurrent_limit', remaining: 0, maxConc });
    }
    if (engineRequested > remainingConc) {
      return res.status(409).json({ error: 'concurrent_limit', remaining: remainingConc, maxConc });
    }

    const serverRows = await all(
      `SELECT id, name, api_url, duration_max, engine, methods, status, created_at, updated_at
       FROM servers WHERE status = 'Online' ORDER BY id ASC`
    );
    const servers = serverRows.map(mapServerRow).filter((server) => server && server.apiUrl);
    const supportedServers = servers.filter((server) => serverSupportsMethod(server, method.hash));
    if (!supportedServers.length) {
      return res.status(409).json({ error: 'method_unavailable' });
    }

    const durationServers = supportedServers.filter((server) => serverAllowsDuration(server, durationSeconds));
    if (!durationServers.length) {
      const maxServerDuration = supportedServers.reduce((max, server) => {
        const limit = normalizePlanNumber(server.durationMax, 0, 0);
        return Math.max(max, limit);
      }, 0);
      const durationLimit = maxServerDuration > 0 ? Math.min(maxSeconds, maxServerDuration) : maxSeconds;
      return res.status(400).json({ error: 'duration_limit', maxSeconds: durationLimit });
    }

    const totalEngine = durationServers.reduce((sum, server) => {
      return sum + normalizePlanNumber(server.engine, 1, 1);
    }, 0);
    const maxEngine = Math.min(remainingConc, totalEngine);
    if (engineRequested > maxEngine) {
      return res.status(409).json({ error: 'engine_busy', maxEngine });
    }

    const occupancyMap = await getServerOccupancyMap();
    const { assignments, remaining } = allocateServerEngines(
      durationServers,
      engineRequested,
      occupancyMap
    );
    if (remaining > 0) {
      const maxAvailableAcrossAll = durationServers.reduce((max, srv) => {
        const cap = normalizePlanNumber(srv.engine, 0, 0);
        const occ = occupancyMap[srv.id] || 0;
        return Math.max(max, cap - occ);
      }, 0);
      return res
        .status(409)
        .json({ error: 'engine_busy', maxEngine: maxAvailableAcrossAll });
    }

    const serverIds = Array.from(new Set(assignments.map((a) => a?.server?.id).filter((id) => Number.isInteger(id) && id > 0)));
    const methodLabel = normalizeMethodLabelForApi(method.name || method.display || method.hash);

    try {
      for (const assignment of assignments) {
        const server = assignment.server;
        for (let i = 0; i < assignment.count; i += 1) {
          const requestUrl = buildServerUrl(server.apiUrl, {
            target,
            port,
            durationSeconds,
            methodLabel,
          });
          if (!requestUrl) throw new Error(`invalid_server_url:${server.id}`);
          const result = await sendServerRequest(requestUrl);
          if (result.statusCode < 200 || result.statusCode >= 300) {
            throw new Error(`server_status_${result.statusCode}`);
          }
        }
      }
    } catch (dispatchError) {
      console.error('API Run dispatch failed:', dispatchError);
      return res.status(409).json({ error: 'engine_busy' });
    }

    const createdAt = new Date().toISOString();
    const jobId = generateToken();
    await run(
      `INSERT INTO ongoing_runs (user_id, job_id, method, target, port, duration, duration_seconds, engine, servers, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [userId, jobId, method.hash, target, port, durationInput, durationSeconds, engineRequested, JSON.stringify(serverIds), 'ongoing', createdAt]
    );
    await logAttack(userId, jobId, method.hash, target, port, durationInput, durationSeconds, engineRequested, 'success', createdAt);
    await trimOngoingRuns(userId);

    return res.json({ ok: true, message: 'Attack successfully dispatched', jobId, target, port, time: durationSeconds, method: method.hash });
  } catch (error) {
    console.error('API Attack Error:', error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/attack/ongoing', async (req, res) => {
  try {
    const keyInput = sanitize(req.query?.key || '');
    if (!keyInput) return res.status(401).json({ error: 'missing_key' });

    const keyRow = await get('SELECT * FROM api_keys WHERE api_key = ?', [keyInput]);
    if (!keyRow) return res.status(401).json({ error: 'invalid_key' });

    const clientIp = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress;
    let allowedIps = [];
    try { allowedIps = JSON.parse(keyRow.whitelist_ips || '[]'); } catch (e) { }
    if (allowedIps.length > 0 && !allowedIps.includes(clientIp)) {
      return res.status(401).json({ error: 'ip_not_whitelisted' });
    }

    const userId = keyRow.user_id;
    const rows = await all(
      `SELECT job_id, method, target, port, duration, duration_seconds, engine, status, created_at
       FROM ongoing_runs WHERE user_id = ? ORDER BY datetime(created_at) DESC`,
      [userId]
    );

    const now = Date.now();
    const runs = rows.map(row => {
      const createdAtMs = Date.parse(row.created_at);
      const durationSeconds = Number(row.duration_seconds) || 0;
      const elapsedSeconds = Math.max(0, Math.floor((now - createdAtMs) / 1000));
      const remainingSeconds = Math.max(0, durationSeconds - elapsedSeconds);

      return {
        jobId: row.job_id,
        target: row.target,
        port: row.port,
        method: row.method,
        duration: durationSeconds,
        elapsed: elapsedSeconds,
        remaining: remainingSeconds,
        engine: row.engine,
        status: row.status,
        createdAt: row.created_at
      };
    }).filter(r => r.remaining > 0);

    return res.json({ ok: true, runs });
  } catch (error) {
    console.error('API Ongoing Error:', error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/attack/stop', async (req, res) => {
  try {
    const keyInput = sanitize(req.query?.key || '');
    if (!keyInput) return res.status(401).json({ error: 'missing_key' });

    const keyRow = await get('SELECT * FROM api_keys WHERE api_key = ?', [keyInput]);
    if (!keyRow) return res.status(401).json({ error: 'invalid_key' });

    const jobId = sanitize(req.query?.jobId || req.query?.id || '');
    if (!jobId) return res.status(400).json({ error: 'missing_job_id' });

    const userId = keyRow.user_id;
    const row = await get(
      `SELECT job_id, method, target, port, duration, duration_seconds, engine, servers
       FROM ongoing_runs WHERE job_id = ? AND user_id = ?`,
      [jobId, userId]
    );
    if (!row) return res.status(404).json({ error: 'not_found' });

    const durationSeconds = Number(row.duration_seconds) || 0;
    const stopLabel = 'STOP';

    const serverRows = await all(`SELECT id, api_url FROM servers WHERE status = 'Online'`);
    const servers = serverRows.filter(s => s && s.api_url);
    const serverIds = [];
    try {
      const parsed = JSON.parse(row.servers);
      if (Array.isArray(parsed)) serverIds.push(...parsed);
    } catch (e) { }

    let stopServers = [];
    if (serverIds.length) {
      const idSet = new Set(serverIds.map(id => Number(id)));
      stopServers = servers.filter(s => idSet.has(Number(s.id)));
    }

    // Dispatch STOP
    for (const server of stopServers) {
      const requestUrl = buildServerUrl(server.api_url, {
        target: row.target,
        port: row.port,
        durationSeconds,
        methodLabel: stopLabel,
      });
      if (requestUrl) {
        sendServerRequest(requestUrl).catch(() => { });
      }
    }

    await run('DELETE FROM ongoing_runs WHERE job_id = ? AND user_id = ?', [jobId, userId]);
    return res.json({ ok: true, message: 'Attack stopped', jobId });
  } catch (error) {
    console.error('API Stop Error:', error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/run', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    const planLimits = await resolvePlanLimitsForUser(req.session.userId);
    if (!planLimits.planId) {
      return res.status(403).json({ error: 'plan_required' });
    }

    const planCooldown = normalizePlanNumber(planLimits.plan?.cooldown, 0, 0);
    const cooldownResult = await checkUserCooldown(req.session.userId, planCooldown);
    if (!cooldownResult.ok) {
      return res.status(409).json({
        error: 'cooldown_active',
        remaining: cooldownResult.remaining,
      });
    }
    const methodInput = sanitize(req.body?.method).toLowerCase();
    if (!METHOD_HASH_REGEX.test(methodInput) && !METHOD_NAME_REGEX.test(methodInput)) {
      return res.status(400).json({ error: 'method_unavailable' });
    }
    const target = normalizeRunTarget(req.body?.target);
    if (!target) {
      return res.status(400).json({ error: 'invalid_target' });
    }
    const port = parseInt(req.body?.port, 10) || 0;
    const durationInput = normalizeRunDuration(req.body?.duration);
    if (!durationInput) {
      return res.status(400).json({ error: 'invalid_duration' });
    }
    const durationSeconds = parseDurationSeconds(durationInput);
    console.log(`[DEBUG] Received durationInput: "${durationInput}", durationSeconds: ${durationSeconds}`);
    if (!durationSeconds) {
      return res.status(400).json({ error: 'invalid_duration' });
    }
    const engineInput = req.body?.concurrent ?? req.body?.engine;
    const engineRequested = Math.trunc(Number(engineInput));
    if (!Number.isFinite(engineRequested) || engineRequested < 1) {
      return res.status(400).json({ error: 'invalid_engine' });
    }

    const methodRow = await get(
      'SELECT * FROM methods WHERE (hash = ? OR name = ?) AND enabled = 1',
      [methodInput, methodInput]
    );
    if (!methodRow) {
      return res.status(409).json({ error: 'method_unavailable' });
    }
    const method = mapMethodRow(methodRow);
    const planAccess = planLimits.plan?.access || 'Basic';
    if (planAccess !== 'Premium' && method.access !== 'Basic') {
      return res.status(401).json({ error: 'requires_premium' });
    }

    if (method.layer === 'Layer 4' && (port <= 0 || port > 65535)) {
      return res.status(400).json({ error: 'invalid_port' });
    }

    const planMax = normalizePlanNumber(planLimits.maxTime, FALLBACK_USER_MAX_SECONDS, 1);
    const rawMethodMax = Number(method.maxDuration) || 0;
    const maxSeconds = rawMethodMax > 0 ? Math.min(planMax, rawMethodMax) : planMax;
    if (durationSeconds > maxSeconds) {
      return res
        .status(400)
        .json({ error: 'duration_limit', maxSeconds });
    }

    const maxConc = normalizePlanNumber(planLimits.maxConc, 1, 1);
    const activeConc = await getUserActiveConcurrency(req.session.userId);
    const remainingConc = Math.max(0, maxConc - activeConc);
    if (remainingConc <= 0) {
      return res
        .status(409)
        .json({ error: 'concurrent_limit', remaining: 0, maxConc });
    }
    if (engineRequested > remainingConc) {
      return res.status(409).json({
        error: 'concurrent_limit',
        remaining: remainingConc,
        maxConc,
      });
    }

    const serverRows = await all(
      `SELECT id, name, api_url, duration_max, engine, methods, status,
              created_at, updated_at
       FROM servers
       WHERE status = 'Online'
       ORDER BY id ASC`
    );
    const servers = serverRows
      .map(mapServerRow)
      .filter((server) => server && server.apiUrl);
    const supportedServers = servers.filter((server) =>
      serverSupportsMethod(server, method.hash)
    );
    if (!supportedServers.length) {
      return res.status(409).json({ error: 'method_unavailable' });
    }

    const durationServers = supportedServers.filter((server) =>
      serverAllowsDuration(server, durationSeconds)
    );
    if (!durationServers.length) {
      const maxServerDuration = supportedServers.reduce((max, server) => {
        const limit = normalizePlanNumber(server.durationMax, 0, 0);
        return Math.max(max, limit);
      }, 0);
      const durationLimit =
        maxServerDuration > 0 ? Math.min(maxSeconds, maxServerDuration) : maxSeconds;
      return res
        .status(400)
        .json({ error: 'duration_limit', maxSeconds: durationLimit });
    }

    const totalEngine = durationServers.reduce((sum, server) => {
      return sum + normalizePlanNumber(server.engine, 1, 1);
    }, 0);
    const maxEngine = Math.min(maxConc, totalEngine);
    if (engineRequested > maxEngine) {
      return res
        .status(409)
        .json({ error: 'engine_busy', maxEngine });
    }

    const occupancyMap = await getServerOccupancyMap();
    const { assignments, remaining } = allocateServerEngines(
      durationServers,
      engineRequested,
      occupancyMap
    );
    if (remaining > 0) {
      // In broadcast mode, this only fails if NO server can take ANY slots.
      // We calculate a generic "max" for friendly error reporting.
      const maxAvailableAcrossAll = durationServers.reduce((max, srv) => {
        const cap = normalizePlanNumber(srv.engine, 0, 0);
        const occ = occupancyMap[srv.id] || 0;
        return Math.max(max, cap - occ);
      }, 0);
      return res
        .status(409)
        .json({ error: 'engine_busy', maxEngine: maxAvailableAcrossAll });
    }

    const serverIds = Array.from(
      new Set(
        assignments
          .map((assignment) => assignment?.server?.id)
          .filter((id) => Number.isInteger(id) && id > 0)
      )
    );
    const methodLabel = normalizeMethodLabelForApi(
      method.name || method.display || method.hash
    );
    const successServerIds = [];
    const failedServerIds = [];
    let successCount = 0;
    let failCount = 0;

    for (const assignment of assignments) {
      const server = assignment.server;
      for (let i = 0; i < assignment.count; i += 1) {
        const requestUrl = buildServerUrl(server.apiUrl, {
          target,
          port,
          durationSeconds,
          methodLabel,
        });
        
        if (!requestUrl) {
          console.error(`[API RUN] Invalid URL for server ${server.id}`);
          failCount += 1;
          if (!failedServerIds.includes(server.id)) failedServerIds.push(server.id);
          continue;
        }

        try {
          const result = await sendServerRequest(requestUrl);
          if (result.statusCode >= 200 && result.statusCode < 300) {
            successCount += 1;
            if (!successServerIds.includes(server.id)) {
              successServerIds.push(server.id);
            }
          } else {
            throw new Error(`server_status_${result.statusCode}`);
          }
        } catch (dispatchError) {
          failCount += 1;
          if (!failedServerIds.includes(server.id)) {
            failedServerIds.push(server.id);
          }
          console.error(`[API RUN] Server ${server.id} dispatch failed:`, dispatchError.message);
        }
      }
    }

    if (successCount === 0) {
      return res.status(409).json({ 
        error: 'engine_busy', 
        details: 'all_servers_failed',
        failCount,
        failedServerIds
      });
    }

    const report = {
      success: successCount,
      failed: failCount,
      failedServerIds,
      total: successCount + failCount
    };

    const createdAt = new Date().toISOString();
    const jobId = generateToken();
    await run(
      `INSERT INTO ongoing_runs
       (user_id, job_id, method, target, port, duration, duration_seconds, engine, servers, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        req.session.userId,
        jobId,
        method.hash,
        target,
        port,
        durationInput,
        durationSeconds,
        engineRequested,
        JSON.stringify(successServerIds),
        'ongoing',
        createdAt,
      ]
    );
    await logAttack(req.session.userId, jobId, method.hash, target, port, durationInput, durationSeconds, engineRequested, 'success', createdAt);
    await trimOngoingRuns(req.session.userId);
    return res.json({ 
      ok: true, 
      jobId,
      report 
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/run/stop', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    const jobId = sanitize(req.body?.jobId);
    if (!jobId || !JOB_ID_REGEX.test(jobId)) {
      return res.status(400).json({ error: 'invalid_job' });
    }

    const row = await get(
      `SELECT job_id, method, target, port, duration, duration_seconds, engine, servers
       FROM ongoing_runs
       WHERE job_id = ? AND user_id = ?`,
      [jobId, req.session.userId]
    );
    if (!row) {
      return res.status(404).json({ error: 'not_found' });
    }

    const storedSeconds = Number(row.duration_seconds);
    const durationSeconds =
      Number.isFinite(storedSeconds) && storedSeconds > 0
        ? storedSeconds
        : parseDurationSeconds(row.duration);
    const stopLabel = 'STOP';
    const serverRows = await all(
      `SELECT id, name, api_url, duration_max, engine, methods, status,
              created_at, updated_at
       FROM servers
       WHERE status = 'Online'
       ORDER BY id ASC`
    );
    const servers = serverRows
      .map(mapServerRow)
      .filter((server) => server && server.apiUrl);
    const serverIds = parseServerIds(row.servers);
    let stopServers = [];
    if (serverIds.length) {
      const idSet = new Set(serverIds);
      stopServers = servers.filter((server) => idSet.has(server.id));
    }
    if (!stopServers.length) {
      stopServers = servers.filter((server) =>
        serverSupportsMethod(server, row.method)
      );
    }
    if (!stopServers.length) {
      return res.status(409).json({ error: 'method_unavailable' });
    }

    try {
      for (const server of stopServers) {
        const requestUrl = buildServerUrl(server.apiUrl, {
          target: row.target,
          port: row.port,
          durationSeconds,
          methodLabel: stopLabel,
        });
        if (!requestUrl) {
          throw new Error(`invalid_server_url:${server.id}`);
        }
        const result = await sendServerRequest(requestUrl);
        if (result.statusCode < 200 || result.statusCode >= 300) {
          throw new Error(`server_status_${result.statusCode}`);
        }
      }
    } catch (dispatchError) {
      console.error('Stop dispatch failed:', dispatchError);
      return res.status(409).json({ error: 'engine_busy' });
    }

    const result = await run(
      'DELETE FROM ongoing_runs WHERE job_id = ? AND user_id = ?',
      [jobId, req.session.userId]
    );
    if (Number(result?.changes) > 0) {
      return res.json({ ok: true });
    }
    return res.status(404).json({ error: 'not_found' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/run/ongoing', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    const rows = await all(
      `SELECT o.job_id, o.method, o.target, o.port, o.duration, o.duration_seconds,
              o.engine, o.status, o.created_at,
              m.display_name AS method_display, m.name AS method_name
       FROM ongoing_runs o
       LEFT JOIN methods m
         ON m.hash = o.method OR m.name = o.method
       WHERE o.user_id = ?
       ORDER BY datetime(o.created_at) DESC, o.id DESC
       LIMIT ?`,
      [req.session.userId, MAX_ONGOING_RUNS]
    );
    const now = Date.now();
    const expiredIds = [];
    const runs = [];

    for (const row of rows) {
      const storedSeconds = Number(row.duration_seconds);
      const computedSeconds = parseDurationSeconds(row.duration);
      const durationSeconds =
        Number.isFinite(storedSeconds) && storedSeconds > 0
          ? storedSeconds
          : computedSeconds;
      if (
        (!Number.isFinite(storedSeconds) || storedSeconds <= 0) &&
        durationSeconds > 0
      ) {
        run('UPDATE ongoing_runs SET duration_seconds = ? WHERE job_id = ?', [
          durationSeconds,
          row.job_id,
        ]).catch((error) => console.error(error));
      }

      const createdAtMs = Date.parse(row.created_at);
      const safeCreatedAt = Number.isFinite(createdAtMs) ? createdAtMs : now;
      const elapsedSeconds = Math.max(
        0,
        Math.floor((now - safeCreatedAt) / 1000)
      );
      const remainingSeconds = Math.max(
        0,
        (durationSeconds || 0) - elapsedSeconds
      );
      if (remainingSeconds <= 0) {
        expiredIds.push(row.job_id);
        continue;
      }

      const displayLabel =
        normalizeMethodDisplay(row.method_display) ||
        row.method_name ||
        row.method;
      runs.push({
        id: row.job_id,
        method: row.method,
        methodLabel: row.method_name || row.method,
        methodDisplay: String(row.method_display || row.method),
        target: row.target,
        port: row.port || 0,
        duration: row.duration,
        durationSeconds: durationSeconds || 0,
        remainingSeconds,
        engine: row.engine,
        status: row.status,
        createdAt: row.created_at,
        expiresAt: new Date(
          safeCreatedAt + (durationSeconds || 0) * 1000
        ).toISOString(),
      });
    }

    if (expiredIds.length) {
      const placeholders = expiredIds.map(() => '?').join(',');
      await run(
        `DELETE FROM ongoing_runs WHERE job_id IN (${placeholders})`,
        expiredIds
      );
    }
    return res.json({ runs });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/run/method', async (req, res) => {
  try {
    let userId = req.session?.userId || null;
    const planLimits = await resolvePlanLimitsForUser(userId);
    const planRequired = !planLimits.planId;
    const planAccess = planLimits.plan?.access || 'Basic';
    const maxConc = planRequired
      ? 0
      : normalizePlanNumber(planLimits.maxConc, 1, 1);
    const activeConc = planRequired
      ? 0
      : await getUserActiveConcurrency(userId);
    const remainingConc = Math.max(0, maxConc - activeConc);
    const serverRows = await all(
      `SELECT id, name, api_url, duration_max, engine, methods, status,
              created_at, updated_at
       FROM servers
       WHERE status = 'Online'
       ORDER BY id ASC`
    );
    const servers = serverRows
      .map(mapServerRow)
      .filter((server) => server && server.apiUrl);
    const rows = await all(
      `SELECT id, hash, name, display_name, access_level, api_access, layer, enabled
       FROM methods
       WHERE enabled = 1
       ORDER BY name ASC, id ASC`
    );
    const methods = rows
      .map(mapMethodRow)
      .map((method) => {
        if (!method) return null;
        let isAllowed = false;
        if (!planRequired) {
          isAllowed = planAccess === 'Premium' ? true : method.access === 'Basic';
        }
        return {
          ...method,
          isAllowed,
        };
      })
      .filter(Boolean)
      .map((method) => ({
        value: method.hash,
        label: method.display,
        access: method.access,
        apiAccess: method.apiAccess,
        layer: method.layer,
        isAllowed: method.isAllowed,
        engineMax: maxConc,
      }));
    const maxAvailable = maxConc;
    return res.json({
      options: methods,
      connections: maxAvailable,
      available: maxAvailable,
      planRequired,
      maxConc,
      remainingConc,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/methods', async (req, res) => {
  try {
    const rows = await all(
      'SELECT id, display_name as display, description, layer FROM methods WHERE enabled = 1 ORDER BY name ASC'
    );
    return res.json({ methods: rows });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.get('/api/login-history', async (req, res) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'unauthorized' });
  }

  try {
    await trimLoginHistory(req.session.userId);
    const history = await all(
      `SELECT id, ip_address, user_agent, locale, created_at
       FROM login_history
       WHERE user_id = ?
       ORDER BY datetime(created_at) DESC, id DESC
       LIMIT ?`,
      [req.session.userId, MAX_LOGIN_HISTORY]
    );

    return res.json({ history });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'server_error' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: 'logout_failed' });
    }
    res.clearCookie('sid');
    return res.json({ ok: true });
  });
});

if (hasFrontendDist) {
  app.use(express.static(FRONTEND_DIST));
  app.get('*', (req, res, next) => {
    if (/^\/api(\/|$)/.test(req.path)) {
      return next();
    }
    return res.sendFile(path.join(FRONTEND_DIST, 'index.html'));
  });
}

app.use((req, res) => {
  res.status(404).json({ error: 'not_found' });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'server_error' });
});

startup.then(() => {
  app.listen(PORT, () => {
    console.log(`Auth API listening on port ${PORT}`);
  });
});
