const sqlite3 = require('sqlite3').verbose();
const {
  DB_PATH,
  DEFAULT_BALANCE,
  FALLBACK_USER_MAX_SECONDS,
  FALLBACK_METHOD_MAX_SECONDS,
  SETTINGS_KEY_DEFAULT_USER_MAX,
  SETTINGS_KEY_DEFAULT_METHOD_MAX,
  DEFAULT_NEWS_TITLE,
  DEFAULT_NEWS_MESSAGE,
  DEFAULT_NEWS_AUTHOR,
} = require('./config');
const { generateToken, generateUniqCode } = require('./lib/crypto');

const db = new sqlite3.Database(DB_PATH);

const run = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.run(sql, params, function onRun(err) {
      if (err) {
        reject(err);
        return;
      }
      resolve(this);
    });
  });

const get = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(row);
    });
  });

const all = (sql, params = []) =>
  new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(rows);
    });
  });

const settingsCache = new Map();

const normalizeSettingNumber = (value, fallback) => {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) return fallback;
  return Math.trunc(parsed);
};

const getSettingNumber = async (key, fallback) => {
  if (!key) return fallback;
  if (settingsCache.has(key)) {
    return settingsCache.get(key);
  }
  try {
    const row = await get('SELECT value FROM settings WHERE key = ?', [key]);
    const normalized = normalizeSettingNumber(row?.value, fallback);
    settingsCache.set(key, normalized);
    return normalized;
  } catch (error) {
    console.error('Settings lookup error:', error);
    return fallback;
  }
};

const getDefaultUserMaxSeconds = async () =>
  getSettingNumber(SETTINGS_KEY_DEFAULT_USER_MAX, FALLBACK_USER_MAX_SECONDS);

const getDefaultMethodMaxSeconds = async () =>
  getSettingNumber(SETTINGS_KEY_DEFAULT_METHOD_MAX, FALLBACK_METHOD_MAX_SECONDS);

const addColumnIfMissing = async (table, column, definition) => {
  const info = await all(`PRAGMA table_info(${table})`);
  const exists = Array.isArray(info)
    ? info.some((col) => col.name === column)
    : false;
  if (!exists) {
    await run(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
};

const generateUniqueToken = async () => {
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const token = generateToken();
    const existing = await get('SELECT id FROM users WHERE token = ?', [token]);
    if (!existing) {
      return token;
    }
  }
  throw new Error('Unable to generate unique token');
};

const generateUniqueUniqCode = async () => {
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const uniqCode = generateUniqCode();
    const existing = await get('SELECT id FROM users WHERE uniq_code = ?', [
      uniqCode,
    ]);
    if (!existing) {
      return uniqCode;
    }
  }
  throw new Error('Unable to generate unique uniq_code');
};

const initDb = () =>
  new Promise((resolve) => {
    db.serialize(() => {
      db.run('PRAGMA foreign_keys = ON');
      db.run(
        `CREATE TABLE IF NOT EXISTS settings (
          key TEXT PRIMARY KEY,
          value TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )`
      );
      const settingsSeededAt = new Date().toISOString();
      [
        [SETTINGS_KEY_DEFAULT_USER_MAX, String(FALLBACK_USER_MAX_SECONDS)],
        [SETTINGS_KEY_DEFAULT_METHOD_MAX, String(FALLBACK_METHOD_MAX_SECONDS)],
      ].forEach(([key, value]) => {
        db.run(
          'INSERT OR IGNORE INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
          [key, value, settingsSeededAt]
        );
      });
      db.run(
        `CREATE TABLE IF NOT EXISTS users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          username TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          telegram_chat_id TEXT NOT NULL,
          twofa_enabled INTEGER NOT NULL DEFAULT 0,
          otp_send_count INTEGER NOT NULL DEFAULT 0,
          otp_send_day TEXT,
          otp_last_sent_at TEXT,
          plan TEXT NOT NULL DEFAULT '',
          role TEXT NOT NULL DEFAULT 'user',
          is_admin INTEGER NOT NULL DEFAULT 0,
          verified INTEGER NOT NULL DEFAULT 0,
          balance INTEGER NOT NULL DEFAULT ${DEFAULT_BALANCE} CHECK(balance >= 0),
          plan_started_at TEXT,
          plan_expires_at TEXT,
          token TEXT NOT NULL UNIQUE,
          uniq_code TEXT NOT NULL UNIQUE,
          created_at TEXT NOT NULL
        )`
      );

      db.run(
        `CREATE UNIQUE INDEX IF NOT EXISTS idx_users_telegram_chat_id
         ON users (telegram_chat_id)
         WHERE telegram_chat_id <> ''`,
        (err) => {
          if (err) {
            console.error('Unable to create telegram chat id index:', err);
          }
        }
      );

      db.run(
        `CREATE TABLE IF NOT EXISTS login_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          ip_address TEXT NOT NULL,
          user_agent TEXT NOT NULL,
          locale TEXT NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )`
      );

      db.run(
        `CREATE INDEX IF NOT EXISTS idx_login_history_user
         ON login_history (user_id, created_at)`
      );

      db.run(
        `CREATE TABLE IF NOT EXISTS news (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          author TEXT NOT NULL,
          created_at TEXT NOT NULL
        )`
      );

      db.run(
        `CREATE INDEX IF NOT EXISTS idx_news_created_at
         ON news (created_at)`
      );

      addColumnIfMissing(
        'users',
        'twofa_enabled',
        'INTEGER NOT NULL DEFAULT 0'
      ).catch((err) => console.error(err));
      addColumnIfMissing(
        'users',
        'otp_send_count',
        'INTEGER NOT NULL DEFAULT 0'
      ).catch((err) => console.error(err));
      addColumnIfMissing('users', 'otp_send_day', 'TEXT').catch((err) =>
        console.error(err)
      );
      addColumnIfMissing('users', 'otp_last_sent_at', 'TEXT').catch((err) =>
        console.error(err)
      );

      db.get('SELECT COUNT(*) AS total FROM news', (err, row) => {
        if (err) {
          console.error(err);
          return;
        }
        const total = Number(row?.total) || 0;
        if (total === 0) {
          db.run(
            'INSERT INTO news (title, message, author, created_at) VALUES (?, ?, ?, ?)',
            [
              DEFAULT_NEWS_TITLE,
              DEFAULT_NEWS_MESSAGE,
              DEFAULT_NEWS_AUTHOR,
              new Date().toISOString(),
            ]
          );
        }
      });

      db.run(
        `CREATE TABLE IF NOT EXISTS methods (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          hash TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          display_name TEXT NOT NULL DEFAULT '',
          description TEXT NOT NULL DEFAULT '',
          max_duration_seconds INTEGER NOT NULL DEFAULT ${FALLBACK_METHOD_MAX_SECONDS},
          exclusive_host INTEGER NOT NULL DEFAULT 0,
          enabled INTEGER NOT NULL DEFAULT 1,
          access_level TEXT NOT NULL DEFAULT 'Basic',
          api_access INTEGER NOT NULL DEFAULT 0,
          layer TEXT NOT NULL DEFAULT 'Layer 7',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )`
      );

      db.run(
        `CREATE TABLE IF NOT EXISTS servers (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          api_url TEXT NOT NULL,
          duration_max INTEGER NOT NULL DEFAULT 0,
          engine INTEGER NOT NULL DEFAULT 1,
          methods TEXT NOT NULL DEFAULT '[]',
          status TEXT NOT NULL DEFAULT 'Offline',
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )`
      );

      db.run(
        `CREATE INDEX IF NOT EXISTS idx_servers_status
         ON servers (status)`
      );

      db.run(
        `CREATE TABLE IF NOT EXISTS usage_history (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          total_engine INTEGER NOT NULL,
          total_targets INTEGER NOT NULL,
          timestamp TEXT NOT NULL
        )`
      );

      db.run(
        `CREATE TABLE IF NOT EXISTS plans (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL UNIQUE,
          display_name TEXT NOT NULL,
          time_seconds INTEGER NOT NULL DEFAULT ${FALLBACK_USER_MAX_SECONDS},
          conc INTEGER NOT NULL DEFAULT 1,
          api_access INTEGER NOT NULL DEFAULT 0,
          expired_days INTEGER NOT NULL DEFAULT 0,
          stock INTEGER NOT NULL DEFAULT 0,
          access_level TEXT NOT NULL DEFAULT 'Basic',
          is_private INTEGER NOT NULL DEFAULT 0,
          price INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        )`
      );

      db.run(
        `CREATE INDEX IF NOT EXISTS idx_plans_private
         ON plans (is_private)`
      );

      db.run(
        `CREATE UNIQUE INDEX IF NOT EXISTS idx_methods_name
         ON methods (name)`
      );

      db.run(
        `CREATE INDEX IF NOT EXISTS idx_methods_enabled
         ON methods (enabled)`
      );

      db.all('PRAGMA table_info(methods)', (err, rows) => {
        if (err) {
          console.error(err);
          return;
        }
        const hasDisplayName = rows.some(
          (row) => row.name === 'display_name'
        );
        const hasExclusiveHost = rows.some(
          (row) => row.name === 'exclusive_host'
        );
        const hasAccessLevel = rows.some(
          (row) => row.name === 'access_level'
        );
        const hasApiAccess = rows.some(
          (row) => row.name === 'api_access'
        );
        const hasLayer = rows.some(
          (row) => row.name === 'layer'
        );
        const hasDescription = rows.some(
          (row) => row.name === 'description'
        );
        if (!hasDisplayName) {
          db.run(
            'ALTER TABLE methods ADD COLUMN display_name TEXT NOT NULL DEFAULT ""'
          );
        }
        if (!hasExclusiveHost) {
          db.run('ALTER TABLE methods ADD COLUMN exclusive_host INTEGER NOT NULL DEFAULT 0');
        }
        if (!hasAccessLevel) {
          db.run(
            "ALTER TABLE methods ADD COLUMN access_level TEXT NOT NULL DEFAULT 'Basic'"
          );
        }
        if (!hasApiAccess) {
          db.run(
            'ALTER TABLE methods ADD COLUMN api_access INTEGER NOT NULL DEFAULT 0'
          );
        }
        if (!hasLayer) {
          db.run(
            "ALTER TABLE methods ADD COLUMN layer TEXT NOT NULL DEFAULT 'Layer 7'"
          );
        }
        if (!hasDescription) {
          db.run(
            "ALTER TABLE methods ADD COLUMN description TEXT NOT NULL DEFAULT ''"
          );
        }
      });

      db.run(
        `CREATE TABLE IF NOT EXISTS ongoing_runs (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          job_id TEXT NOT NULL UNIQUE,
          method TEXT NOT NULL,
          target TEXT NOT NULL,
          port INTEGER NOT NULL DEFAULT 0,
          duration TEXT NOT NULL,
          duration_seconds INTEGER NOT NULL DEFAULT 0,
          engine INTEGER NOT NULL,
          servers TEXT NOT NULL DEFAULT '[]',
          status TEXT NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )`
      );

      db.run(
        `CREATE TABLE IF NOT EXISTS logs_run (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          job_id TEXT NOT NULL UNIQUE,
          method TEXT NOT NULL,
          target TEXT NOT NULL,
          port INTEGER NOT NULL DEFAULT 0,
          duration TEXT NOT NULL,
          duration_seconds INTEGER NOT NULL DEFAULT 0,
          engine INTEGER NOT NULL,
          status TEXT NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )`
      );

      db.run(
        `CREATE INDEX IF NOT EXISTS idx_ongoing_runs_user
         ON ongoing_runs (user_id, created_at)`
      );

      db.run(
        `CREATE INDEX IF NOT EXISTS idx_logs_run_user
         ON logs_run (user_id, created_at)`
      );

      db.all('PRAGMA table_info(ongoing_runs)', (err, rows) => {
        if (err) {
          console.error(err);
          return;
        }
        const hasDurationSeconds = rows.some(
          (row) => row.name === 'duration_seconds'
        );
        const hasServers = rows.some((row) => row.name === 'servers');
        const hasPort = rows.some((row) => row.name === 'port');
        if (!hasDurationSeconds) {
          db.run('ALTER TABLE ongoing_runs ADD COLUMN duration_seconds INTEGER');
        }
        if (!hasServers) {
          db.run('ALTER TABLE ongoing_runs ADD COLUMN servers TEXT NOT NULL DEFAULT "[]"');
        }
        if (!hasPort) {
          db.run('ALTER TABLE ongoing_runs ADD COLUMN port INTEGER NOT NULL DEFAULT 0');
        }
      });

      db.run(
        `CREATE TABLE IF NOT EXISTS api_keys (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL,
          api_key TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          whitelist_ips TEXT NOT NULL DEFAULT '[]',
          auto_bind INTEGER NOT NULL DEFAULT 0,
          allowed_methods TEXT NOT NULL DEFAULT '[]',
          max_time INTEGER DEFAULT 0,
          max_engine INTEGER DEFAULT 0,
          last_ip TEXT,
          last_used_at TEXT,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )`
      );

      addColumnIfMissing('logs_run', 'port', 'INTEGER NOT NULL DEFAULT 0').catch(err => console.error(err));

      db.all('PRAGMA table_info(users)', (err, rows) => {
        if (err) {
          console.error(err);
          return;
        }
        const hasPlan = rows.some((row) => row.name === 'plan');
        const hasToken = rows.some((row) => row.name === 'token');
        const hasUniqCode = rows.some((row) => row.name === 'uniq_code');
        const hasBalance = rows.some((row) => row.name === 'balance');
        const hasPlanStartedAt = rows.some(
          (row) => row.name === 'plan_started_at'
        );
        const hasPlanExpiresAt = rows.some(
          (row) => row.name === 'plan_expires_at'
        );
        const hasRole = rows.some((row) => row.name === 'role');
        const hasIsAdmin = rows.some((row) => row.name === 'is_admin');
        const hasVerified = rows.some((row) => row.name === 'verified');

        const ensurePlan = () => {
          db.run('UPDATE users SET plan = ? WHERE plan IS NULL', ['']);
        };

        const ensureTokens = () => {
          db.run(
            'CREATE UNIQUE INDEX IF NOT EXISTS idx_users_token ON users(token)'
          );
          db.all(
            'SELECT id FROM users WHERE token IS NULL OR token = ""',
            (selectErr, users) => {
              if (selectErr) {
                console.error(selectErr);
                return;
              }
              users.forEach((userRow) => {
                generateUniqueToken()
                  .then((token) => {
                    db.run(
                      'UPDATE users SET token = ? WHERE id = ? AND (token IS NULL OR token = "")',
                      [token, userRow.id],
                      (updateErr) => {
                        if (updateErr) {
                          console.error(updateErr);
                        }
                      }
                    );
                  })
                  .catch((tokenErr) => {
                    console.error(tokenErr);
                  });
              });
            }
          );
        };

        const ensureBalance = () => {
          db.run(
            'UPDATE users SET balance = ? WHERE balance IS NULL OR balance = "" OR balance < 0',
            [DEFAULT_BALANCE]
          );
        };
        const ensureRole = () => {
          db.run(
            "UPDATE users SET role = 'user' WHERE role IS NULL OR role = ''"
          );
        };

        const ensureIsAdmin = () => {
          db.run(
            'UPDATE users SET is_admin = 0 WHERE is_admin IS NULL OR is_admin = ""'
          );
        };
        const ensureVerified = () => {
          db.run(
            'UPDATE users SET verified = 0 WHERE verified IS NULL OR verified = ""'
          );
        };

        const ensureUniqCodes = () => {
          db.run(
            'CREATE UNIQUE INDEX IF NOT EXISTS idx_users_uniq_code ON users(uniq_code)'
          );
          db.all(
            'SELECT id FROM users WHERE uniq_code IS NULL OR uniq_code = ""',
            (selectErr, users) => {
              if (selectErr) {
                console.error(selectErr);
                return;
              }
              users.forEach((userRow) => {
                generateUniqueUniqCode()
                  .then((uniqCode) => {
                    db.run(
                      'UPDATE users SET uniq_code = ? WHERE id = ? AND (uniq_code IS NULL OR uniq_code = "")',
                      [uniqCode, userRow.id],
                      (updateErr) => {
                        if (updateErr) {
                          console.error(updateErr);
                        }
                      }
                    );
                  })
                  .catch((codeErr) => {
                    console.error(codeErr);
                  });
              });
            }
          );
        };

        if (!hasPlan) {
          db.run(
            "ALTER TABLE users ADD COLUMN plan TEXT NOT NULL DEFAULT ''",
            (alterErr) => {
              if (alterErr) {
                console.error(alterErr);
                return;
              }
              ensurePlan();
            }
          );
        } else {
          ensurePlan();
        }

        if (!hasToken) {
          db.run('ALTER TABLE users ADD COLUMN token TEXT', (alterErr) => {
            if (alterErr) {
              console.error(alterErr);
              return;
            }
            ensureTokens();
          });
        } else {
          ensureTokens();
        }

        if (!hasUniqCode) {
          db.run('ALTER TABLE users ADD COLUMN uniq_code TEXT', (alterErr) => {
            if (alterErr) {
              console.error(alterErr);
              return;
            }
            ensureUniqCodes();
          });
        } else {
          ensureUniqCodes();
        }

        if (!hasBalance) {
          db.run(
            `ALTER TABLE users ADD COLUMN balance INTEGER NOT NULL DEFAULT ${DEFAULT_BALANCE}`,
            (alterErr) => {
              if (alterErr) {
                console.error(alterErr);
                return;
              }
              ensureBalance();
            }
          );
        } else {
          ensureBalance();
        }

        if (!hasPlanStartedAt) {
          db.run('ALTER TABLE users ADD COLUMN plan_started_at TEXT');
        }

        if (!hasPlanExpiresAt) {
          db.run('ALTER TABLE users ADD COLUMN plan_expires_at TEXT');
        }

        if (!hasRole) {
          db.run(
            "ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'",
            (alterErr) => {
              if (alterErr) {
                console.error(alterErr);
                return;
              }
              ensureRole();
            }
          );
        } else {
          ensureRole();
        }

        if (!hasIsAdmin) {
          db.run(
            'ALTER TABLE users ADD COLUMN is_admin INTEGER NOT NULL DEFAULT 0',
            (alterErr) => {
              if (alterErr) {
                console.error(alterErr);
                return;
              }
              ensureIsAdmin();
            }
          );
        } else {
          ensureIsAdmin();
        }

        if (!hasVerified) {
          db.run(
            'ALTER TABLE users ADD COLUMN verified INTEGER NOT NULL DEFAULT 0',
            (alterErr) => {
              if (alterErr) {
                console.error(alterErr);
                return;
              }
              ensureVerified();
            }
          );
        } else {
          ensureVerified();
        }
      });
      db.get('SELECT 1', (finalErr) => {
        if (finalErr) {
          console.error('DB init finalize error:', finalErr);
        }
        resolve();
      });
    });
  });

module.exports = {
  db,
  run,
  get,
  all,
  initDb,
  addColumnIfMissing,
  getSettingNumber,
  getDefaultUserMaxSeconds,
  getDefaultMethodMaxSeconds,
  generateUniqueToken,
  generateUniqueUniqCode,
};
