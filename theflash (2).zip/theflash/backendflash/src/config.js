const path = require('path');
const dotenv = require('dotenv');
dotenv.config();

const ROOT_DIR = path.resolve(__dirname, '..');

const PORT = process.env.PORT || 4000;
const CLIENT_ORIGIN = process.env.CLIENT_ORIGIN || 'http://localhost:5173';
const SESSION_SECRET =
  process.env.SESSION_SECRET || 'dev-insecure-secret-change-me';
const DB_PATH =
  process.env.DB_PATH || path.join(ROOT_DIR, 'data', 'auth.sqlite');
const DEFAULT_PLAN = 'Starter Plan';
const MAX_LOGIN_HISTORY = 10;
const MAX_ONGOING_RUNS = 50;
const DEFAULT_BALANCE = 0;
const TOKEN_BYTES = 16;
const UNIQ_CODE_BYTES = 6;
const DELETE_DELAY_MS = 1200;
const METHOD_TTL_MS =
  (Number(process.env.SIMATRIX_METHOD_TTL_SECONDS) || 60) * 1000;
const RUN_QUEUE_TTL_MS =
  (Number(process.env.SIMATRIX_RUN_TTL_SECONDS) || 120) * 1000;
const JOB_TOKEN_TTL_MS =
  (Number(process.env.SIMATRIX_JOB_TOKEN_TTL_SECONDS) || 30) * 1000;
const RUN_TARGET_MAX = 200;
const RUN_DURATION_MAX = 64;
const FALLBACK_METHOD_MAX_SECONDS = 0;
const FALLBACK_USER_MAX_SECONDS = 600;
const SETTINGS_KEY_DEFAULT_USER_MAX = 'default_user_max_seconds';
const SETTINGS_KEY_DEFAULT_METHOD_MAX = 'default_method_max_seconds';
const DEFAULT_NEWS_TITLE = 'Wellcome';
const DEFAULT_NEWS_MESSAGE = 'Wellcome new stresser.cloud';
const DEFAULT_NEWS_AUTHOR = 'Stressercloud';
const METHOD_SCOPE_UNIQ = 'uniq';
const MAX_METHODS_PER_SYNC = 50;
const FRONTEND_DIST =
  process.env.FRONTEND_DIST || path.join(ROOT_DIR, '..', 'frontend', 'dist');
const CDN_SECRET = String(process.env.CDN_SECRET || '').trim();
const CDN_ROUTE = (() => {
  const raw = String(process.env.CDN_ROUTE || '/cdn-ctf').trim();
  if (!raw) return '/cdn-ctf';
  const normalized = raw.startsWith('/') ? raw : `/${raw}`;
  return normalized.replace(/\/+$/, '');
})();
const CDN_DIR = process.env.CDN_DIR || path.join(ROOT_DIR, 'cdn');
const USERNAME_REGEX = /^[a-zA-Z0-9_]{3,32}$/;
const CAPTCHA_REGEX = /^[A-Z0-9]{6}$/i;
const METHOD_HASH_REGEX = /^[a-f0-9]{8,64}$/i;
const METHOD_NAME_REGEX = /^[a-z0-9-]{3,64}$/i;
const METHOD_LABEL_REGEX = /^[A-Za-z0-9 _().:+-]{1,64}$/;
const TARGET_REGEX =
  /^[A-Za-z0-9\-._~:/?#\[\]@!$&'()*+,;=%]{3,200}$/;
const DURATION_REGEX = /^[A-Za-z0-9 .:+-]{1,64}$/;
const CLIENT_ID_REGEX = /^[A-Za-z0-9._-]{1,64}$/;
const JOB_ID_REGEX = /^[a-f0-9-]{12,64}$/i;
const JOB_TOKEN_REGEX = /^[a-f0-9]{32}$/i;
const UNSAFE_TEXT_REGEX = /<|>|javascript:|on\w+\s*=/i;
const TOKEN_REGEX = /^[a-f0-9]{32}$/i;
const UNIQ_CODE_REGEX = /^[a-f0-9]{12}$/i;

module.exports = {
  ROOT_DIR,
  PORT,
  CLIENT_ORIGIN,
  SESSION_SECRET,
  DB_PATH,
  DEFAULT_PLAN,
  MAX_LOGIN_HISTORY,
  MAX_ONGOING_RUNS,
  DEFAULT_BALANCE,
  TOKEN_BYTES,
  UNIQ_CODE_BYTES,
  DELETE_DELAY_MS,
  METHOD_TTL_MS,
  RUN_QUEUE_TTL_MS,
  JOB_TOKEN_TTL_MS,
  RUN_TARGET_MAX,
  RUN_DURATION_MAX,
  FALLBACK_METHOD_MAX_SECONDS,
  FALLBACK_USER_MAX_SECONDS,
  SETTINGS_KEY_DEFAULT_USER_MAX,
  SETTINGS_KEY_DEFAULT_METHOD_MAX,
  DEFAULT_NEWS_TITLE,
  DEFAULT_NEWS_MESSAGE,
  DEFAULT_NEWS_AUTHOR,
  METHOD_SCOPE_UNIQ,
  MAX_METHODS_PER_SYNC,
  FRONTEND_DIST,
  CDN_SECRET,
  CDN_ROUTE,
  CDN_DIR,
  USERNAME_REGEX,
  CAPTCHA_REGEX,
  METHOD_HASH_REGEX,
  METHOD_NAME_REGEX,
  METHOD_LABEL_REGEX,
  TARGET_REGEX,
  DURATION_REGEX,
  CLIENT_ID_REGEX,
  JOB_ID_REGEX,
  JOB_TOKEN_REGEX,
  UNSAFE_TEXT_REGEX,
  TOKEN_REGEX,
  UNIQ_CODE_REGEX,
};
