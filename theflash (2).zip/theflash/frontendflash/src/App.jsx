import { Fragment, useCallback, useEffect, useRef, useState } from 'react';
import {
  BrowserRouter,
  Link,
  Navigate,
  NavLink,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
} from 'react-router-dom';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Captcha from './components/Captcha.jsx';
import profileImage from './assets/p_37007v8g41.jpg';
import altProfileImage from './assets/p_370039aug1.jpg';
import bgVideo from './assets/m_37000vyto1.mp4';
import {
  Zap,
  Shield,
  Activity,
  Terminal,
  ArrowRight,
  Check,
  Globe,
  Lock,
  Settings,
  Layers,
  Cpu,
  ExternalLink,
  AlertTriangle,
  ShoppingCart,
  Headphones,
  FileSearch,
  LogOut
} from 'lucide-react';

const API_BASE = import.meta.env.VITE_API_BASE || '';
const MENU_QUERY = '(min-width: 960px)';
const TITLE_BASE = 'TheFlash';

const getPageTitle = (pathname) => {
  if (!pathname || pathname === '/') return `${TITLE_BASE} - Home`;
  if (pathname === '/login') return `${TITLE_BASE} - Login`;
  if (pathname === '/register') return `${TITLE_BASE} - Register`;
  if (pathname === '/home') return `${TITLE_BASE} - Home`;
  if (pathname === '/panel') return `${TITLE_BASE} - Panel`;
  if (pathname === '/api-manager') return `${TITLE_BASE} - API Manager`;
  if (pathname === '/admin' || pathname === '/admin/users') {
    return `${TITLE_BASE} - Admin`;
  }
  if (pathname.startsWith('/admin/users/')) {
    return `${TITLE_BASE} - Admin User`;
  }
  if (pathname === '/admin/plans') {
    return `${TITLE_BASE} - Admin Plans`;
  }
  if (pathname === '/admin/servers') {
    return `${TITLE_BASE} - Admin Servers`;
  }
  if (pathname === '/admin/methods') {
    return `${TITLE_BASE} - Admin Methods`;
  }
  if (pathname === '/admin/news') {
    return `${TITLE_BASE} - Admin News`;
  }
  if (pathname.startsWith('/admin/plans/')) {
    return `${TITLE_BASE} - Admin Plan`;
  }
  if (pathname.startsWith('/admin/servers/')) {
    return `${TITLE_BASE} - Admin Server`;
  }
  if (pathname === '/api-manager') return `${TITLE_BASE} - API Manager`;
  if (pathname === '/shop') return `${TITLE_BASE} - Plan`;
  if (pathname === '/profile') return `${TITLE_BASE} - Profile`;
  if (pathname === '/methods') return `${TITLE_BASE} - Method List`;
  return TITLE_BASE;
};

const getInitialMenuOpen = () => {
  if (typeof window === 'undefined') return false;
  return window.matchMedia?.(MENU_QUERY).matches ?? false;
};

const getInitialTheme = () => 'dark';

function AppShell() {
  const [menuOpen, setMenuOpen] = useState(getInitialMenuOpen);
  const [isDesktopMenu, setIsDesktopMenu] = useState(getInitialMenuOpen);
  const [theme, setTheme] = useState(getInitialTheme);
  const [user, setUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [toast, setToast] = useState(null);
  const [menuTooltip, setMenuTooltip] = useState(null);
  const [adminMenuOpen, setAdminMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const tooltipTimerRef = useRef(null);
  const adminMenuRef = useRef(null);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => {
    let active = true;

    const loadSession = async () => {
      try {
        const response = await fetch(`${API_BASE}/api/profile`, {
          credentials: 'include',
        });
        if (!response.ok) {
          if (active) setUser(null);
          return;
        }
        const data = await response.json();
        if (active) {
          setUser(data.user);
        }
      } catch (error) {
        if (active) setUser(null);
      } finally {
        if (active) setAuthLoading(false);
      }
    };

    loadSession();

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return undefined;
    const media = window.matchMedia(MENU_QUERY);
    const syncMenuState = (matches) => {
      setIsDesktopMenu(matches);
      setMenuOpen(matches);
    };
    const handleChange = (event) => syncMenuState(event.matches);

    syncMenuState(media.matches);

    if (media.addEventListener) {
      media.addEventListener('change', handleChange);
      return () => media.removeEventListener('change', handleChange);
    }
    media.addListener(handleChange);
    return () => media.removeListener(handleChange);
  }, []);

  useEffect(() => {
    if (!isDesktopMenu) {
      setMenuOpen(false);
    }
  }, [location.pathname, isDesktopMenu]);

  useEffect(() => {
    setAdminMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (!adminMenuOpen) return undefined;

    const handleClick = (event) => {
      if (
        adminMenuRef.current &&
        !adminMenuRef.current.contains(event.target)
      ) {
        setAdminMenuOpen(false);
      }
    };

    const handleKey = (event) => {
      if (event.key === 'Escape') {
        setAdminMenuOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleKey);

    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleKey);
    };
  }, [adminMenuOpen]);

  useEffect(() => {
    if (typeof document === 'undefined') return;
    document.title = getPageTitle(location.pathname);
  }, [location.pathname]);

  useEffect(() => {
    document.body.style.overflow =
      menuOpen && !isDesktopMenu ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [menuOpen, isDesktopMenu]);

  useEffect(() => {
    if (!toast) return undefined;
    const timer = window.setTimeout(() => setToast(null), 5000);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    if (!menuOpen) {
      setMenuTooltip(null);
    }
  }, [menuOpen]);

  const notify = (message, tone = 'info') => {
    setToast({ message, tone, id: Date.now() });
  };

  const handleAuth = (nextUser) => {
    setUser(nextUser);
  };

  const handleUserUpdate = (patch) => {
    setUser((prev) => (prev ? { ...prev, ...patch } : prev));
  };

  const handleLogout = async () => {
    try {
      await fetch(`${API_BASE}/api/logout`, {
        method: 'POST',
        credentials: 'include',
      });
      setUser(null);
      setMenuOpen(false);
      notify('Logged out', 'info');
    } catch (error) {
      notify('Unable to log out. Please try again.', 'error');
    }
  };

  const hideMenuTooltip = () => {
    if (tooltipTimerRef.current) {
      window.clearTimeout(tooltipTimerRef.current);
      tooltipTimerRef.current = null;
    }
    setMenuTooltip(null);
  };

  const showMenuTooltip = (event, label) => {
    if (!label) return;
    const rect = event.currentTarget.getBoundingClientRect();
    setMenuTooltip({
      label,
      top: rect.top + rect.height / 2,
      left: rect.right + 12,
    });
  };

  const handleAccountDeleted = () => {
    setUser(null);
    setMenuOpen(false);
    notify('Account deleted.', 'success');
  };

  const adminLinks = user?.isAdmin
    ? [
      { label: 'Users', to: '/admin/users' },
      { label: 'Plans', to: '/admin/plans' },
      { label: 'Methods', to: '/admin/methods' },
      { label: 'Servers', to: '/admin/servers' },
      { label: 'News', to: '/admin/news' },
    ]
    : [];

  const navSections = user
    ? [
      {
        title: 'Main',
        items: [
          { label: 'Home', to: '/home' },
          { label: 'Plan', to: '/shop' },
        ],
      },
      {
        title: 'Stress',
        items: [
          { label: 'Panel', to: '/panel' },
          { label: 'Method List', to: '/methods' },
          { label: "Api", to: '/api-manager' },
        ],
      },
    ]
    : [
      {
        title: null,
        items: [
          { label: 'Login', to: '/login' },
          { label: 'Register', to: '/register' },
        ],
      },
    ];
  const logoutLink = user
    ? { label: 'Logout', action: handleLogout, tone: 'danger' }
    : null;

  const profileName = user?.username || 'Guest';
  const profilePlan = user?.plan || 'No plan';

  const menuIcon = (label) => {
    switch (label) {
      case 'Home':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path
              d="M4 11.5 12 5l8 6.5V19a1 1 0 0 1-1 1h-4.5v-5.5h-5V20H5a1 1 0 0 1-1-1z"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 'Login':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path
              d="M4 12h10"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M11 8l4 4-4 4"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M14 5h5a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1h-5"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 'Register':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path
              d="M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle
              cx="9.5"
              cy="8"
              r="3.5"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M18 8v6"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M15 11h6"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 'Users':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <circle
              cx="12"
              cy="8"
              r="3.5"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M4 20v-1a5 5 0 0 1 5-5h6a5 5 0 0 1 5 5v1"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 'Api':
      case 'Api Manager':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path
              d="M7 8h10"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M7 12h6"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M7 16h8"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <rect
              x="4"
              y="5"
              width="16"
              height="14"
              rx="2"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 'Plan':
      case 'Plans':
      case 'Shop':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path
              d="M6 8h12l-1.2 11H7.2L6 8Z"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M9 8V6a3 3 0 0 1 6 0v2"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 'Methods':
      case 'Method List':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path
              d="M6 7h12M6 12h12M6 17h8"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle
              cx="18"
              cy="17"
              r="2"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 'Servers':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <rect
              x="4"
              y="5"
              width="16"
              height="5"
              rx="1.6"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <rect
              x="4"
              y="14"
              width="16"
              height="5"
              rx="1.6"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <circle cx="8" cy="7.5" r="0.9" fill="currentColor" />
            <circle cx="8" cy="16.5" r="0.9" fill="currentColor" />
          </svg>
        );
      case 'News':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path
              d="M5 5h14a1 1 0 0 1 1 1v11a2 2 0 0 1-2 2H6a1 1 0 0 1-1-1Z"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M8 9h8"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M8 12.5h6"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 'Panel':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <rect
              x="4"
              y="5"
              width="7.5"
              height="7.5"
              rx="1.8"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <rect
              x="12.5"
              y="5"
              width="7.5"
              height="7.5"
              rx="1.8"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <rect
              x="4"
              y="12.5"
              width="7.5"
              height="7.5"
              rx="1.8"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <rect
              x="12.5"
              y="12.5"
              width="7.5"
              height="7.5"
              rx="1.8"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      case 'Logout':
        return (
          <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
            <path
              d="M10 5H6a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h4"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M14 7l4 5-4 5"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            <path
              d="M18 12H9"
              strokeWidth="1.8"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        );
      default:
        return null;
    }
  };

  const SettingsIcon = () => (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
      <path
        d="M12 8.8a3.2 3.2 0 1 1 0 6.4 3.2 3.2 0 0 1 0-6.4Z"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M19.4 15.2a1 1 0 0 0 .2 1.1l.1.1a1.2 1.2 0 0 1 0 1.7l-1.2 1.2a1.2 1.2 0 0 1-1.7 0l-.1-.1a1 1 0 0 0-1.1-.2 1 1 0 0 0-.6.9v.3a1.2 1.2 0 0 1-1.2 1.2h-1.6a1.2 1.2 0 0 1-1.2-1.2v-.3a1 1 0 0 0-.6-.9 1 1 0 0 0-1.1.2l-.1.1a1.2 1.2 0 0 1-1.7 0l-1.2-1.2a1.2 1.2 0 0 1 0-1.7l.1-.1a1 1 0 0 0 .2-1.1 1 1 0 0 0-.9-.6h-.3A1.2 1.2 0 0 1 2.8 13v-1.6A1.2 1.2 0 0 1 4 10.2h.3a1 1 0 0 0 .9-.6 1 1 0 0 0-.2-1.1l-.1-.1a1.2 1.2 0 0 1 0-1.7L6.1 5a1.2 1.2 0 0 1 1.7 0l.1.1a1 1 0 0 0 1.1.2 1 1 0 0 0 .6-.9V4a1.2 1.2 0 0 1 1.2-1.2h1.6A1.2 1.2 0 0 1 13.6 4v.3a1 1 0 0 0 .6.9 1 1 0 0 0 1.1-.2l.1-.1A1.2 1.2 0 0 1 17.1 5l1.2 1.2a1.2 1.2 0 0 1 0 1.7l-.1.1a1 1 0 0 0-.2 1.1 1 1 0 0 0 .9.6h.3A1.2 1.2 0 0 1 21.2 11v1.6a1.2 1.2 0 0 1-1.2 1.2h-.3a1 1 0 0 0-.9.6Z"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );

  const isAdminActive = (target) => {
    if (!target) return false;
    if (target === '/admin/users') {
      return (
        location.pathname === '/admin' ||
        location.pathname.startsWith('/admin/users')
      );
    }
    if (target === '/admin/plans') {
      return location.pathname.startsWith('/admin/plans');
    }
    if (target === '/admin/servers') {
      return location.pathname.startsWith('/admin/servers');
    }
    if (target === '/admin/methods') {
      return location.pathname.startsWith('/admin/methods');
    }
    if (target === '/admin/news') {
      return location.pathname.startsWith('/admin/news');
    }
    return location.pathname === target;
  };

  const isMenuDocked = isDesktopMenu && menuOpen;

  const MobileNav = () => {
    if (!user || isDesktopMenu) return null;

    const mobileLinks = [
      { label: 'Home', to: '/home' },
      { label: 'Panel', to: '/panel' },
      { label: 'Methods', to: '/methods' },
      { label: 'Plan', to: '/shop' },
      { label: "Api", to: '/api-manager' },
    ];

    return (
      <nav className="mobile-nav">
        <div className="mobile-nav__items">
          {mobileLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              className={({ isActive }) =>
                `mobile-nav__link ${isActive ? 'is-active' : ''}`
              }
            >
              <span className="mobile-nav__icon">{menuIcon(link.label)}</span>
              <span className="mobile-nav__label">{link.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>
    );
  };

  return (
    <div
      className={`app ${menuOpen && !isMenuDocked ? 'is-menu-open' : ''} ${isMenuDocked ? 'has-docked-menu' : ''
        }`}
    >
      <header className="topbar">
        <div className="topbar__left">
          {isDesktopMenu && (
            <button
              type="button"
              className="menu-trigger"
              onClick={() => setMenuOpen((open) => !open)}
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
            >
              <span className="menu-trigger__icon" aria-hidden="true">
                <svg viewBox="0 0 24 24" width="20" height="20">
                  <line x1="4" y1="6" x2="20" y2="6" />
                  <line x1="4" y1="12" x2="20" y2="12" />
                  <line x1="4" y1="18" x2="20" y2="18" />
                </svg>
              </span>
              <span className="menu-trigger__text">Menu</span>
            </button>
          )}
          {isDesktopMenu && !menuOpen && (
            <button
              type="button"
              className="nav__expand-tab"
              onClick={() => setMenuOpen(true)}
              aria-label="Expand sidebar"
              title="Open sidebar"
            >
              <svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true">
                <path
                  d="M9 3H18.5A1.5 1.5 0 0 1 20 4.5v15A1.5 1.5 0 0 1 18.5 21H9"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <path
                  d="M10 8l4 4-4 4"
                  strokeWidth="1.8"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
                <line x1="4" y1="12" x2="14" y2="12" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            </button>
          )}
          {location.pathname === '/' && isDesktopMenu && !isMenuDocked && (
            <Link to="/" className="topbar__landing-brand">
              <span className="brand__the">The</span>
              <span className="brand__flash">Flash</span>
            </Link>
          )}
        </div>
        <div className="topbar__center">
          {!isDesktopMenu ? (
            <div className="topbar__brand-mobile">
              <span className="brand-mobile__the">The</span>
              <span className="brand-mobile__flash">Flash</span>
            </div>
          ) : location.pathname === '/' ? (
            <nav className="topbar__landing-links">
              <a href="#stats" onClick={(e) => { e.preventDefault(); document.getElementById('stats')?.scrollIntoView({ behavior: 'smooth' }); }}>Stats</a>
              <a href="#features" onClick={(e) => { e.preventDefault(); document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' }); }}>Features</a>
              <a href="#preview" onClick={(e) => { e.preventDefault(); document.getElementById('preview')?.scrollIntoView({ behavior: 'smooth' }); }}>Interface</a>
              <a href="#workflow" onClick={(e) => { e.preventDefault(); document.getElementById('workflow')?.scrollIntoView({ behavior: 'smooth' }); }}>Workflow</a>
              <a href="#pricing" onClick={(e) => { e.preventDefault(); document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' }); }}>Plans</a>
              <a href="#faq" onClick={(e) => { e.preventDefault(); document.getElementById('faq')?.scrollIntoView({ behavior: 'smooth' }); }}>FAQ</a>
            </nav>
          ) : null}
        </div>
        <div className="topbar__right">
          {location.pathname === '/' && (
            user ? (
              <Link to="/home" className="topbar__auth-btn topbar__auth-btn--primary">
                <span>Dashboard</span>
                <ArrowRight size={14} />
              </Link>
            ) : (
              <div className="topbar__auth-group">
                <Link to="/login" className="topbar__auth-btn topbar__auth-btn--ghost">
                  Login
                </Link>
                <Link to="/register" className="topbar__auth-btn topbar__auth-btn--primary">
                  <span>Register</span>
                  <ArrowRight size={14} />
                </Link>
              </div>
            )
          )}
          {adminLinks.length && !isDesktopMenu ? (
            <div
              className={`admin-menu ${adminMenuOpen ? 'is-open' : ''}`}
              ref={adminMenuRef}
            >
              <button
                type="button"
                className="admin-menu__trigger"
                onClick={() => setAdminMenuOpen((open) => !open)}
                aria-expanded={adminMenuOpen}
                aria-controls="admin-menu-panel"
              >
                <span>Admin</span>
                <span className="admin-menu__chevron" aria-hidden="true">
                  <svg viewBox="0 0 24 24" width="18" height="18">
                    <path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </span>
              </button>
              <div
                className="admin-menu__panel"
                id="admin-menu-panel"
                role="menu"
                aria-hidden={!adminMenuOpen}
              >
                {adminLinks.map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    role="menuitem"
                    className={`admin-menu__item ${isAdminActive(link.to) ? 'is-active' : ''
                      }`}
                    onClick={() => setAdminMenuOpen(false)}
                  >
                    {link.label}
                  </Link>
                ))}
              </div>
            </div>
          ) : null}
        </div>
      </header>

      <main className="main">
        {user && location.pathname !== '/' && (
          <div className="page-header">
            <div className="page-header__breadcrumbs">
              <span className="breadcrumbs__section">
                {location.pathname.startsWith('/admin') ? 'Admin' : 'Dashboard'}
              </span>
              <span className="breadcrumbs__separator">/</span>
              <span className="breadcrumbs__current">
                {location.pathname === '/home' && 'Home'}
                {location.pathname === '/panel' && 'Stress Panel'}
                {location.pathname === '/methods' && 'Method List'}
                {location.pathname === '/shop' && 'Store'}
                {location.pathname === '/api-manager' && 'API Manager'}
                {location.pathname === '/admin/users' && 'Users'}
                {location.pathname === '/admin/plans' && 'Plans'}
                {location.pathname === '/admin/methods' && 'Methods'}
                {location.pathname === '/admin/servers' && 'Servers'}
                {location.pathname === '/admin/news' && 'News Settings'}
              </span>
            </div>
            <h1 className="page-header__title">
              {location.pathname === '/home' && 'Overview'}
              {location.pathname === '/panel' && 'Attack Hub'}
              {location.pathname === '/methods' && 'Attack Vectors'}
              {location.pathname === '/shop' && 'Plans & Pricing'}
              {location.pathname === '/api-manager' && 'Developers API'}
              {location.pathname === '/admin/users' && 'Manage Users'}
              {location.pathname === '/admin/plans' && 'Manage Plans'}
              {location.pathname === '/admin/methods' && 'Manage Methods'}
              {location.pathname === '/admin/servers' && 'Manage Servers'}
              {location.pathname === '/admin/news' && 'Manage News'}
            </h1>
          </div>
        )}
        <Routes>
          <Route path="/" element={<Landing user={user} />} />
          <Route
            path="/login"
            element={
              user ? (
                <Navigate to="/home" replace />
              ) : (
                <Login
                  onAuth={handleAuth}
                  onNotify={notify}
                />
              )
            }
          />
          <Route
            path="/register"
            element={
              user ? (
                <Navigate to="/home" replace />
              ) : (
                <Register onAuth={handleAuth} onNotify={notify} />
              )
            }
          />
          <Route
            path="/home"
            element={
              <RequireAuth user={user} loading={authLoading}>
                <Home user={user} onLogout={handleLogout} />
              </RequireAuth>
            }
          />
          <Route
            path="/panel"
            element={
              <RequireAuth user={user} loading={authLoading}>
                <Panel user={user} onNotify={notify} />
              </RequireAuth>
            }
          />
          <Route
            path="/methods"
            element={
              <RequireAuth user={user} loading={authLoading}>
                <MethodsList onNotify={notify} />
              </RequireAuth>
            }
          />
          <Route
            path="/api-manager"
            element={
              <RequireAuth user={user} loading={authLoading}>
                <ApiManager onNotify={notify} />
              </RequireAuth>
            }
          />
          <Route
            path="/admin"
            element={<Navigate to="/admin/users" replace />}
          />
          <Route
            path="/admin/users"
            element={
              <RequireAdmin user={user} loading={authLoading}>
                <AdminUsersList onNotify={notify} />
              </RequireAdmin>
            }
          />
          <Route
            path="/admin/users/:userId"
            element={
              <RequireAdmin user={user} loading={authLoading}>
                <AdminUserDetail onNotify={notify} />
              </RequireAdmin>
            }
          />
          <Route
            path="/admin/plans"
            element={
              <RequireAdmin user={user} loading={authLoading}>
                <AdminPlans onNotify={notify} />
              </RequireAdmin>
            }
          />
          <Route
            path="/admin/methods"
            element={
              <RequireAdmin user={user} loading={authLoading}>
                <AdminMethods onNotify={notify} />
              </RequireAdmin>
            }
          />
          <Route
            path="/admin/servers"
            element={
              <RequireAdmin user={user} loading={authLoading}>
                <AdminServers onNotify={notify} />
              </RequireAdmin>
            }
          />
          <Route
            path="/admin/servers/:serverId"
            element={
              <RequireAdmin user={user} loading={authLoading}>
                <AdminServerDetail onNotify={notify} />
              </RequireAdmin>
            }
          />
          <Route
            path="/admin/plans/:planId"
            element={
              <RequireAdmin user={user} loading={authLoading}>
                <AdminPlanDetail onNotify={notify} />
              </RequireAdmin>
            }
          />
          <Route
            path="/admin/news"
            element={
              <RequireAdmin user={user} loading={authLoading}>
                <AdminNews onNotify={notify} />
              </RequireAdmin>
            }
          />
          <Route
            path="/shop"
            element={
              <RequireAuth user={user} loading={authLoading}>
                <Plan
                  user={user}
                  onNotify={notify}
                  onUserUpdate={handleUserUpdate}
                />
              </RequireAuth>
            }
          />
          <Route
            path="/profile"
            element={
              <RequireAuth user={user} loading={authLoading}>
                <Profile
                  user={user}
                  onNotify={notify}
                  onAccountDeleted={handleAccountDeleted}
                />
              </RequireAuth>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      {menuOpen && (
        <div
          className={`menu-overlay ${isMenuDocked ? 'menu-overlay--docked' : ''
            }`}
          role="dialog"
          aria-modal={!isMenuDocked}
          id="mobile-menu"
        >
          <div className="menu-overlay__panel">
            <nav className="nav nav--mobile" aria-label="Mobile">
              <div className="nav__scroll" onScroll={hideMenuTooltip}>
                <div className="nav__brand">
                  <Link className="brand" to="/" onClick={() => setMenuOpen(false)}>
                    <span className="brand__the">The</span>
                    <span className="brand__flash">Flash</span>
                  </Link>
                  {isMenuDocked && (
                    <button
                      type="button"
                      className="nav__collapse-btn"
                      onClick={() => setMenuOpen(false)}
                      aria-label="Collapse sidebar"
                      title="Collapse sidebar"
                    >
                      <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
                        <path
                          d="M15 3H5.5A1.5 1.5 0 0 0 4 4.5v15A1.5 1.5 0 0 0 5.5 21H15"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <path
                          d="M14 8l-4 4 4 4"
                          strokeWidth="1.8"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        />
                        <line x1="10" y1="12" x2="20" y2="12" strokeWidth="1.8" strokeLinecap="round" />
                      </svg>
                    </button>
                  )}
                </div>

                {navSections.map((section, sectionIndex) => (
                  <Fragment key={`${section.title ?? 'auth'}-${sectionIndex}`}>
                    {section.title && (
                      <span
                        className={`nav__section-title ${sectionIndex > 0 ? 'nav__section-title--spaced' : ''
                          }`}
                      >
                        {section.title}
                      </span>
                    )}
                    {section.items.map((link) => (
                      <NavLink
                        key={link.label}
                        to={link.to}
                        className={({ isActive }) => `nav__link nav__link--mobile ${isActive ? 'is-active' : ''}`}
                        data-label={link.label}
                        title={link.label}
                        aria-label={link.label}
                        onMouseEnter={(event) =>
                          showMenuTooltip(event, link.label)
                        }
                        onMouseLeave={hideMenuTooltip}
                        onFocus={(event) =>
                          showMenuTooltip(event, link.label)
                        }
                        onBlur={hideMenuTooltip}
                        onTouchStart={(event) => {
                          showMenuTooltip(event, link.label);
                          if (tooltipTimerRef.current) {
                            window.clearTimeout(tooltipTimerRef.current);
                          }
                          tooltipTimerRef.current = window.setTimeout(
                            hideMenuTooltip,
                            1200
                          );
                        }}
                      >
                        <span className="nav__icon" aria-hidden="true">
                          {menuIcon(link.label)}
                        </span>
                        <span className="nav__text">{link.label}</span>
                      </NavLink>
                    ))}
                  </Fragment>
                ))}

                {adminLinks.length > 0 && isDesktopMenu && (
                  <Fragment>
                    <span className="nav__section-title nav__section-title--spaced">
                      Administrator
                    </span>
                    <div
                      className={`admin-menu ${adminMenuOpen ? 'is-open' : ''}`}
                      ref={adminMenuRef}
                      style={{ width: '100%' }}
                    >
                      <button
                        type="button"
                        className={`nav__link nav__link--mobile ${adminMenuOpen ? 'is-active' : ''}`}
                        onClick={() => setAdminMenuOpen((open) => !open)}
                        aria-expanded={adminMenuOpen}
                        aria-controls="admin-menu-panel"
                        style={{ width: '100%', border: 'none', background: 'none' }}
                      >
                        <span className="nav__icon" aria-hidden="true">
                          <Shield size={18} strokeWidth={1.8} />
                        </span>
                        <span className="nav__text">Admin</span>
                        <span className="admin-menu__chevron" aria-hidden="true" style={{ marginLeft: 'auto' }}>
                          <svg viewBox="0 0 24 24" width="16" height="16">
                            <path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                          </svg>
                        </span>
                      </button>
                      <div
                        className="admin-menu__panel"
                        id="admin-menu-panel"
                        role="menu"
                        aria-hidden={!adminMenuOpen}
                        style={{ 
                          position: 'relative', 
                          top: '0', 
                          right: '0', 
                          width: '100%', 
                          marginTop: '8px', 
                          display: adminMenuOpen ? 'grid' : 'none',
                          opacity: 1,
                          transform: 'none',
                          pointerEvents: 'auto',
                          boxShadow: 'none',
                          background: 'rgba(255, 255, 255, 0.03)',
                          border: 'none'
                        }}
                      >
                        {adminLinks.map((link) => (
                          <Link
                            key={link.to}
                            to={link.to}
                            role="menuitem"
                            className={`admin-menu__item ${isAdminActive(link.to) ? 'is-active' : ''
                              }`}
                            onClick={() => setAdminMenuOpen(false)}
                          >
                            {link.label}
                          </Link>
                        ))}
                      </div>
                    </div>
                  </Fragment>
                )}
              </div>
              {logoutLink && (
                <div className="nav__footer">
                  <div className="menu-profile">
                    <button
                      type="button"
                      className="menu-profile__trigger"
                      aria-label={`${profileName} ${profilePlan}`}
                      title={`${profileName} — ${profilePlan}`}
                    >
                      <video
                        className="menu-profile__avatar"
                        autoPlay loop muted playsInline
                        src={bgVideo}
                      />
                    </button>
                    <div className="menu-profile__meta menu-profile__meta--inline">
                      <span className="menu-profile__name">{profileName}</span>
                      <span className="menu-profile__plan">{profilePlan}</span>
                    </div>
                    <Link
                      to="/profile"
                      className="menu-profile__settings"
                      aria-label="Profile settings"
                      title="Profile"
                    >
                      <SettingsIcon />
                    </Link>
                    <div className="menu-profile__tooltip" aria-hidden="true">
                      <video
                        className="menu-profile__tooltip-avatar"
                        autoPlay loop muted playsInline
                        src={bgVideo}
                      />
                      <div className="menu-profile__meta">
                        <span className="menu-profile__name">
                          {profileName}
                        </span>
                        <span className="menu-profile__plan">
                          {profilePlan}
                        </span>
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    className="menu-profile__logout"
                    onClick={handleLogout}
                    aria-label="Logout"
                    title="Logout"
                  >
                    <LogOut size={16} strokeWidth={2.2} />
                    <span className="nav__text">Logout</span>
                  </button>
                </div>
              )}
            </nav>
          </div>
          {menuTooltip && (
            <div
              className="menu-tooltip"
              style={{
                top: `${menuTooltip.top}px`,
                left: `${menuTooltip.left}px`,
              }}
              aria-hidden="true"
            >
              {menuTooltip.label}
            </div>
          )}
          {!isMenuDocked && (
            <button
              type="button"
              className="menu-overlay__backdrop"
              onClick={() => setMenuOpen(false)}
              aria-label="Close menu"
            />
          )}
        </div>
      )}

      {toast && (
        <div
          key={toast.id}
          className={`toast toast--${toast.tone}`}
          role="status"
          aria-live="polite"
          style={{ '--toast-duration': '5000ms' }}
        >
          <span>{toast.message}</span>
          <button
            type="button"
            className="toast__close"
            onClick={() => setToast(null)}
            aria-label="Dismiss notification"
          >
            x
          </button>
          <div className="toast__progress" aria-hidden="true" />
        </div>
      )}
      <MobileNav />
    </div>
  );
}

function RequireAuth({ user, loading, children }) {
  const location = useLocation();
  if (loading) {
    return (
      <div className="page">
        <div className="status-card">Checking session...</div>
      </div>
    );
  }
  if (!user) {
    return <Navigate to="/" replace state={{ from: location }} />;
  }
  return children;
}

function RequireAdmin({ user, loading, children }) {
  if (loading) {
    return (
      <div className="page">
        <div className="status-card">Checking session...</div>
      </div>
    );
  }
  if (!user) {
    return <Navigate to="/" replace />;
  }
  if (!user.isAdmin) {
    return <Navigate to="/home" replace />;
  }
  return children;
}

function Landing({ user }) {
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`${API_BASE}/api/public/plans`)
      .then((res) => res.json())
      .then((data) => {
        if (data.plans) setPlans(data.plans);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const handleBuy = () => {
    if (user) {
      navigate('/shop');
    } else {
      navigate('/login');
    }
  };

  const formatCurrency = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return 'Rp 0';
    return `Rp ${new Intl.NumberFormat('id-ID').format(Math.trunc(amount))}`;
  };

  const formatTime = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return '-';
    if (amount >= 3600 && amount % 3600 === 0) return `${amount / 3600}h`;
    if (amount >= 60 && amount % 60 === 0) return `${amount / 60}m`;
    return `${amount}s`;
  };

  const formatStock = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return 'Out of stock';
    return `${amount} slot${amount === 1 ? '' : 's'}`;
  };

  const services = [
    {
      title: 'Site Hold Services',
      subtitle: 'Hourly availability',
      icon: <Activity size={20} />,
      items: [
        { label: '1 Hour', price: 'Rp120k / $10' },
        { label: '4 Hours', price: 'Rp300k / $25' },
        { label: '6 Hours', price: 'Rp500k / $35' },
      ],
    },
    {
      title: 'Site Hold Services',
      subtitle: 'Daily availability',
      icon: <Globe size={20} />,
      items: [
        { label: '1 Day', price: 'Rp1jt / $70' },
        { label: '7 Days', price: 'Rp4jt / $270' },
        { label: '30 Days', price: 'Rp14jt / $900' },
      ],
    },
    {
      title: 'Specialized Suspension',
      subtitle: 'Tailored solutions',
      icon: <Shield size={20} />,
      items: [
        { label: 'Easy Target', price: 'Rp1jt / $70' },
        { label: 'Hard Target', price: 'Rp3jt / $200' },
        { label: 'Super Hard', price: 'Rp15jt / $1000' },
      ],
    },
  ];

  return (
    <div className="landing-page">
      <header className="landing-hero">
        <div className="landing-container">
          <div className="landing-hero__content">
            <div className="landing-badge">
              <span className="pulse-indicator" />
              <Zap size={14} style={{ marginRight: 6 }} />
              <span>THE ULTIMATE NETWORK TESTING PLATFORM</span>
            </div>
            <h1 className="landing-hero__title">
              THE<span className="text-accent">FLASH</span> STRESSER
            </h1>
            <p className="landing-hero__subtitle">
              Elite infrastructure security auditing &amp; high-capacity load testing. <br />
              Secure. Private. Unstoppable.
            </p>
            <div className="landing-hero__actions">
              <button
                onClick={() => navigate(user ? '/home' : '/register')}
                className="button button--primary button--hero"
              >
                {user ? 'Open Dashboard' : 'Get Started'}
                <div className="button__icon">
                  <ArrowRight size={18} />
                </div>
              </button>
              <button
                onClick={() => {
                  const el = document.getElementById('pricing');
                  el?.scrollIntoView({ behavior: 'smooth' });
                }}
                className="button button--ghost button--hero"
              >
                Explore Plans
              </button>
            </div>

            <div className="landing-hero__trust">
              <div className="trust-pill">
                <Zap size={14} />
                <span>Layer 4 &amp; 7 Vectors</span>
              </div>
              <div className="trust-pill">
                <Shield size={14} />
                <span>Bypass Cloudflare &amp; Akamai</span>
              </div>
              <div className="trust-pill">
                <Lock size={14} />
                <span>100% Anonymous &amp; Zero Logs</span>
              </div>
            </div>
          </div>
        </div>
        <div className="landing-hero__shadow" />
      </header>

      <div className="landing-container">
        {/* ─── PLATFORM STATS ─── */}
        <section className="landing-stats" id="stats">
          <div className="landing-section-header center">
            <div className="section-badge">PLATFORM</div>
            <h2>Proven at <span className="text-accent">Scale</span></h2>
            <p>Real numbers from our active multi-region cluster. Updated continuously.</p>
          </div>
          <div className="stats-grid">
            <div className="stat-card">
              <div className="stat-card__value">99.9<span className="stat-card__unit">%</span></div>
              <div className="stat-card__label">Uptime SLA</div>
              <div className="stat-card__desc">Redundant multi-region nodes with automatic failover</div>
            </div>
            <div className="stat-card stat-card--accent">
              <div className="stat-card__value">50<span className="stat-card__unit">+</span></div>
              <div className="stat-card__label">Attack Methods</div>
              <div className="stat-card__desc">Layer 4 &amp; Layer 7 vectors across UDP, TCP, HTTP protocols</div>
            </div>
            <div className="stat-card">
              <div className="stat-card__value">1M<span className="stat-card__unit">+</span></div>
              <div className="stat-card__label">Total Attacks Sent</div>
              <div className="stat-card__desc">Millions of successful stress tests executed on our platform</div>
            </div>
            <div className="stat-card">
              <div className="stat-card__value">24<span className="stat-card__unit">/7</span></div>
              <div className="stat-card__label">Live Support</div>
              <div className="stat-card__desc">Dedicated support team available around the clock via Telegram</div>
            </div>
          </div>
        </section>

        {/* ─── FEATURES ─── */}
        <section className="landing-features" id="features">
          <div className="landing-section-header center">
            <div className="section-badge">ADVANTAGES</div>
            <h2>Why Use <span className="text-accent">TheFlash</span>?</h2>
            <p>Our infrastructure is built for high-demand auditing and precise load testing across various vectors.</p>
          </div>
          
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-card__icon">
                <Zap size={24} />
              </div>
              <h3 className="feature-card__title">Instant Launch</h3>
              <p className="feature-card__text">No queues, no manual verification. Execute your power instantly from our intuitive dashboard.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-card__icon">
                <Settings size={24} />
              </div>
              <h3 className="feature-card__title">Total Precision</h3>
              <p className="feature-card__text">Fine-tune targets, methods, slots, and bypass settings for the most accurate simulation possible.</p>
            </div>
            
            <div className="feature-card">
              <div className="feature-card__icon">
                <Terminal size={24} />
              </div>
              <h3 className="feature-card__title">Advanced API</h3>
              <p className="feature-card__text">Seamlessly integrate our C2 infrastructure into your automated scripts or monitoring workflows.</p>
            </div>

            <div className="feature-card">
              <div className="feature-card__icon">
                <Globe size={24} />
              </div>
              <h3 className="feature-card__title">Global Network</h3>
              <p className="feature-card__text">Distributed nodes worldwide guarantee extreme bandwidth and instant penetration without bottlenecks.</p>
            </div>
          </div>
        </section>

        {/* ─── DASHBOARD PREVIEW ─── */}
        <section className="landing-preview" id="preview">
          <div className="landing-section-header center">
            <div className="section-badge">INTERFACE</div>
            <h2>Powerful <span className="text-accent">Dashboard</span></h2>
            <p>Everything you need in one clean, responsive interface designed for speed.</p>
          </div>
          <div className="preview-wrapper">
            <div className="preview-topbar">
              <div className="preview-topbar__dots">
                <span /><span /><span />
              </div>
              <div className="preview-topbar__title">TheFlash — Attack Hub (Live Simulator)</div>
            </div>
            <div className="preview-body">
              <div className="preview-sidebar">
                {['Home', 'Panel', 'Method List', 'Plan', 'Api'].map((item) => (
                  <div key={item} className={`preview-nav-item ${item === 'Panel' ? 'is-active' : ''}`}>
                    <span className="preview-nav-dot" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
              <div className="preview-content">
                <div className="preview-metrics">
                  {[
                    { label: 'Active Runs', value: '3', color: '#8b5cf6' },
                    { label: 'Max Concurrent', value: '10', color: '#10b981' },
                    { label: 'Total Attacks', value: '1,248', color: '#f59e0b' },
                  ].map((m) => (
                    <div key={m.label} className="preview-metric">
                      <span className="preview-metric__value" style={{ color: m.color }}>{m.value}</span>
                      <span className="preview-metric__label">{m.label}</span>
                    </div>
                  ))}
                </div>
                <div className="preview-form">
                  <div className="preview-form__row">
                    <div className="preview-form__field">
                      <div className="preview-form__label">Target</div>
                      <div className="preview-form__input">192.168.1.1</div>
                    </div>
                    <div className="preview-form__field">
                      <div className="preview-form__label">Port</div>
                      <div className="preview-form__input">80</div>
                    </div>
                  </div>
                  <div className="preview-form__row">
                    <div className="preview-form__field">
                      <div className="preview-form__label">Method</div>
                      <div className="preview-form__input">UDP-BYPASS</div>
                    </div>
                    <div className="preview-form__field">
                      <div className="preview-form__label">Duration</div>
                      <div className="preview-form__input">300s</div>
                    </div>
                  </div>
                  <div className="preview-launch-btn">
                    <Zap size={14} /> Launch Attack
                  </div>
                </div>
                <div className="preview-table">
                  <div className="preview-table__header">
                    <span>Target</span><span>Method</span><span>Status</span>
                  </div>
                  {[
                    { target: '10.0.0.1:80', method: 'HTTP-FLOOD', status: 'Running', color: '#10b981' },
                    { target: '10.0.0.2:443', method: 'UDP-BYPASS', status: 'Running', color: '#10b981' },
                    { target: '10.0.0.3:25', method: 'TCP-ACK', status: 'Finished', color: '#6b7280' },
                  ].map((row, i) => (
                    <div key={i} className="preview-table__row">
                      <span>{row.target}</span>
                      <span>{row.method}</span>
                      <span style={{ color: row.color }}>{row.status}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ─── HOW IT WORKS ─── */}
        <section className="landing-howitworks" id="workflow">
          <div className="landing-section-header center">
            <div className="section-badge">WORKFLOW</div>
            <h2>How It <span className="text-accent">Works</span></h2>
            <p>Get started in minutes. No complicated verification required.</p>
          </div>
          <div className="steps-grid">
            <div className="step-card">
              <div className="step-card__number">01</div>
              <div className="step-card__icon">
                <Lock size={24} />
              </div>
              <h3 className="step-card__title">Create Account</h3>
              <p className="step-card__text">Register in seconds. Your identity is protected with end-to-end encryption and no personal data required.</p>
            </div>
            <div className="step-card">
              <div className="step-card__number">02</div>
              <div className="step-card__icon">
                <ShoppingCart size={24} />
              </div>
              <h3 className="step-card__title">Choose a Plan</h3>
              <p className="step-card__text">Select the plan that fits your testing capacity. Upgrade or add-on anytime to get more concurrent slots or duration.</p>
            </div>
            <div className="step-card">
              <div className="step-card__number">03</div>
              <div className="step-card__icon">
                <Layers size={24} />
              </div>
              <h3 className="step-card__title">Configure Attack</h3>
              <p className="step-card__text">Set your target, port, method, duration, and engine power. Fine-tune every parameter for precise load simulation.</p>
            </div>
            <div className="step-card">
              <div className="step-card__number">04</div>
              <div className="step-card__icon">
                <Zap size={24} />
              </div>
              <h3 className="step-card__title">Launch &amp; Monitor</h3>
              <p className="step-card__text">Execute instantly from the dashboard. Monitor live runs, view history, and stop attacks at any time with one click.</p>
            </div>
          </div>
        </section>

        {/* ─── PRICING ─── */}
        <section className="landing-pricing" id="pricing">
          <div className="landing-section-header center">
            <div className="section-badge">SUBSCRIPTIONS</div>
            <h2>Available <span className="text-accent">Plans</span></h2>
            <p>Select the capacity that matches your testing requirements.</p>
          </div>

          <div className="landing-plan-grid">
            {loading ? (
              <div className="full-width text-center">
                <div className="loading-spinner" style={{ margin: '0 auto 12px' }} />
                <span>Synchronizing plans...</span>
              </div>
            ) : (
              plans.map((plan, idx) => (
                <div
                  key={plan.id}
                  className={`landing-plan-card ${idx === 1 ? 'is-featured' : ''}`}
                >
                  {idx === 1 && <div className="plan-card__featured-tag">BEST VALUE</div>}
                  <div className="landing-plan-card__header">
                    <h3>{plan.display || plan.name}</h3>
                    <div className="landing-plan-price">
                      {formatCurrency(plan.price)}
                      <span className="price-label"> / {plan.expired} days</span>
                    </div>
                  </div>
                  
                  <div className="plan-divider" />
                  
                  <ul className="landing-plan-features">
                    <li><Check size={16} /> <span><strong>{formatTime(plan.time)}</strong> Duration</span></li>
                    <li><Check size={16} /> <span><strong>{plan.conc}</strong> Concurrent</span></li>
                    <li><Check size={16} /> <span><strong>7/24</strong> Full Support</span></li>
                    <li><Check size={16} /> <span><strong>{formatTime(plan.cooldown)}</strong> Cooldown</span></li>
                    <li><Check size={16} /> <span><strong>{formatStock(plan.stock)}</strong> Slots</span></li>
                  </ul>
                  
                  <button onClick={handleBuy} className={`button full-width ${idx === 1 ? 'button--primary' : 'button--ghost'}`}>
                    {user ? 'Purchase Plan' : 'Get Started'}
                  </button>
                </div>
              ))
            )}
          </div>

          <div className="landing-addons">
            <div className="landing-section-header center">
               <h3>Custom Add-Ons</h3>
               <p style={{ color: 'var(--muted)', fontSize: '14px', marginTop: '6px' }}>Scale your capabilities on demand</p>
            </div>
            <div className="addons-grid">
              <div className="addon-card">
                <div className="addon-card__icon"><Cpu size={18} /></div>
                <div className="addon-card__info">
                  <span className="addon-card__title">+1 Concurrent</span>
                  <span className="addon-card__price">$7.00</span>
                </div>
              </div>
              <div className="addon-card">
                <div className="addon-card__icon"><Activity size={18} /></div>
                <div className="addon-card__info">
                  <span className="addon-card__title">+10 Days Access</span>
                  <span className="addon-card__price">$8.00</span>
                </div>
              </div>
              <div className="addon-card">
                <div className="addon-card__icon"><Zap size={18} /></div>
                <div className="addon-card__info">
                  <span className="addon-card__title">+1000s Duration</span>
                  <span className="addon-card__price">$30.00</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ─── DIRECT SERVICES ─── */}
        <section className="landing-services" id="services">
          <div className="landing-section-header center">
            <div className="section-badge">MANAGED SOLUTIONS</div>
            <h2>Direct <span className="text-accent">Services</span></h2>
            <p>Managed attack solutions with full mitigation reports and optimization advice.</p>
          </div>
          
          <div className="services-grid">
            {services.map((svc, idx) => (
              <div key={idx} className="service-card">
                <div className="service-card__header">
                  <div className="service-card__icon">{svc.icon}</div>
                  <div className="service-card__info">
                    <h3 className="service-card__title">{svc.title}</h3>
                    <span className="service-card__subtitle">{svc.subtitle}</span>
                  </div>
                </div>
                <div className="service-card__items">
                  {svc.items.map((item, i) => (
                    <div key={i} className="service-card__item">
                      <span className="service-card__item-label">{item.label}</span>
                      <span className="service-card__item-price">{item.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ─── FAQ ─── */}
        <section className="landing-faq" id="faq">
          <div className="landing-section-header center">
             <div className="section-badge">KNOWLEDGEBASE</div>
             <h2>FAQ &amp; Support</h2>
             <p>Frequently asked questions about our testing infrastructure.</p>
          </div>
          <div className="faq-grid">
             <div className="faq-card">
                <h4 className="faq-card__question">Pre-Service Testing</h4>
                <p className="faq-card__answer">All managed services can begin with a trial phase. Mitigation reports are provided post-testing to ensure results.</p>
             </div>
             <div className="faq-card">
                <h4 className="faq-card__question">Payment Methods</h4>
                <p className="faq-card__answer">We accept USDT, IDR, and major Crypto. Escrow/Rekber services are welcome to ensure secure deals.</p>
             </div>
             <div className="faq-card">
                <h4 className="faq-card__question">Workflow System</h4>
                <p className="faq-card__answer">Simple and effective: Request &gt; Verification &gt; Success &gt; Payment. We stand by our power.</p>
             </div>
          </div>
        </section>

        {/* ─── CONTACT & SUPPORT ─── */}
        <section className="landing-contact" id="contact">
          <div className="landing-section-header center">
            <div className="section-badge">GET IN TOUCH</div>
            <h2>Contact &amp; <span className="text-accent">Support</span></h2>
            <p>We're available 24/7. Reach out through any of the channels below.</p>
          </div>
          <div className="contact-grid">
            <a href="https://t.me/thestresser" target="_blank" rel="noopener noreferrer" className="contact-card">
              <div className="contact-card__icon">
                <Headphones size={28} />
              </div>
              <div className="contact-card__info">
                <span className="contact-card__title">Customer Support</span>
                <span className="contact-card__handle">@thestresser</span>
                <span className="contact-card__desc">Direct support, order inquiries, and technical help</span>
              </div>
              <ExternalLink size={16} className="contact-card__arrow" />
            </a>
            <a href="https://t.me/theflashddosbox" target="_blank" rel="noopener noreferrer" className="contact-card">
              <div className="contact-card__icon">
                <Globe size={28} />
              </div>
              <div className="contact-card__info">
                <span className="contact-card__title">Public Channel</span>
                <span className="contact-card__handle">@theflashddosbox</span>
                <span className="contact-card__desc">Announcements, updates, and showcase results</span>
              </div>
              <ExternalLink size={16} className="contact-card__arrow" />
            </a>
            <div className="contact-card contact-card--info">
              <div className="contact-card__icon">
                <Shield size={28} />
              </div>
              <div className="contact-card__info">
                <span className="contact-card__title">Secure Deals</span>
                <span className="contact-card__handle">Escrow / Rekber</span>
                <span className="contact-card__desc">We support third-party escrow for verified and safe transactions</span>
              </div>
            </div>
            <div className="contact-card contact-card--info">
              <div className="contact-card__icon">
                <Cpu size={28} />
              </div>
              <div className="contact-card__info">
                <span className="contact-card__title">API Access</span>
                <span className="contact-card__handle">Developer Ready</span>
                <span className="contact-card__desc">Full REST API for integrating our infrastructure into your automation</span>
              </div>
            </div>
          </div>
        </section>
      </div>

      <footer className="landing-footer">
        <div className="landing-container">
          <div className="footer-content">
             <div className="footer-brand">
                <span className="brand-the">The</span><span className="brand-flash">Flash</span>
                <p>Advanced security auditing infrastructure and private C2 services.</p>
             </div>
             <div className="footer-contacts">
                <a href="https://t.me/thestresser" target="_blank" rel="noopener noreferrer" className="footer-link">
                  <Headphones size={18} />
                  <span>@thestresser</span>
                </a>
                <a href="https://t.me/theflashddosbox" target="_blank" rel="noopener noreferrer" className="footer-link">
                  <FileSearch size={18} />
                  <span>Public Channel</span>
                </a>
             </div>
          </div>
          <div className="footer-bottom">
             <p>© {new Date().getFullYear()} {TITLE_BASE}. Built for power. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Home({ user, onLogout }) {
  useNavigate();
  const [totalClients, setTotalClients] = useState(null);
  const [totalAttacks, setTotalAttacks] = useState(null);
  const [totalLoading, setTotalLoading] = useState(true);
  const [totalError, setTotalError] = useState(false);
  const [activeRuns, setActiveRuns] = useState(null);
  const [engines, setEngines] = useState([]);
  const [enginesLoading, setEnginesLoading] = useState(true);
  const [concStats, setConcStats] = useState({
    max: 0,
    active: 0,
    planRequired: false,
  });
  const [concLoading, setConcLoading] = useState(true);
  const [concError, setConcError] = useState(false);
  const [newsItems, setNewsItems] = useState([]);
  const [newsLoading, setNewsLoading] = useState(true);
  const [serverUsage, setServerUsage] = useState([]);
  const [serverUsageLoading, setServerUsageLoading] = useState(true);
  const [usageHistory, setUsageHistory] = useState([]);

  const loadHistory = async () => {
    try {
      const response = await fetch(`${API_BASE}/api/stats/history`, {
        credentials: 'include',
      });
      if (response.ok) {
        const data = await response.json();
        setUsageHistory(data);
      }
    } catch (e) {
      console.error('Failed to load usage history:', e);
    }
  };

  function UsageChart({ data }) {
    if (!data || data.length < 2) {
      return (
        <div className="usage-chart-placeholder">
          <span className="usage-chart-placeholder__text">Gathering real-time trend data...</span>
        </div>
      );
    }

    const maxEngine = Math.max(...data.map(d => d.engine), 1);
    const maxTargets = Math.max(...data.map(d => d.targets), 1);
    const chartMax = Math.max(maxEngine, maxTargets * 1.5);

    const width = 900;
    const height = 320;
    const padding = 20;

    const points = data.map((d, i) => {
      const x = padding + (i * (width - 2 * padding)) / (data.length - 1);
      const y = height - padding - (d.targets / chartMax) * (height - 2 * padding);
      return `${x},${y}`;
    }).join(' ');

    const fillPoints = `${padding},${height - padding} ${points} ${width - padding},${height - padding}`;

    return (
      <div className="usage-chart">
        <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
          <defs>
            <linearGradient id="usageGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.4" />
              <stop offset="100%" stopColor="var(--accent)" stopOpacity="0" />
            </linearGradient>
          </defs>

          {/* Grid lines */}
          <line x1={padding} y1={padding} x2={width - padding} y2={padding} stroke="var(--border)" strokeOpacity="0.3" strokeDasharray="4" />
          <line x1={padding} y1={(height - padding * 2) / 2 + padding} x2={width - padding} y2={(height - padding * 2) / 2 + padding} stroke="var(--border)" strokeOpacity="0.3" strokeDasharray="4" />

          {/* Area fill */}
          <polyline points={fillPoints} fill="url(#usageGradient)" />

          {/* Line */}
          <polyline
            points={points}
            fill="none"
            stroke="var(--accent)"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
            style={{ filter: 'drop-shadow(0 0 6px var(--accent-strong))' }}
          />

          {/* Data points */}
          {data.map((d, i) => {
            const x = padding + (i * (width - 2 * padding)) / (data.length - 1);
            const y = height - padding - (d.targets / chartMax) * (height - 2 * padding);
            return <circle key={i} cx={x} cy={y} r="3" fill="var(--accent-strong)" />;
          })}
        </svg>
      </div>
    );
  }

  useEffect(() => {
    let active = true;

    const loadStats = async () => {
      setTotalLoading(true);
      setTotalError(false);
      try {
        const response = await fetch(`${API_BASE}/api/stats`, {
          credentials: 'include',
        });
        if (!response.ok) {
          throw new Error('Failed to load stats');
        }
        const data = await response.json();
        if (!active) return;
        const total = Number(data?.totalClients);
        setTotalClients(Number.isFinite(total) ? total : null);
        const runs = Number(data?.activeRuns);
        setActiveRuns(Number.isFinite(runs) ? runs : null);
        const attacks = Number(data?.totalAttacks);
        setTotalAttacks(Number.isFinite(attacks) ? attacks : null);

        if (Array.isArray(data?.serverUsage)) {
          setServerUsage(data.serverUsage);
        }
      } catch (error) {
        if (!active) return;
        setTotalClients(null);
        setActiveRuns(null);
        setTotalAttacks(null);
        setServerUsage([]);
        setTotalError(true);
      } finally {
        if (active) {
          setTotalLoading(false);
          setServerUsageLoading(false);
        }
      }
    };

    loadStats();
    loadHistory();
    const intervalStats = setInterval(loadStats, 10000);
    const intervalHistory = setInterval(loadHistory, 60000);
    return () => {
      active = false;
      clearInterval(intervalStats);
      clearInterval(intervalHistory);
    };
  }, []);

  useEffect(() => {
    let active = true;

    const loadEngines = async () => {
      setEnginesLoading(true);
      try {
        const response = await fetch(`${API_BASE}/api/engines/active`, {
          credentials: 'include',
        });
        const data = await response.json().catch(() => ({}));
        const list = Array.isArray(data?.engines) ? data.engines : [];
        if (active) {
          setEngines(list);
        }
      } catch (error) {
        if (active) {
          setEngines([]);
        }
      } finally {
        if (active) {
          setEnginesLoading(false);
        }
      }
    };

    loadEngines();
    const timer = window.setInterval(() => {
      if (document.hidden) return;
      loadEngines();
    }, 10000);

    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, []);

  useEffect(() => {
    let active = true;

    const loadNews = async () => {
      setNewsLoading(true);
      try {
        const response = await fetch(`${API_BASE}/api/news`, {
          credentials: 'include',
        });
        if (!response.ok) {
          throw new Error('Failed to load news');
        }
        const data = await response.json().catch(() => ({}));
        const items = Array.isArray(data?.items) ? data.items : [];
        if (active) {
          setNewsItems(items);
        }
      } catch (error) {
        if (active) {
          setNewsItems([]);
        }
      } finally {
        if (active) {
          setNewsLoading(false);
        }
      }
    };

    loadNews();

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    const loadConcurrent = async (showLoading = true) => {
      if (showLoading) {
        setConcLoading(true);
      }
      setConcError(false);
      try {
        const [methodResponse, runsResponse] = await Promise.all([
          fetch(`${API_BASE}/api/run/method`, { credentials: 'include' }),
          fetch(`${API_BASE}/api/run/ongoing`, { credentials: 'include' }),
        ]);
        if (!methodResponse.ok || !runsResponse.ok) {
          throw new Error('Failed to load concurrent stats');
        }
        const methodData = await methodResponse.json().catch(() => ({}));
        const runsData = await runsResponse.json().catch(() => ({}));
        if (!active) return;

        const planRequired = Boolean(methodData?.planRequired);
        const maxConcRaw = Number(methodData?.maxConc);
        const maxConc = planRequired
          ? 0
          : Math.max(0, Math.trunc(Number.isFinite(maxConcRaw) ? maxConcRaw : 0));
        const runs = Array.isArray(runsData?.runs) ? runsData.runs : [];
        const activeConc = runs.reduce((sum, run) => {
          const engine = Math.trunc(Number(run?.engine) || 0);
          return sum + Math.max(0, engine);
        }, 0);

        setConcStats({ max: maxConc, active: activeConc, planRequired });
      } catch (error) {
        if (!active) return;
        setConcError(true);
        setConcStats({ max: 0, active: 0, planRequired: false });
      } finally {
        if (active && showLoading) {
          setConcLoading(false);
        }
      }
    };

    loadConcurrent(true);
    const timer = window.setInterval(() => {
      if (document.hidden) return;
      loadConcurrent(false);
    }, 8000);

    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, [user?.id]);

  const formatNewsDate = (value) => {
    if (!value) return '-';
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return value;
    return parsed.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
    });
  };

  const formatTotal = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return '-';
    return new Intl.NumberFormat('en-US').format(Math.trunc(amount));
  };

  const formatEngineDate = (value) => {
    if (!value) return '-';
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return value;
    return parsed.toLocaleString('id-ID');
  };

  const formatPlanDate = (value) => {
    if (!value) return '-';
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return value;
    return parsed.toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
    });
  };

  const formatTime = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return '-';
    if (amount >= 3600 && amount % 3600 === 0) {
      return `${amount / 3600}h`;
    }
    if (amount >= 60 && amount % 60 === 0) {
      return `${amount / 60}m`;
    }
    return `${amount}s`;
  };

  const formatDays = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return 'No expiry';
    return `${amount} day${amount === 1 ? '' : 's'}`;
  };

  const totalLabel = totalLoading
    ? '...'
    : totalError
      ? '-'
      : formatTotal(totalClients);
  const activeRunsLabel = totalLoading
    ? '...'
    : totalError
      ? '-'
      : formatTotal(activeRuns);
  const totalAttacksLabel = totalLoading
    ? '...'
    : totalError
      ? '-'
      : formatTotal(totalAttacks);
  const planInfo = user?.planDetails || null;
  const hasPlan = Boolean(user?.planId);
  const planName =
    planInfo?.display || planInfo?.name || user?.plan || 'No plan';
  const planAccess = hasPlan ? planInfo?.access || 'Basic' : '-';
  const planTime = hasPlan ? formatTime(planInfo?.time) : '-';
  const planConc = hasPlan
    ? formatTotal(planInfo?.conc ?? concStats.max)
    : '-';
  const planApiAccess = hasPlan
    ? planInfo?.apiAccess
      ? 'Yes'
      : 'No'
    : '-';
  const planStartedLabel = hasPlan
    ? user?.planStartedAt
      ? formatPlanDate(user.planStartedAt)
      : 'Not set'
    : '-';
  const planExpiresLabel = hasPlan
    ? user?.planExpiresAt
      ? formatPlanDate(user.planExpiresAt)
      : formatDays(planInfo?.expired)
    : '-';
  const planRowClass = 'profile-info__row';
  const planHint = hasPlan ? 'Active plan details' : 'No plan assigned';

  return (
    <section className="page home">
      <div className="home-shell">
        <div className="home-metrics">
          <div className="home-metric">
            <div className="home-metric__header">
              <span className="home-metric__label">Total client</span>
              <span className="home-metric__icon" aria-hidden="true" style={{ '--icon-color': '#10b981' }}>
                <svg viewBox="0 0 24 24" width="18" height="18">
                  <rect x="4" y="4" width="7" height="7" rx="1.6" fill="#10b981" stroke="none" />
                  <rect x="13" y="4" width="7" height="7" rx="1.6" fill="#8b5cf6" stroke="none" />
                  <rect x="4" y="13" width="7" height="7" rx="1.6" fill="#f59e0b" stroke="none" />
                  <rect x="13" y="13" width="7" height="7" rx="1.6" fill="#3b82f6" stroke="none" />
                </svg>
              </span>
            </div>
            <div className="home-metric__body">
              <span className="home-metric__value">{totalLabel}</span>
              <span className="home-metric__subtitle">+12% this month</span>
            </div>
          </div>
          <div className="home-metric">
            <div className="home-metric__header">
              <span className="home-metric__label">Active ongoing</span>
              <span className="home-metric__icon" aria-hidden="true" style={{ '--icon-color': '#8b5cf6' }}>
                <svg viewBox="0 0 24 24" width="18" height="18">
                  <path
                    d="M5 12h5l2-6 2 12 2-6h3"
                    stroke="#8b5cf6"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </span>
            </div>
            <div className="home-metric__body">
              <span className="home-metric__value">{activeRunsLabel}</span>
              <span className="home-metric__subtitle">+5% this month</span>
            </div>
          </div>
          <div className="home-metric">
            <div className="home-metric__header">
              <span className="home-metric__label">Total attack</span>
              <span className="home-metric__icon" aria-hidden="true" style={{ '--icon-color': '#f59e0b' }}>
                <svg viewBox="0 0 24 24" width="18" height="18">
                  <path
                    d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"
                    stroke="#f59e0b"
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </span>
            </div>
            <div className="home-metric__body">
              <span className="home-metric__value">{totalAttacksLabel}</span>
              <span className="home-metric__subtitle">+8% this month</span>
            </div>
          </div>
        </div>
        <div className="home-grid">
          <article className="news-card">
            <div className="news-card__header">
              <h2 className="news-card__heading">News</h2>
            </div>
            <div className="news-card__list">
              {newsItems.map((item) => (
                <div key={item.id} className="news-item">
                  <div className="news-item__meta">
                    <video
                      className="news-item__avatar"
                      autoPlay loop muted playsInline
                      src={bgVideo}
                    />
                    <div className="news-item__meta-text">
                      <span className="news-item__author">{item.title}</span>
                      <span className="news-item__message">{item.message}</span>
                    </div>
                  </div>
                </div>
              ))}
              {!newsLoading && !newsItems.length && (
                <div className="news-item">
                  <div className="news-item__meta">
                    <video
                      className="news-item__avatar"
                      autoPlay loop muted playsInline
                      src={bgVideo}
                    />
                    <div className="news-item__meta-text">
                      <span className="news-item__author">No updates</span>
                      <span className="news-item__message">
                        Check back soon.
                      </span>
                    </div>
                  </div>
                </div>
              )}
              {newsLoading && (
                <div className="news-item">
                  <div className="news-item__meta">
                    <video
                      className="news-item__avatar"
                      autoPlay loop muted playsInline
                      src={bgVideo}
                    />
                    <div className="news-item__meta-text">
                      <span className="news-item__author">Loading</span>
                      <span className="news-item__message">
                        Fetching updates...
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </article>
          <div className="panel-card panel-card--table panel-card--no-scroll">
            <div className="panel-card__header">
              <div>
                <h2>Plan info</h2>
                <span className="panel-card__hint">{planHint}</span>
              </div>
            </div>
            <div className="profile-info">
              {hasPlan ? (
                <>
                  <div className={planRowClass}>
                    <span className="profile-info__label">Plan</span>
                    <span className="profile-info__value">{planName}</span>
                  </div>
                  <div className="profile-info__row">
                    <span className="profile-info__label">Access</span>
                    <span className="profile-info__value">{planAccess}</span>
                  </div>
                  <div className="profile-info__row">
                    <span className="profile-info__label">Time</span>
                    <span className="profile-info__value">{planTime}</span>
                  </div>
                  <div className="profile-info__row">
                    <span className="profile-info__label">Concurrent</span>
                    <span className="profile-info__value">{planConc}</span>
                  </div>
                  <div className="profile-info__row">
                    <span className="profile-info__label">Balance</span>
                    <span className="profile-info__value">
                      {user?.balance !== undefined ? `$${user.balance.toLocaleString()}` : '$0'}
                    </span>
                  </div>
                  <div className="profile-info__row">
                    <span className="profile-info__label">Api access</span>
                    <span className="profile-info__value">{planApiAccess}</span>
                  </div>
                  <div className="profile-info__row">
                    <span className="profile-info__label">Started</span>
                    <span className="profile-info__value">{planStartedLabel}</span>
                  </div>
                  <div className="profile-info__row">
                    <span className="profile-info__label">Expires</span>
                    <span className="profile-info__value">{planExpiresLabel}</span>
                  </div>
                </>
              ) : (
                <div className="profile-buy">
                  <Link to="/shop" className="btn btn--primary btn--full">
                    Buy Plan
                  </Link>
                </div>
              )}
            </div>
          </div>


        </div>
      </div>
    </section>
  );
}

function EmptyPage() {
  return <section className="page" />;
}

function Panel({ user, onNotify }) {
  const PAGE_SIZE = 10;
  const [page, setPage] = useState(1);
  const [category, setCategory] = useState('');
  const [selectOpen, setSelectOpen] = useState(false);
  const [rangeValue, setRangeValue] = useState(0);
  const [rangeInput, setRangeInput] = useState('0');
  const [engineMax, setEngineMax] = useState(0);
  const [planRequired, setPlanRequired] = useState(false);
  const [target, setTarget] = useState('');
  const [port, setPort] = useState('');
  const [duration, setDuration] = useState('');
  const [runLoading, setRunLoading] = useState(false);
  const [runs, setRuns] = useState([]);
  const [runsLoading, setRunsLoading] = useState(false);
  const [stopLoadingId, setStopLoadingId] = useState(null);
  const [methodOptions, setMethodOptions] = useState([]);
  const [methodsLoading, setMethodsLoading] = useState(false);
  const selectRef = useRef(null);
  const runsLoadingRef = useRef(false);
  const methodsRequestRef = useRef(0);
  const userToken = user?.token || '';
  const tableRows = runs;
  const totalRows = tableRows.length;
  const totalPages = Math.max(1, Math.ceil(totalRows / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const startIndex = (currentPage - 1) * PAGE_SIZE;
  const pageRows = tableRows.slice(startIndex, startIndex + PAGE_SIZE);
  const rangeStart = totalRows === 0 ? 0 : startIndex + 1;
  const rangeEnd =
    totalRows === 0 ? 0 : Math.min(totalRows, startIndex + PAGE_SIZE);

  useEffect(() => {
    if (page !== currentPage) {
      setPage(currentPage);
    }
  }, [page, currentPage]);

  const loadMethods = useCallback(async () => {
    if (!userToken) {
      setMethodOptions([]);
      setPlanRequired(false);
      setEngineMax(0);
      return;
    }
    const requestId = methodsRequestRef.current + 1;
    methodsRequestRef.current = requestId;
    setMethodsLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/run/method`, {
        credentials: 'include',
        headers: {
          Authorization: `Bearer ${userToken}`,
        },
      });
      if (!response.ok) {
        throw new Error('Failed to load methods');
      }
      const data = await response.json();
      if (methodsRequestRef.current !== requestId) return;
      const options = Array.isArray(data?.options) ? data.options : [];
      setMethodOptions(options);
      setPlanRequired(Boolean(data?.planRequired));
      if (typeof data?.available === 'number') {
        setEngineMax(Math.max(0, data.available));
      } else if (typeof data?.connections === 'number') {
        setEngineMax(Math.max(0, data.connections));
      } else {
        setEngineMax(0);
      }
    } catch (error) {
      if (methodsRequestRef.current !== requestId) return;
      setMethodOptions([]);
      setPlanRequired(false);
      setEngineMax(0);
    } finally {
      if (methodsRequestRef.current === requestId) {
        setMethodsLoading(false);
      }
    }
  }, [userToken]);

  useEffect(() => {
    loadMethods();
  }, [loadMethods]);

  useEffect(() => {
    if (!methodOptions.length) return;
    const hasSelected = methodOptions.some(
      (option) => option.value === category
    );
    if (!hasSelected) {
      setCategory(methodOptions[0].value);
    }
  }, [methodOptions, category]);

  useEffect(() => {
    if (!methodOptions.length) {
      setEngineMax(0);
      return;
    }
    const selected = methodOptions.find(
      (option) => option.value === category
    );
    const selectedMax = Number(selected?.engineMax);
    if (Number.isFinite(selectedMax)) {
      setEngineMax(Math.max(0, selectedMax));
      return;
    }
    const fallbackMax = Number(methodOptions[0]?.engineMax);
    if (Number.isFinite(fallbackMax)) {
      setEngineMax(Math.max(0, fallbackMax));
    }
  }, [category, methodOptions]);

  useEffect(() => {
    if (!selectOpen) return undefined;
    const handleClick = (event) => {
      if (!selectRef.current?.contains(event.target)) {
        setSelectOpen(false);
      }
    };
    const handleKey = (event) => {
      if (event.key === 'Escape') {
        setSelectOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleKey);
    };
  }, [selectOpen]);

  useEffect(() => {
    if (!user?.id) return;
    loadRuns();
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return undefined;
    const timer = window.setInterval(() => {
      if (document.hidden) return;
      loadRuns();
    }, 3000);
    return () => window.clearInterval(timer);
  }, [user?.id]);

  useEffect(() => {
    const safeMax = Math.max(0, engineMax);
    if (rangeValue > safeMax) {
      setRangeValue(safeMax);
    }
  }, [engineMax, rangeValue]);

  const safeEngineMax = Math.max(0, engineMax);
  useEffect(() => {
    if (Number(rangeInput) !== rangeValue) {
      setRangeInput(rangeValue.toString());
    }
  }, [rangeValue]);

  const rangeProgress =
    safeEngineMax === 0 ? 0 : (rangeValue / safeEngineMax) * 100;

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const loadRuns = async () => {
    if (runsLoadingRef.current) return;
    runsLoadingRef.current = true;
    setRunsLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/run/ongoing`, {
        credentials: 'include',
      });
      if (!response.ok) {
        throw new Error('Failed to load runs');
      }
      const data = await response.json().catch(() => ({}));
      const list = Array.isArray(data?.runs) ? data.runs : [];
      const now = Date.now();
      const normalized = list.map((run) => {
        const expiresAtMs = run.expiresAt
          ? Date.parse(run.expiresAt)
          : now + (Number(run.durationSeconds) || 0) * 1000;

        // Preserve local countdown if possible to prevent jumping
        const existingRun = runs.find(r => r.id === run.job_id);
        const remainingSeconds = existingRun && Math.abs(existingRun.expiresAtMs - expiresAtMs) < 2000
          ? existingRun.remainingSeconds
          : Math.max(0, Math.ceil((expiresAtMs - now) / 1000));

        return {
          ...run,
          expiresAtMs,
          remainingSeconds,
        };
      });
      setRuns(normalized);
    } catch (error) {
      setRuns([]);
    } finally {
      setRunsLoading(false);
      runsLoadingRef.current = false;
    }
  };

  useEffect(() => {
    if (!runs.length) return undefined;
    const timer = window.setInterval(() => {
      const now = Date.now();
      setRuns((prev) =>
        prev
          .map((run) => {
            const expiresAtMs =
              Number.isFinite(run.expiresAtMs) && run.expiresAtMs > 0
                ? run.expiresAtMs
                : Date.parse(run.expiresAt || '') ||
                now + (Number(run.durationSeconds) || 0) * 1000;
            const remainingSeconds = Math.max(
              0,
              Math.ceil((expiresAtMs - now) / 1000)
            );
            return { ...run, expiresAtMs, remainingSeconds };
          })
          .filter((run) => run.remainingSeconds > 0)
      );
    }, 1000);
    return () => window.clearInterval(timer);
  }, [runs.length]);

  const selectedCategory =
    methodOptions.find((option) => option.value === category) ||
    (methodsLoading
      ? { value: '', label: 'Loading...' }
      : { value: '', label: 'Select method' });

  const handleRun = async (event) => {
    event.preventDefault();
    if (runLoading) return;

    if (!category) {
      notify('Select method first.', 'warning');
      return;
    }

    const selectedCategoryLayer =
      methodOptions.find((opt) => opt.value === category)?.layer || 'Layer 7';
    const isLayer4 = selectedCategoryLayer === 'Layer 4';

    if (!target.trim()) {
      notify('Target is required.', 'warning');
      return;
    }
    if (isLayer4 && !port.trim()) {
      notify('Port is required for Layer 4.', 'warning');
      return;
    }
    if (!duration.trim()) {
      notify('Duration is required.', 'warning');
      return;
    }
    if (planRequired) {
      notify('Please buy a plan first.', 'warning');
      return;
    }
    if (engineMax === 0) {
      notify('No concurrent capacity available.', 'warning');
      return;
    }
    if (rangeValue < 1) {
      notify('Concurrent must be at least 1.', 'warning');
      return;
    }

    const engineValue = Math.min(rangeValue, Math.max(1, engineMax));
    setRunLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/run`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          method: category,
          target: target.trim(),
          port: port.trim(),
          duration: duration.trim(),
          concurrent: engineValue,
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error || 'server_error';
        if (errorCode === 'concurrent_limit') {
          const remaining = Number(data?.remaining);
          if (Number.isFinite(remaining) && remaining >= 0) {
            setEngineMax(Math.max(0, remaining));
            notify(`Concurrent limit reached. Remaining ${remaining}.`, 'warning');
          } else {
            notify('Concurrent limit reached.', 'warning');
          }
        } else if (errorCode === 'cooldown_active') {
          const remaining = Number(data?.remaining) || 0;
          notify(`Attack cooldown active. Please wait ${remaining}s.`, 'warning');
        } else if (errorCode === 'engine_busy') {
          const maxAvailable = Number(data?.maxEngine);
          const details = data?.details;
          if (details === 'all_servers_failed') {
            const ids = data?.failedServerIds ? ` (IDs: ${data.failedServerIds.join(', ')})` : '';
            notify(`All ${data?.failCount || ''} servers failed${ids}.`, 'error');
          } else if (details === 'api_server_error') {
            notify('API Server returned error. Contact Admin.', 'error');
          } else if (details === 'connection_failed') {
            notify('Failed to connect to API Server.', 'error');
          } else if (Number.isFinite(maxAvailable) && maxAvailable >= 0) {
             notify(`Capacity reached. Max now is ${maxAvailable} concurrent.`, 'error');
          } else {
             notify('Server capacity reached. Try again later.', 'error');
          }
        } else if (errorCode === 'no_clients') {
          notify('No active clients available for this method.', 'error');
        } else if (errorCode === 'requires_premium') {
          notify('Method requires a Premium plan.', 'warning');
        } else if (errorCode === 'plan_required') {
          notify('Please buy a plan first.', 'warning');
        } else if (errorCode === 'duration_limit') {
          const maxSeconds = Number(data?.maxSeconds) || 300;
          notify(`Max duration ${maxSeconds}s.`, 'warning');
        } else if (errorCode === 'invalid_duration') {
          notify('Invalid duration.', 'warning');
        } else if (errorCode === 'invalid_target') {
          notify('Invalid target.', 'warning');
        } else if (errorCode === 'method_unavailable') {
          notify('No server available for this method.', 'warning');
        } else {
          notify(`Failed: ${errorCode}. Check server logs.`, 'error');
        }
        return;
      }
      
      const report = data?.report;
      if (report && report.failed > 0) {
        const ids = report.failedServerIds ? ` (Failed IDs: ${report.failedServerIds.join(', ')})` : '';
        notify(`Attack dispatched on ${report.success} servers. ${report.failed} failed${ids}.`, 'warning');
      } else {
        notify('Attack dispatched successfully.', 'success');
      }
      loadMethods();
      window.setTimeout(() => {
        loadRuns();
      }, 1500);
    } catch (error) {
      notify('Network error or server down. Please refresh.', 'error');
    } finally {
      setRunLoading(false);
    }
  };

  const handleStop = async (jobId) => {
    if (!jobId || stopLoadingId) return;
    setStopLoadingId(jobId);
    try {
      const response = await fetch(`${API_BASE}/api/run/stop`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jobId }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error || 'server_error';
        if (errorCode === 'not_found') {
          setRuns((prev) => prev.filter((run) => run.id !== jobId));
          notify('Run already finished.', 'info');
        } else {
          notify('Failed to stop run.', 'error');
        }
        return;
      }
      notify('Stop sent.', 'success');
      loadMethods();
      window.setTimeout(() => {
        loadRuns();
      }, 1500);
    } catch (error) {
      notify('Failed to stop run.', 'error');
    } finally {
      setStopLoadingId(null);
    }
  };

  return (
    <section className="page panel">
      <div className="panel-shell">
        <div className="panel-grid">
          <div className="panel-card panel-card--form">
            <div className="panel-card__header">
              <h2>Panel</h2>
            </div>
            <form className="panel-form" onSubmit={handleRun}>
              <div
                className={`panel-select ${selectOpen ? 'is-open' : ''}`}
                ref={selectRef}
              >
                <button
                  type="button"
                  className="panel-select__trigger"
                  onClick={() => setSelectOpen((open) => !open)}
                  aria-haspopup="listbox"
                  aria-expanded={selectOpen}
                >
                  <span className="panel-select__value" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    {selectedCategory.label}
                    {selectedCategory.access === 'Premium' && (
                      <span style={{ fontSize: '10px', padding: '2px 6px', background: 'var(--danger)', borderRadius: '4px', color: 'white' }}>
                        Premium
                      </span>
                    )}
                  </span>
                  <span className="panel-select__chevron" aria-hidden="true" />
                </button>
                {selectOpen && (
                  <div className="panel-select__menu" role="listbox">
                    {methodOptions.length ? (
                      methodOptions.map((option) => (
                        <button
                          key={option.value}
                          type="button"
                          role="option"
                          aria-selected={option.value === category}
                          className={`panel-select__option ${option.value === category ? 'is-active' : ''
                            }`}
                          onClick={() => {
                            setCategory(option.value);
                            setSelectOpen(false);
                          }}
                          style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
                        >
                          <span>{option.label}</span>
                          <span style={{ display: 'flex', gap: '6px' }}>
                            {option.access === 'Premium' && (
                              <span style={{ fontSize: '10px', padding: '2px 6px', background: 'var(--danger)', borderRadius: '4px', color: 'white' }}>
                                Premium
                              </span>
                            )}
                            <span style={{ fontSize: '10px', padding: '2px 6px', background: 'var(--border)', borderRadius: '4px' }}>
                              {option.layer === 'Layer 4' ? 'L4' : 'L7'}
                            </span>
                          </span>
                        </button>
                      ))
                    ) : (
                      <button
                        type="button"
                        className="panel-select__option is-disabled"
                        disabled
                      >
                        {methodsLoading ? 'Loading...' : 'No methods'}
                      </button>
                    )}
                  </div>
                )}
              </div>
              {methodOptions.find((opt) => opt.value === category)?.layer === 'Layer 4' ? (
                <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 120px', gap: 'var(--space-md)' }}>
                  <label className="field">
                    <span>Target IP</span>
                    <input
                      className="input"
                      type="text"
                      placeholder="1.1.1.1"
                      aria-label="Target IP"
                      value={target}
                      onChange={(event) => setTarget(event.target.value)}
                    />
                  </label>
                  <label className="field">
                    <span>Port</span>
                    <input
                      className="input"
                      type="number"
                      placeholder="80"
                      aria-label="Port"
                      value={port}
                      onChange={(event) => setPort(event.target.value)}
                    />
                  </label>
                </div>
              ) : (
                <label className="field">
                  <span>Target URL</span>
                  <input
                    className="input"
                    type="text"
                    placeholder="https://example.com"
                    aria-label="Target"
                    value={target}
                    onChange={(event) => setTarget(event.target.value)}
                  />
                </label>
              )}
              <label className="field">
                <span className="field__label-row">
                  <span>Duration</span>
                  <button
                    type="button"
                    className="field__info"
                    aria-label="Duration Active in Ongoing"
                  >
                    !
                  </button>
                  <span className="field__tooltip">
                    Duration Active in Ongoing
                  </span>
                </span>
                <input
                  className="input"
                  type="text"
                  placeholder="e.g. 30 minutes"
                  aria-label="Duration"
                  value={duration}
                  onChange={(event) => setDuration(event.target.value)}
                />
              </label>
              <label className="field">
                <span className="field__header">
                  <span className="field__label">Slots Count</span>
                </span>
                <input
                  className="input"
                  type="number"
                  placeholder="e.g. 1"
                  min="0"
                  max={safeEngineMax}
                  value={rangeInput}
                  onChange={(event) => {
                    const raw = event.target.value;
                    setRangeInput(raw);
                    if (raw === "") {
                      setRangeValue(0);
                      return;
                    }
                    const val = Number(raw);
                    if (!isNaN(val)) {
                      if (val >= 0 && val <= safeEngineMax) {
                        setRangeValue(val);
                      } else if (val > safeEngineMax) {
                        setRangeValue(safeEngineMax);
                        setRangeInput(safeEngineMax.toString());
                      }
                    }
                  }}
                  onBlur={() => {
                    if (rangeInput === "" || isNaN(Number(rangeInput))) {
                      setRangeInput("0");
                      setRangeValue(0);
                    } else {
                      setRangeInput(Number(rangeInput).toString());
                    }
                  }}
                  aria-label="Slots Input"
                />
              </label>
              <div className="panel-range">
                <div className="panel-range__meta">
                  <span className="panel-range__label">Adjust via Slider</span>
                  <span className="panel-range__value">{rangeValue}</span>
                </div>
                <input
                  className="range-input"
                  type="range"
                  min="0"
                  max={safeEngineMax}
                  value={rangeValue}
                  onChange={(event) => {
                    const val = Number(event.target.value);
                    setRangeValue(val);
                    setRangeInput(val.toString());
                  }}
                  style={{
                    '--range-progress': `${rangeProgress}%`,
                  }}
                  aria-label="Slots Slider"
                />
              </div>
              <button
                className="button button--primary"
                type="submit"
                disabled={runLoading || selectedCategory.isAllowed === false}
              >
                {runLoading ? 'Starting...' : (selectedCategory.isAllowed === false ? 'Upgrade Plan to Use' : 'Start Attack')}
              </button>
            </form>
          </div>

          <div className="panel-card panel-card--table">
            <div className="panel-card__header">
              <h2>Ongoing</h2>
              <span className="panel-card__hint">
                {runsLoading ? 'Loading...' : 'No data yet'}
              </span>
            </div>
            <div className="panel-table">
              <div className="panel-table__row panel-table__row--head">
                <span>Target</span>
                <span>Duration</span>
                <span>Slots</span>
                <span>Method</span>
              </div>
              <div className="panel-table__body">
                {pageRows.length ? (
                  pageRows.map((row) => (
                    <div key={row.id} className="panel-table__row">
                      <span data-label="Target">
                        {row.port > 0 ? `${row.target}:${row.port}` : row.target}
                      </span>
                      <span data-label="Duration">
                        {typeof row.remainingSeconds === 'number'
                          ? row.remainingSeconds
                          : row.duration}
                      </span>
                      <span data-label="Slots">{row.engine}</span>
                      <span data-label="Method">
                        {row.methodLabel || row.method}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="panel-table__empty">
                    {runsLoading ? 'Loading...' : 'None'}
                  </div>
                )}
              </div>
            </div>
            {totalRows > 0 && (
              <div className="panel-table__footer">
                <span className="panel-table__range">
                  {rangeStart} - {rangeEnd}
                </span>
                {totalPages > 1 && (
                  <div className="panel-table__pages">
                    {Array.from({ length: totalPages }, (_, index) => {
                      const pageNumber = index + 1;
                      return (
                        <button
                          key={pageNumber}
                          type="button"
                          className={`panel-page ${pageNumber === currentPage ? 'is-active' : ''
                            }`}
                          onClick={() => setPage(pageNumber)}
                        >
                          {pageNumber}
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function Plan({ user, onNotify, onUserUpdate }) {
  const [meta, setMeta] = useState({
    balance: Number(user?.balance) || 0,
    plan: user?.plan || 'No plan',
    planId: user?.planId || null,
  });
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [buyingId, setBuyingId] = useState(null);

  useEffect(() => {
    setMeta({
      balance: Number(user?.balance) || 0,
      plan: user?.plan || 'No plan',
      planId: user?.planId || null,
    });
  }, [user?.balance, user?.plan, user?.planId]);

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const formatCurrency = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return 'Rp 0';
    return `Rp ${new Intl.NumberFormat('id-ID').format(Math.trunc(amount))}`;
  };

  const formatTime = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return '-';
    if (amount >= 3600 && amount % 3600 === 0) {
      return `${amount / 3600}h`;
    }
    if (amount >= 60 && amount % 60 === 0) {
      return `${amount / 60}m`;
    }
    return `${amount}s`;
  };

  const formatDays = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return 'No expiry';
    return `${amount} day${amount === 1 ? '' : 's'}`;
  };

  const formatStock = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return 'Out of stock';
    return `${amount} slot${amount === 1 ? '' : 's'}`;
  };

  const loadPlans = async () => {
    setLoading(true);
    setError(false);
    try {
      const response = await fetch(`${API_BASE}/api/plans`, {
        credentials: 'include',
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data?.error || 'Failed to load plans');
      }
      const list = Array.isArray(data?.plans) ? data.plans : [];
      setPlans(list);
      setLastUpdated(new Date().toISOString());
    } catch (loadError) {
      setPlans([]);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPlans();
  }, []);

  const handleBuy = async (planId) => {
    if (!planId || buyingId) return;
    setBuyingId(planId);
    try {
      const response = await fetch(`${API_BASE}/api/plans/buy`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planId }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error;
        if (errorCode === 'insufficient_balance') {
          notify('Balance is not enough for this plan.', 'warning');
        } else if (errorCode === 'out_of_stock') {
          notify('Plan is out of stock.', 'warning');
        } else if (errorCode === 'plan_private') {
          notify('Plan is not available.', 'warning');
        } else if (errorCode === 'plan_not_found') {
          notify('Plan not found.', 'error');
        } else {
          notify('Failed to buy plan.', 'error');
        }
        return;
      }
      const nextBalance = Number(data?.balance);
      const nextPlan = data?.plan || meta.plan;
      const nextPlanId = data?.planId || planId;
      const nextPlanDetails =
        plans.find((plan) => plan.id === Number(nextPlanId)) || null;
      setMeta((prev) => ({
        ...prev,
        balance: Number.isFinite(nextBalance) ? nextBalance : prev.balance,
        plan: nextPlan,
        planId: nextPlanId,
      }));
      if (onUserUpdate) {
        onUserUpdate({
          balance: Number.isFinite(nextBalance) ? nextBalance : user?.balance,
          plan: nextPlan,
          planId: nextPlanId,
          planDetails: nextPlanDetails || user?.planDetails || null,
          planStartedAt: data?.planStartedAt ?? user?.planStartedAt,
          planExpiresAt: data?.planExpiresAt ?? user?.planExpiresAt,
        });
      }
      setPlans((prev) =>
        prev.map((plan) =>
          plan.id === planId
            ? { ...plan, stock: Math.max(0, (plan.stock || 0) - 1) }
            : plan
        )
      );
      notify('Plan activated.', 'success');
    } catch (purchaseError) {
      notify('Failed to buy plan.', 'error');
    } finally {
      setBuyingId(null);
    }
  };

  const formatDate = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('id-ID');
  };

  return (
    <section className="page shop">
      <div className="shop-shell">

        <div className="landing-section-header" style={{ marginTop: '4rem' }}>
          <h2>Available <span className="text-accent">Plans</span></h2>
          <p className="landing-hero__subtitle">
            {loading
              ? 'Fetching latest offers...'
              : plans.length
                ? `Choose from our ${plans.length} professional plans`
                : 'No plans available'}
          </p>
        </div>

        {plans.length ? (
          <div className="landing-plan-grid" style={{ marginTop: '2rem' }}>
            {plans.map((plan) => {
              const isCurrent = meta.planId === plan.id;
              const outOfStock = plan.stock <= 0;
              const canAfford = meta.balance >= plan.price;
              const disabled =
                buyingId === plan.id || outOfStock || isCurrent || !canAfford;

              return (
                <div
                  key={plan.id}
                  className={`landing-plan-card ${plan.name === 'GOD FLES' ? 'landing-plan-card--featured' : ''}`}
                >
                  <div className="landing-plan-card__header">
                    <h3>{plan.display || plan.name}</h3>
                    <div className="plan-tags" style={{ marginTop: '0.5rem' }}>
                      <span className="plan-tag">{plan.access}</span>
                      {plan.apiAccess && (
                        <span className="plan-tag plan-tag--accent">API</span>
                      )}
                      {isCurrent && (
                        <span className="plan-tag plan-tag--active">Active</span>
                      )}
                    </div>
                  </div>
                  <div className="landing-plan-price">
                    {formatCurrency(plan.price)}
                    <span>/ {plan.expired} days</span>
                  </div>
                  <ul className="landing-plan-features">
                    <li><Check size={16} className="text-accent" /> <strong>{formatTime(plan.time)}</strong> Max Duration</li>
                    <li><Check size={16} className="text-accent" /> <strong>{plan.conc}</strong> Concurrent Slots</li>
                    <li><Check size={16} className="text-accent" /> <strong>{plan.expired}</strong> Days Validity</li>
                    <li><Check size={16} className="text-accent" /> <strong>{formatTime(plan.cooldown)}</strong> Cooldown</li>
                    <li><Check size={16} className="text-accent" /> <strong>{formatStock(plan.stock)}</strong> Stock</li>
                    {plan.name === 'STARTER FLES' && <li><Check size={16} className="text-accent" /> 30s Cooldown</li>}
                    {plan.name === 'PRIME FLES' && <li><Check size={16} className="text-accent" /> 10s Cooldown</li>}
                    {(plan.name === 'GOD FLES' || plan.name === 'VIP FLES') && <li><Check size={16} className="text-accent" /> Zero Cooldown</li>}
                  </ul>
                  <div className="landing-plan-card__footer" style={{ marginTop: 'auto', width: '100%' }}>
                    <button
                      type="button"
                      className="button button--primary full-width"
                      onClick={() => handleBuy(plan.id)}
                      disabled={disabled}
                    >
                      {buyingId === plan.id
                        ? 'Processing...'
                        : isCurrent
                          ? 'Active Plan'
                          : outOfStock
                            ? 'Out of Stock'
                            : !canAfford
                              ? 'Insufficient Balance'
                              : 'Purchase Plan'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="shop-empty">
            {loading
              ? 'Loading plans...'
              : error
                ? 'Unable to load plans.'
                : 'No plans available right now.'}
          </div>
        )}
      </div>
    </section>
  );
}

function Profile({
  user,
  onNotify,
  onAccountDeleted,
}) {
  const tabs = [
    { id: 'profile', label: 'Profile' },
    { id: 'password', label: 'Change password' },
    { id: 'history', label: 'Login history' },
  ];
  const [activeTab, setActiveTab] = useState(
    tabs[0]?.id || tabs[1]?.id || 'profile'
  );
  const [history, setHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState(false);
  const [changingPassword, setChangingPassword] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deletePassword, setDeletePassword] = useState('');
  const [deleteCaptcha, setDeleteCaptcha] = useState('');
  const [deleteRefresh, setDeleteRefresh] = useState(0);
  const [deleteErrors, setDeleteErrors] = useState({
    password: false,
    captcha: false,
  });
  const navigate = useNavigate();
  const profileName = user?.username || 'Guest';
  const profilePlan = user?.plan || 'No plan';
  const uniqCodeValue = user?.uniqCode || '';
  const activeIndex = Math.max(
    0,
    tabs.findIndex((tab) => tab.id === activeTab)
  );

  const formatLoginTime = (value) => {
    if (!value) return '-';
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return value;
    return parsed.toLocaleString();
  };

  const formatBalance = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return '0';
    return new Intl.NumberFormat('en-US').format(Math.trunc(amount));
  };

  const formatCurrency = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return '-';
    return `Rp ${new Intl.NumberFormat('id-ID').format(Math.trunc(amount))}`;
  };

  const formatDate = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('id-ID');
  };

  const balanceValue = (
    <span className="profile-balance">
      <span className="profile-balance__row">
        <span className="profile-balance__amount">
          {formatBalance(user?.balance)}
        </span>
      </span>
    </span>
  );

  const profileDetails = [
    { label: 'Username', value: profileName },
    { label: 'Plan', value: profilePlan, tone: 'plan' },
    { label: 'Balance', valueNode: balanceValue },
    {
      label: 'Uniq code',
      value: uniqCodeValue || '-',
      tone: 'token',
      copyValue: uniqCodeValue,
    },
    { label: 'Joined', value: formatLoginTime(user?.created_at) },
  ];

  const copyUniqCode = async (value) => {
    if (!value) {
      onNotify?.('Uniq code is not available.', 'warning');
      return;
    }
    try {
      if (navigator?.clipboard?.writeText) {
        await navigator.clipboard.writeText(value);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = value;
        textarea.setAttribute('readonly', '');
        textarea.style.position = 'absolute';
        textarea.style.left = '-9999px';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      onNotify?.('Uniq code copied.', 'success');
    } catch (error) {
      onNotify?.('Unable to copy uniq code.', 'error');
    }
  };

  const getDeviceLabel = (userAgent = '') => {
    const ua = userAgent.toLowerCase();
    if (ua.includes('iphone')) return 'iPhone';
    if (ua.includes('ipad')) return 'iPad';
    if (ua.includes('android')) return 'Android';
    if (ua.includes('windows')) return 'Windows';
    if (ua.includes('macintosh') || ua.includes('mac os')) return 'macOS';
    if (ua.includes('linux')) return 'Linux';
    return 'Unknown device';
  };

  const getLocationLabel = (locale = '') => {
    if (!locale || locale === 'Unknown') return 'Unknown';
    return locale.toUpperCase();
  };

  useEffect(() => {
    if (activeTab !== 'history') return undefined;
    let active = true;

    const loadHistory = async () => {
      setHistoryLoading(true);
      setHistoryError(false);
      try {
        const response = await fetch(`${API_BASE}/api/login-history`, {
          credentials: 'include',
        });
        if (!response.ok) {
          throw new Error('Failed to load history');
        }
        const data = await response.json();
        if (!active) return;
        setHistory(Array.isArray(data.history) ? data.history : []);
      } catch (error) {
        if (!active) return;
        setHistory([]);
        setHistoryError(true);
      } finally {
        if (active) setHistoryLoading(false);
      }
    };

    loadHistory();

    return () => {
      active = false;
    };
  }, [activeTab]);

  const handlePasswordSubmit = (event) => {
    event.preventDefault();
    if (changingPassword) return;
    const form = new FormData(event.currentTarget);
    const currentPassword = String(form.get('currentPassword') || '');
    const nextPassword = String(form.get('nextPassword') || '');
    const confirmPassword = String(form.get('confirmPassword') || '');

    if (!currentPassword || !nextPassword) {
      onNotify?.('Please fill in all password fields.', 'warning');
      return;
    }
    if (nextPassword !== confirmPassword) {
      onNotify?.('Passwords do not match.', 'error');
      return;
    }
    const strongRule =
      /[A-Z]/.test(nextPassword) &&
      /[a-z]/.test(nextPassword) &&
      /[0-9]/.test(nextPassword) &&
      /[^A-Za-z0-9]/.test(nextPassword) &&
      nextPassword.length >= 12;
    if (!strongRule) {
      onNotify?.(
        'Password must be 12+ chars with upper, lower, number, and symbol.',
        'warning'
      );
      return;
    }

    const submitChange = async () => {
      setChangingPassword(true);
      try {
        const response = await fetch(`${API_BASE}/api/change-password`, {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            currentPassword,
            nextPassword,
            confirmPassword,
          }),
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          const error = data?.error;
          const message = {
            unauthorized: 'Session expired. Please login again.',
            rate_limited: 'Too many attempts. Try again later.',
            invalid_current_password: 'Current password is incorrect.',
            password_same: 'New password must be different.',
            password_mismatch: 'Passwords do not match.',
            weak_password:
              'Password must be 12+ chars with upper, lower, number, and symbol.',
            invalid_password: 'Invalid password.',
          }[error] || 'Unable to update password.';
          onNotify?.(message, 'error');
          return;
        }
        event.currentTarget.reset();
        onNotify?.('Password updated successfully.', 'success');
      } catch (error) {
        onNotify?.('Unable to update password. Please try again.', 'error');
      } finally {
        setChangingPassword(false);
      }
    };

    submitChange();
  };

  const openDeleteOverlay = () => {
    setDeletePassword('');
    setDeleteCaptcha('');
    setDeleteLoading(false);
    setDeleteErrors({ password: false, captcha: false });
    setDeleteOpen(true);
    setDeleteRefresh((value) => value + 1);
  };

  const closeDeleteOverlay = () => {
    if (deleteLoading) return;
    setDeleteOpen(false);
  };

  const handleDeleteSubmit = (event) => {
    event.preventDefault();
    if (deleteLoading) return;

    if (!deletePassword || !deleteCaptcha) {
      setDeleteErrors({
        password: !deletePassword,
        captcha: !deleteCaptcha,
      });
      onNotify?.('Enter your password and captcha to continue.', 'warning');
      return;
    }
    setDeleteErrors({ password: false, captcha: false });

    const submitDelete = async () => {
      setDeleteLoading(true);
      try {
        const response = await fetch(`${API_BASE}/api/delete-account`, {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            password: deletePassword,
            captcha: deleteCaptcha,
          }),
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          const error = data?.error;
          const nextErrors = {
            password: error === 'invalid_password',
            captcha: error === 'invalid_captcha',
          };
          setDeleteErrors(nextErrors);
          const message = {
            unauthorized: 'Session expired. Please login again.',
            rate_limited: 'Too many attempts. Try again later.',
            invalid_password: 'Password is incorrect.',
            invalid_captcha: 'Captcha is incorrect.',
          }[error] || 'Unable to delete account.';
          onNotify?.(message, 'error');
          setDeletePassword('');
          setDeleteCaptcha('');
          setDeleteRefresh((value) => value + 1);
          setDeleteLoading(false);
          return;
        }

        setDeleteOpen(false);
        setDeleteLoading(false);
        if (onAccountDeleted) {
          onAccountDeleted();
        } else {
          onNotify?.('Account deleted.', 'success');
        }
        navigate('/');
      } catch (error) {
        onNotify?.('Unable to delete account. Please try again.', 'error');
        setDeletePassword('');
        setDeleteCaptcha('');
        setDeleteRefresh((value) => value + 1);
        setDeleteLoading(false);
      }
    };

    submitDelete();
  };

  return (
    <section className="page profile">
      <div className="profile-shell">
        <div className="profile-card">
          <div className="profile-card__header">
            <video
              className="profile-card__avatar"
              autoPlay loop muted playsInline
              src={bgVideo}
            />
            <div className="profile-card__meta">
              <span className="profile-card__name">{profileName}</span>
              <span className="profile-card__plan">{profilePlan}</span>
            </div>
          </div>
          <div
            className="profile-actions"
            style={{
              '--tab-count': String(tabs.length),
              '--active-index': String(activeIndex),
            }}
          >
            {tabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                className={`profile-action ${activeTab === tab.id ? 'is-active' : ''
                  } ${tab.muted ? 'profile-action--muted' : ''}`}
                onClick={() => {
                  setActiveTab(tab.id);
                  if (tab.muted) {
                    onNotify?.('Coming soon.', 'info');
                  }
                }}
                title={tab.label}
              >
                <span className="profile-action__label">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>

        {activeTab === 'password' && (
          <div className="profile-card profile-card--panel">
            <div className="profile-panel__header">
              <h3>Change password</h3>
              <span className="profile-panel__hint">
                Update your account password
              </span>
            </div>
            <form className="profile-form" onSubmit={handlePasswordSubmit}>
              <label className="field">
                <span>Current password</span>
                <input
                  className="input"
                  type="password"
                  name="currentPassword"
                  autoComplete="current-password"
                  required
                />
              </label>
              <label className="field">
                <span>New password</span>
                <input
                  className="input"
                  type="password"
                  name="nextPassword"
                  minLength={12}
                  autoComplete="new-password"
                  required
                />
                <span className="field-hint">
                  Min 12 chars with upper, lower, number, symbol.
                </span>
              </label>
              <label className="field">
                <span>Confirm new password</span>
                <input
                  className="input"
                  type="password"
                  name="confirmPassword"
                  minLength={12}
                  autoComplete="new-password"
                  required
                />
              </label>
              <div className="profile-form__actions">
                <button
                  className="button button--primary"
                  type="submit"
                  disabled={changingPassword}
                >
                  {changingPassword ? 'Updating...' : 'Update password'}
                </button>
                <button className="button button--ghost" type="reset">
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {activeTab === 'history' && (
          <div className="profile-card profile-card--panel">
            <div className="profile-panel__header">
              <h3>Login history</h3>
              <span className="profile-panel__hint">
                {historyLoading
                  ? 'Loading history...'
                  : history.length
                    ? `Last login: ${formatLoginTime(history[0]?.created_at)}`
                    : 'No login history yet'}
              </span>
            </div>
            <div className="profile-table">
              <div className="profile-table__row profile-table__row--head">
                <span>Device</span>
                <span>Location</span>
                <span>IP</span>
                <span>Last login</span>
                <span>Status</span>
              </div>
              {history.map((item) => (
                <div key={item.id} className="profile-table__row">
                  <span className="profile-table__cell">
                    {getDeviceLabel(item.user_agent)}
                  </span>
                  <span className="profile-table__cell">
                    {getLocationLabel(item.locale)}
                  </span>
                  <span className="profile-table__cell">
                    {item.ip_address || '-'}
                  </span>
                  <span className="profile-table__cell">
                    {formatLoginTime(item.created_at)}
                  </span>
                  <span className="profile-table__cell profile-table__status">
                    Success
                  </span>
                </div>
              ))}
              {!historyLoading && history.length === 0 && !historyError && (
                <div className="profile-empty">No login history yet.</div>
              )}
              {historyError && (
                <div className="profile-empty profile-empty--error">
                  Unable to load login history.
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'profile' && (
          <>
            <div className="profile-card profile-card--panel">
              <div className="profile-panel__header">
                <h3>Profile overview</h3>
                <span className="profile-panel__hint">Account details</span>
              </div>
              <div className="profile-info">
                {profileDetails.map((detail) => (
                  <div
                    key={detail.label}
                    className={`profile-info__row ${detail.tone ? `profile-info__row--${detail.tone}` : ''
                      }`}
                  >
                    <span className="profile-info__label">{detail.label}</span>
                    <span className="profile-info__value-wrap">
                      {detail.valueNode ? (
                        detail.valueNode
                      ) : (
                        <span className="profile-info__value">
                          {detail.value}
                        </span>
                      )}
                      {detail.copyValue && (
                        <button
                          type="button"
                          className="profile-info__copy"
                          onClick={() => copyUniqCode(detail.copyValue)}
                          aria-label="Copy uniq code"
                          title="Copy uniq code"
                        >
                          <svg viewBox="0 0 24 24" width="16" height="16">
                            <rect
                              x="8"
                              y="8"
                              width="10"
                              height="10"
                              rx="2"
                            />
                            <path d="M6 16H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1" />
                          </svg>
                        </button>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="profile-card profile-card--danger">
              <div className="profile-panel__header">
                <h3>Delete account</h3>
                <span className="profile-panel__hint">Permanent action</span>
              </div>
              <p className="profile-danger__text">
                Deleting your account removes your access and clears your login
                history. This cannot be undone.
              </p>
              <div className="profile-danger__actions">
                <button
                  type="button"
                  className="button button--danger"
                  onClick={openDeleteOverlay}
                >
                  Delete account
                </button>
                <span className="profile-danger__note">
                  Requires password + captcha.
                </span>
              </div>
            </div>
          </>
        )}
      </div>

      {deleteOpen && (
        <div
          className={`delete-overlay ${deleteLoading ? 'delete-overlay--loading' : ''
            }`}
          role="dialog"
          aria-modal="true"
        >
          <button
            type="button"
            className="delete-overlay__backdrop"
            onClick={closeDeleteOverlay}
            aria-label="Close delete dialog"
            disabled={deleteLoading}
          />
          <div
            className={`delete-panel ${deleteLoading ? 'delete-panel--loading' : ''
              }`}
          >
            {deleteLoading ? (
              <div className="delete-loading">
                <span className="delete-loading__spinner" aria-hidden="true" />
                <span className="delete-loading__text">
                  Deleting your account...
                </span>
              </div>
            ) : (
              <>
                <button
                  type="button"
                  className="delete-panel__close"
                  onClick={closeDeleteOverlay}
                  aria-label="Close"
                >
                  x
                </button>
                <div className="delete-panel__header">
                  <h3>Confirm delete</h3>
                  <p>
                    Please enter your password and solve the captcha to delete
                    your account.
                  </p>
                </div>
                <form className="profile-form" onSubmit={handleDeleteSubmit}>
                  <label className="field">
                    <span>Password</span>
                    <input
                      className={`input ${deleteErrors.password ? 'input--error' : ''
                        }`}
                      type="password"
                      value={deletePassword}
                      onChange={(event) => {
                        setDeletePassword(event.target.value);
                        if (deleteErrors.password) {
                          setDeleteErrors((prev) => ({
                            ...prev,
                            password: false,
                          }));
                        }
                      }}
                      autoComplete="current-password"
                      required
                    />
                  </label>
                  <Captcha
                    value={deleteCaptcha}
                    onChange={(value) => {
                      setDeleteCaptcha(value);
                      if (deleteErrors.captcha) {
                        setDeleteErrors((prev) => ({ ...prev, captcha: false }));
                      }
                    }}
                    refreshToken={deleteRefresh}
                    onNotify={onNotify}
                    hasError={deleteErrors.captcha}
                  />
                  <div className="profile-form__actions">
                    <button className="button button--danger" type="submit">
                      Delete account
                    </button>
                    <button
                      className="button button--ghost"
                      type="button"
                      onClick={closeDeleteOverlay}
                    >
                      Cancel
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </section>
  );
}

function AdminUsersList({ onNotify }) {
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [query, setQuery] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const loadUsers = async (searchValue = query) => {
    setLoading(true);
    setError(false);
    try {
      const response = await fetch(
        `${API_BASE}/api/admin/users?q=${encodeURIComponent(searchValue)}`,
        { credentials: 'include' }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data?.error || 'Failed to load users');
      }
      const list = Array.isArray(data?.users) ? data.users : [];
      setUsers(list);
      setLastUpdated(new Date().toISOString());
    } catch (error) {
      setUsers([]);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadUsers(query);
    }, 400);
    return () => window.clearTimeout(timer);
  }, [query]);

  const formatCurrency = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return '-';
    return `Rp ${new Intl.NumberFormat('id-ID').format(Math.trunc(amount))}`;
  };

  const formatDate = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('id-ID');
  };

  return (
    <section className="page admin">
      <div className="panel-shell">
        <div className="panel-card panel-card--table admin-card">
          <div className="panel-card__header">
            <div className="panel-card__header-row">
              <div>
                <h2>Admin</h2>
                <span className="panel-card__hint">User management</span>
              </div>
              <div className="admin-toolbar">
                <input
                  className="input admin-search"
                  type="search"
                  placeholder="Search username"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                />
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() => loadUsers()}
                >
                  Refresh
                </button>
              </div>
            </div>
            <span className="admin-meta">
              {loading
                ? 'Loading users...'
                : `${users.length} user(s)`}{' '}
              {lastUpdated && !loading
                ? `- Updated ${formatDate(lastUpdated)}`
                : ''}
            </span>
          </div>
          <div className="panel-table admin-table">
            <div className="panel-table__row panel-table__row--head">
              <span>User</span>
              <span>Plan</span>
              <span>Balance</span>
              <span>Created</span>
              <span>Action</span>
            </div>
            <div className="panel-table__body">
              {users.length ? (
                users.map((user) => (
                  <div key={user.id} className="panel-table__row">
                    <span data-label="User">
                      <div className="admin-user">
                        <div className="admin-user__title">
                          {user.username}
                          {user.isAdmin && (
                            <span className="admin-tag">Admin</span>
                          )}
                        </div>
                        <div className="admin-user__meta">
                          ID {user.id}
                        </div>
                      </div>
                    </span>
                    <span data-label="Plan">{user.plan || 'No plan'}</span>
                    <span data-label="Balance">
                      {formatCurrency(user.balance)}
                    </span>
                    <span data-label="Created">
                      {formatDate(user.createdAt)}
                    </span>
                    <span data-label="Action">
                      <button
                        type="button"
                        className="button button--primary"
                        onClick={() => navigate(`/admin/users/${user.id}`)}
                      >
                        Manage
                      </button>
                    </span>
                  </div>
                ))
              ) : (
                <div className="panel-table__empty">
                  {loading
                    ? 'Loading...'
                    : error
                      ? 'Unable to load users.'
                      : 'No users found.'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function AdminUserDetail({ onNotify }) {
  const { userId } = useParams();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [savingAdmin, setSavingAdmin] = useState(false);
  const [savingBalance, setSavingBalance] = useState(false);
  const [savingPlan, setSavingPlan] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [balanceForm, setBalanceForm] = useState({ amount: '' });
  const [plans, setPlans] = useState([]);
  const [plansLoading, setPlansLoading] = useState(false);
  const [planForm, setPlanForm] = useState({ planId: '' });
  const [passwordForm, setPasswordForm] = useState({
    password: '',
    confirmPassword: '',
  });

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const formatCurrency = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return '-';
    return `Rp ${new Intl.NumberFormat('id-ID').format(Math.trunc(amount))}`;
  };

  const formatDate = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('id-ID');
  };

  const handleBack = () => navigate('/admin/users');

  useEffect(() => {
    let active = true;
    const parsedId = Number(userId);
    if (!Number.isInteger(parsedId)) {
      setError('Invalid user.');
      setLoading(false);
      return () => { };
    }

    const loadUser = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await fetch(
          `${API_BASE}/api/admin/users/${parsedId}`,
          { credentials: 'include' }
        );
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          throw new Error(data?.error || 'User not found');
        }
        if (active) {
          setUser(data?.user || null);
        }
      } catch (error) {
        if (active) {
          setUser(null);
          setError('User not found.');
        }
      } finally {
        if (active) setLoading(false);
      }
    };

    loadUser();

    return () => {
      active = false;
    };
  }, [userId]);

  useEffect(() => {
    let active = true;

    const loadPlans = async () => {
      setPlansLoading(true);
      try {
        const response = await fetch(`${API_BASE}/api/admin/plans`, {
          credentials: 'include',
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          throw new Error(data?.error || 'Failed to load plans');
        }
        if (active) {
          setPlans(Array.isArray(data?.plans) ? data.plans : []);
        }
      } catch (loadError) {
        if (active) {
          setPlans([]);
        }
      } finally {
        if (active) setPlansLoading(false);
      }
    };

    loadPlans();

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!user?.planId) {
      setPlanForm({ planId: '' });
      return;
    }
    setPlanForm({ planId: String(user.planId) });
  }, [user?.planId]);

  const handleToggleAdmin = async () => {
    if (!user || savingAdmin) return;
    setSavingAdmin(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/users/admin`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          isAdmin: !user.isAdmin,
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const error = data?.error;
        if (error === 'cannot_demote_self') {
          notify('Cannot remove your own admin access.', 'warning');
        } else if (error === 'last_admin') {
          notify('At least one admin is required.', 'warning');
        } else {
          notify('Failed to update admin access.', 'error');
        }
        return;
      }
      const nextIsAdmin = Boolean(data?.isAdmin);
      setUser((prev) => (prev ? { ...prev, isAdmin: nextIsAdmin } : prev));
      notify(
        nextIsAdmin ? 'Admin access granted.' : 'Admin access revoked.',
        'success'
      );
    } catch (error) {
      notify('Failed to update admin access.', 'error');
    } finally {
      setSavingAdmin(false);
    }
  };

  const handlePlanSubmit = async (event) => {
    event.preventDefault();
    if (!user || savingPlan) return;
    const rawPlanId = planForm.planId;
    const planId = rawPlanId ? Number(rawPlanId) : null;
    if (rawPlanId && !Number.isInteger(planId)) {
      notify('Invalid plan.', 'warning');
      return;
    }
    if ((planId ?? null) === (user.planId ?? null)) {
      notify('Plan is already active.', 'info');
      return;
    }
    setSavingPlan(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/users/plan`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, planId: rawPlanId }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error;
        if (errorCode === 'plan_not_found') {
          notify('Plan not found.', 'error');
        } else if (errorCode === 'invalid_plan') {
          notify('Invalid plan.', 'warning');
        } else {
          notify('Failed to update plan.', 'error');
        }
        return;
      }
      setUser((prev) =>
        prev
          ? {
            ...prev,
            plan:
              Object.prototype.hasOwnProperty.call(data || {}, 'plan')
                ? data.plan
                : prev.plan,
            planId:
              Object.prototype.hasOwnProperty.call(data || {}, 'planId')
                ? data.planId
                : prev.planId,
            planStartedAt:
              Object.prototype.hasOwnProperty.call(
                data || {},
                'planStartedAt'
              )
                ? data.planStartedAt
                : prev.planStartedAt,
            planExpiresAt:
              Object.prototype.hasOwnProperty.call(
                data || {},
                'planExpiresAt'
              )
                ? data.planExpiresAt
                : prev.planExpiresAt,
          }
          : prev
      );
      notify('Plan updated.', 'success');
    } catch (updateError) {
      notify('Failed to update plan.', 'error');
    } finally {
      setSavingPlan(false);
    }
  };

  const handleBalanceSubmit = async (event) => {
    event.preventDefault();
    if (!user || savingBalance) return;
    const rawAmount = Number(balanceForm.amount);
    const amount = Math.trunc(rawAmount);
    if (!Number.isFinite(rawAmount) || rawAmount <= 0 || amount !== rawAmount) {
      notify('Amount must be a positive integer.', 'warning');
      return;
    }
    setSavingBalance(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/users/balance`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, amount }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const error = data?.error;
        if (error === 'invalid_amount') {
          notify('Amount must be a positive integer.', 'warning');
        } else if (error === 'amount_too_large') {
          notify('Amount is too large.', 'warning');
        } else if (error === 'not_found') {
          notify('User not found.', 'error');
        } else {
          notify('Failed to add balance.', 'error');
        }
        return;
      }
      setUser((prev) =>
        prev ? { ...prev, balance: data?.balance ?? prev.balance } : prev
      );
      setBalanceForm({ amount: '' });
      notify('Balance updated.', 'success');
    } catch (error) {
      notify('Failed to add balance.', 'error');
    } finally {
      setSavingBalance(false);
    }
  };

  const handlePasswordSubmit = async (event) => {
    event.preventDefault();
    if (!user || savingPassword) return;
    if (!passwordForm.password || !passwordForm.confirmPassword) {
      notify('Password is required.', 'warning');
      return;
    }
    if (passwordForm.password !== passwordForm.confirmPassword) {
      notify('Passwords do not match.', 'warning');
      return;
    }

    setSavingPassword(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/users/password`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          password: passwordForm.password,
          confirmPassword: passwordForm.confirmPassword,
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const error = data?.error;
        if (error === 'weak_password') {
          notify('Password is too weak.', 'warning');
        } else if (error === 'password_mismatch') {
          notify('Passwords do not match.', 'warning');
        } else if (error === 'invalid_password') {
          notify('Password is invalid.', 'warning');
        } else {
          notify('Failed to update password.', 'error');
        }
        return;
      }
      setPasswordForm({ password: '', confirmPassword: '' });
      notify('Password updated.', 'success');
    } catch (error) {
      notify('Failed to update password.', 'error');
    } finally {
      setSavingPassword(false);
    }
  };

  if (loading) {
    return (
      <section className="page admin">
        <div className="status-card">Loading user...</div>
      </section>
    );
  }

  if (error || !user) {
    return (
      <section className="page admin">
        <div className="status-card">
          {error || 'User not found.'}
          <button
            type="button"
            className="button button--ghost admin-detail__back"
            onClick={handleBack}
          >
            Back to users
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="page admin">
      <div className="panel-shell">
        <div className="panel-card admin-detail">
          <div className="panel-card__header admin-detail__header">
            <div>
              <h2>Manage user</h2>
              <span className="panel-card__hint">ID {user.id}</span>
            </div>
            <button
              type="button"
              className="button button--ghost"
              onClick={handleBack}
            >
              Back to users
            </button>
          </div>
          <div className="admin-detail__body">
            <div className="admin-user">
              <div className="admin-user__title">
                {user.username}
                {user.isAdmin && <span className="admin-tag">Admin</span>}
              </div>
              <div className="admin-user__meta">
                Plan {user.plan || 'No plan'} - Balance{' '}
                {formatCurrency(user.balance)}
                {user.planExpiresAt
                  ? ` - Expires ${formatDate(user.planExpiresAt)}`
                  : ''}
              </div>
            </div>
            <div className="admin-detail__section">
              <span className="admin-detail__label">Admin access</span>
              <button
                type="button"
                className={`button ${user.isAdmin ? 'button--ghost' : 'button--primary'
                  }`}
                onClick={handleToggleAdmin}
                disabled={savingAdmin}
              >
                {savingAdmin
                  ? 'Updating...'
                  : user.isAdmin
                    ? 'Remove admin'
                    : 'Make admin'}
              </button>
            </div>
            <form
              className="panel-form admin-detail__form"
              onSubmit={handlePlanSubmit}
            >
              <label className="field">
                <span>Plan</span>
                <select
                  className="input"
                  value={planForm.planId}
                  onChange={(event) =>
                    setPlanForm({ planId: event.target.value })
                  }
                  disabled={plansLoading}
                >
                  <option value="">
                    {plansLoading ? 'Loading plans...' : 'No plan'}
                  </option>
                  {plans.map((plan) => (
                    <option key={plan.id} value={plan.id}>
                      {plan.display || plan.name}
                    </option>
                  ))}
                </select>
              </label>
              <span className="field-hint">
                {user.planExpiresAt
                  ? `Current plan expires ${formatDate(user.planExpiresAt)}`
                  : 'Assign a plan to reset access.'}
              </span>
              <div className="admin-detail__actions">
                <button
                  type="submit"
                  className="button button--primary"
                  disabled={savingPlan || plansLoading}
                >
                  {savingPlan ? 'Updating...' : 'Update plan'}
                </button>
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() =>
                    setPlanForm({
                      planId: user.planId ? String(user.planId) : '',
                    })
                  }
                  disabled={savingPlan}
                >
                  Cancel
                </button>
              </div>
            </form>
            <form
              className="panel-form admin-detail__form"
              onSubmit={handleBalanceSubmit}
            >
              <label className="field">
                <span>Add balance</span>
                <input
                  className="input"
                  type="number"
                  min="1"
                  step="1"
                  inputMode="numeric"
                  value={balanceForm.amount}
                  onChange={(event) =>
                    setBalanceForm({ amount: event.target.value })
                  }
                  placeholder="e.g. 50000"
                />
              </label>
              <span className="field-hint">
                Amount will be added to current balance.
              </span>
              <div className="admin-detail__actions">
                <button
                  type="submit"
                  className="button button--primary"
                  disabled={savingBalance}
                >
                  {savingBalance ? 'Updating...' : 'Add balance'}
                </button>
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() => setBalanceForm({ amount: '' })}
                  disabled={savingBalance}
                >
                  Cancel
                </button>
              </div>
            </form>
            <form
              className="panel-form admin-detail__form"
              onSubmit={handlePasswordSubmit}
            >
              <label className="field">
                <span>New password</span>
                <input
                  className="input"
                  type="password"
                  value={passwordForm.password}
                  onChange={(event) =>
                    setPasswordForm((prev) => ({
                      ...prev,
                      password: event.target.value,
                    }))
                  }
                  autoComplete="new-password"
                />
              </label>
              <label className="field">
                <span>Confirm password</span>
                <input
                  className="input"
                  type="password"
                  value={passwordForm.confirmPassword}
                  onChange={(event) =>
                    setPasswordForm((prev) => ({
                      ...prev,
                      confirmPassword: event.target.value,
                    }))
                  }
                  autoComplete="new-password"
                />
              </label>
              <span className="field-hint">
                Use 12+ characters with uppercase, lowercase, number, and symbol.
              </span>
              <div className="admin-detail__actions">
                <button
                  type="submit"
                  className="button button--primary"
                  disabled={savingPassword}
                >
                  {savingPassword ? 'Updating...' : 'Update password'}
                </button>
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={handleBack}
                  disabled={savingPassword}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function ApiManager({ onNotify }) {
  const [label, setLabel] = useState('');
  const [allowlistItems, setAllowlistItems] = useState([]);
  const [maxTime, setMaxTime] = useState('');
  const [maxEngine, setMaxEngine] = useState('');
  const [selectedMethods, setSelectedMethods] = useState([]);
  const [methodMenuOpen, setMethodMenuOpen] = useState(false);
  const [autoBind, setAutoBind] = useState(false);
  const [entries, setEntries] = useState([]);
  const [apiView, setApiView] = useState('keys');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [availableMethods, setAvailableMethods] = useState([]);
  const methodSelectRef = useRef(null);

  const methodOptions = availableMethods.length ? availableMethods : [
    { value: 'HTTP-CONNECT', label: 'HTTP-CONNECT' },
    { value: 'HTTP', label: 'HTTP' },
    { value: 'HTTPS', label: 'HTTPS' },
    { value: 'TCP', label: 'TCP' },
    { value: 'UDP', label: 'UDP' },
  ];
  const allMethodValues = methodOptions.map((method) => method.value);

  const apiDocs = [
    { id: 1, method: 'GET', path: '/api/attack', summary: '?key=...&host=...&port=...&time=...&method=...&concurrent=...' },
    { id: 2, method: 'GET', path: '/api/attack/ongoing', summary: 'Lists your active attacks. ?key=...' },
    { id: 3, method: 'GET', path: '/api/attack/stop', summary: 'Stop an attack. ?key=...&jobId=...' },
  ];
  const apiLogs = []; // Not implemented yet

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const loadData = async () => {
    setLoading(true);
    try {
      const [keysRes, methodsRes] = await Promise.all([
        fetch(`${API_BASE}/api/keys`, { credentials: 'include' }),
        fetch(`${API_BASE}/api/run/method`, { credentials: 'include' })
      ]);
      const keysData = await keysRes.json().catch(() => ({}));
      const methodsData = await methodsRes.json().catch(() => ({}));

      if (keysRes.ok && Array.isArray(keysData.keys)) setEntries(keysData.keys);
      if (methodsRes.ok && Array.isArray(methodsData.options)) {
        setAvailableMethods(methodsData.options);
      }
    } catch (e) {
      notify('Failed to load API data', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (!methodMenuOpen) return undefined;
    const handleClick = (event) => {
      if (!methodSelectRef.current?.contains(event.target)) {
        setMethodMenuOpen(false);
      }
    };
    const handleKey = (event) => {
      if (event.key === 'Escape') {
        setMethodMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleKey);
    };
  }, [methodMenuOpen]);

  const maskKey = (value) => {
    if (!value) return '-';
    if (value.length <= 10) return value;
    return `${value.slice(0, 6)}...${value.slice(-4)}`;
  };

  const addAllowlistItem = () => {
    setAllowlistItems((prev) => {
      if (prev.length >= 10) return prev;
      return [...prev, ''];
    });
  };

  const updateAllowlistItem = (index, value) => {
    setAllowlistItems((prev) =>
      prev.map((item, currentIndex) =>
        currentIndex === index ? value : item
      )
    );
  };

  const removeAllowlistItem = (index) => {
    setAllowlistItems((prev) =>
      prev.filter((_, currentIndex) => currentIndex !== index)
    );
  };

  const toggleMethod = (value) => {
    setSelectedMethods((prev) => {
      if (prev.includes(value)) {
        return prev.filter((item) => item !== value);
      }
      return [...prev, value];
    });
  };

  const toggleAllMethods = () => {
    setSelectedMethods((prev) =>
      prev.length === allMethodValues.length ? [] : allMethodValues
    );
  };

  const handleCreate = async (event) => {
    event.preventDefault();
    if (saving) return;

    const trimmedLabel = label.trim();
    if (!trimmedLabel) {
      notify('Label is required.', 'warning');
      return;
    }
    setSaving(true);

    const numericMaxTime = Math.max(0, Math.trunc(Number(maxTime) || 0));
    const numericMaxEngine = Math.max(0, Math.trunc(Number(maxEngine) || 0));
    const normalizedAllowlist = allowlistItems
      .map((value) => value.trim())
      .filter(Boolean);
    const allMethodsSelected =
      selectedMethods.length === allMethodValues.length &&
      selectedMethods.length > 0;

    const payload = {
      name: trimmedLabel,
      autoBind,
      allowedMethods: allMethodsSelected ? allMethodValues : selectedMethods,
      whitelistIps: normalizedAllowlist,
      maxTime: numericMaxTime,
      maxEngine: numericMaxEngine
    };

    try {
      const res = await fetch(`${API_BASE}/api/keys`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        if (data.error === 'max_keys_reached') notify('Maximum keys reached (10)', 'warning');
        else notify(data.error || 'Failed to create key', 'error');
        return;
      }
      notify(`Key Created: ${data.key}`, 'success');
      setLabel('');
      setAllowlistItems([]);
      setMaxTime('');
      setMaxEngine('');
      setSelectedMethods([]);
      setAutoBind(false);
      setMethodMenuOpen(false);
      loadData();
    } catch (err) {
      notify('Failed to create key', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Are you sure you want to delete this key?')) return;
    try {
      const res = await fetch(`${API_BASE}/api/keys/${id}`, {
        method: 'DELETE',
        credentials: 'include'
      });
      if (!res.ok) throw new Error('fail');
      notify('Key deleted', 'success');
      loadData();
    } catch (e) {
      notify('Failed to delete key', 'error');
    }
  };

  const selectedLabels = methodOptions
    .filter((method) => selectedMethods.includes(method.value))
    .map((method) => method.label);
  const allMethodsSelected =
    selectedMethods.length === allMethodValues.length &&
    selectedMethods.length > 0;
  const methodSummary = (() => {
    if (!methodOptions.length) return 'No methods';
    if (!selectedMethods.length) return 'Select method';
    if (allMethodsSelected) return 'All methods';
    if (selectedLabels.length <= 2) return selectedLabels.join(', ');
    return `${selectedLabels.slice(0, 2).join(', ')} +${selectedLabels.length - 2
      }`;
  })();

  const tableLayout =
    apiView === 'docs'
      ? {
        minWidth: '760px',
        columns: 'minmax(0, 0.5fr) minmax(0, 1.2fr) minmax(0, 2fr)',
      }
      : apiView === 'logs'
        ? {
          minWidth: '900px',
          columns:
            'minmax(0, 1fr) minmax(0, 1.2fr) minmax(0, 0.6fr) minmax(0, 1fr)',
        }
        : {
          minWidth: '1180px',
          columns:
            'minmax(0, 1fr) minmax(0, 1.2fr) minmax(0, 1.4fr) minmax(0, 0.7fr) minmax(0, 0.7fr) minmax(0, 1.4fr) minmax(0, 0.6fr) minmax(0, 0.6fr)',
        };

  return (
    <section className="page panel">
      <div className="panel-shell">
        <div className="panel-grid">
          <div className="panel-card panel-card--form">
            <div className="panel-card__header">
              <h2>API Manager</h2>
              <span className="panel-card__hint">Create API key</span>
            </div>
            <form className="panel-form" onSubmit={handleCreate}>
              <label className="field">
                <span>Label</span>
                <input
                  className="input"
                  type="text"
                  placeholder="Primary key"
                  value={label}
                  onChange={(event) => setLabel(event.target.value)}
                />
              </label>
              <div className="field">
                <span className="field__label-row api-allowlist__label">
                  <span>Allow list</span>
                  <span className="api-allowlist__meta">
                    <span className="api-allowlist__count">
                      {allowlistItems.length}/10
                    </span>
                    <button
                      type="button"
                      className="button button--ghost button--compact"
                      onClick={addAllowlistItem}
                      disabled={allowlistItems.length >= 10 || saving}
                    >
                      + Add IP
                    </button>
                  </span>
                </span>
                <div className="api-allowlist">
                  {allowlistItems.length ? (
                    allowlistItems.map((value, index) => (
                      <div key={`ip-${index}`} className="api-allowlist__row">
                        <input
                          className="input api-allowlist__input"
                          type="text"
                          placeholder="e.g. 103.24.0.0/16"
                          value={value}
                          onChange={(event) =>
                            updateAllowlistItem(index, event.target.value)
                          }
                        />
                        <button
                          type="button"
                          className="button button--ghost button--compact api-allowlist__remove"
                          onClick={() => removeAllowlistItem(index)}
                        >
                          Remove
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="api-allowlist__empty">
                      No IP added. Use + Add IP to include allowlist.
                    </div>
                  )}
                </div>
              </div>
              <div className="api-form__grid">
                <label className="field">
                  <span>Max time (seconds)</span>
                  <input
                    className="input"
                    type="number"
                    min="1"
                    inputMode="numeric"
                    placeholder="600"
                    value={maxTime}
                    onChange={(event) => setMaxTime(event.target.value)}
                  />
                </label>
                <label className="field">
                  <span>Max engine</span>
                  <input
                    className="input"
                    type="number"
                    min="1"
                    inputMode="numeric"
                    placeholder="1"
                    value={maxEngine}
                    onChange={(event) => setMaxEngine(event.target.value)}
                  />
                </label>
              </div>
              <div className="field">
                <span>Allow method</span>
                <div
                  className={`panel-select api-methods ${methodMenuOpen ? 'is-open' : ''
                    }`}
                  ref={methodSelectRef}
                >
                  <button
                    type="button"
                    className="panel-select__trigger"
                    onClick={() => setMethodMenuOpen((open) => !open)}
                    aria-haspopup="listbox"
                    aria-expanded={methodMenuOpen}
                  >
                    <span className="panel-select__value">{methodSummary}</span>
                    <span className="panel-select__chevron" aria-hidden="true" />
                  </button>
                  {methodMenuOpen && (
                    <div className="panel-select__menu" role="listbox">
                      <button
                        type="button"
                        className={`panel-select__option api-select__option ${allMethodsSelected ? 'is-active' : ''
                          }`}
                        onClick={toggleAllMethods}
                      >
                        <span className="api-select__checkbox" />
                        <span>All methods</span>
                      </button>
                      {methodOptions.map((option) => {
                        const isActive = selectedMethods.includes(option.value);
                        return (
                          <button
                            key={option.value}
                            type="button"
                            className={`panel-select__option api-select__option ${isActive ? 'is-active' : ''
                              }`}
                            onClick={() => toggleMethod(option.value)}
                          >
                            <span className="api-select__checkbox" />
                            <span>{option.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
              <label className="api-toggle">
                <span className="api-toggle__text">
                  <span>Auto bind</span>
                  <span className="api-toggle__hint">
                    Bind key to creator automatically.
                  </span>
                </span>
                <span className="api-toggle__switch">
                  <input
                    className="api-toggle__input"
                    type="checkbox"
                    checked={autoBind}
                    onChange={(event) => setAutoBind(event.target.checked)}
                  />
                  <span className="api-toggle__control">
                    <span className="api-toggle__thumb" />
                  </span>
                </span>
              </label>
              <button
                className="button button--primary"
                type="submit"
                disabled={saving}
              >
                {saving ? 'Creating...' : 'Create key'}
              </button>
            </form>
          </div>

          <div className="panel-card panel-card--table">
            <div className="panel-card__header">
              <div className="panel-card__header-row">
                <div>
                  <h2>API Manager</h2>
                  <span className="panel-card__hint">
                    {apiView === 'keys'
                      ? entries.length
                        ? `${entries.length} keys`
                        : 'No keys yet'
                      : apiView === 'docs'
                        ? 'API docs'
                        : 'Latest activity'}
                  </span>
                </div>
                <div className="panel-tabs" role="tablist">
                  <button
                    type="button"
                    className={`panel-tab ${apiView === 'keys' ? 'is-active' : ''
                      }`}
                    onClick={() => setApiView('keys')}
                  >
                    ApiKey List
                  </button>
                  <button
                    type="button"
                    className={`panel-tab ${apiView === 'docs' ? 'is-active' : ''
                      }`}
                    onClick={() => setApiView('docs')}
                  >
                    Docs
                  </button>
                  <button
                    type="button"
                    className={`panel-tab ${apiView === 'logs' ? 'is-active' : ''
                      }`}
                    onClick={() => setApiView('logs')}
                  >
                    Logs API
                  </button>
                </div>
              </div>
            </div>
            <div
              className="panel-table panel-table--scroll"
              style={{
                '--table-min-width': tableLayout.minWidth,
                '--table-columns': tableLayout.columns,
              }}
            >
              <div className="panel-table__scroll">
                <div className="panel-table__row panel-table__row--head">
                  {apiView === 'keys' && (
                    <>
                      <span>Label</span>
                      <span>Key</span>
                      <span>Allowlist</span>
                      <span>Max time</span>
                      <span>Max engine</span>
                      <span>Methods</span>
                      <span>Auto bind</span>
                      <span>Action</span>
                    </>
                  )}
                  {apiView === 'docs' && (
                    <>
                      <span>Method</span>
                      <span>Endpoint</span>
                      <span>Description</span>
                    </>
                  )}
                  {apiView === 'logs' && (
                    <>
                      <span>Time</span>
                      <span>Event</span>
                      <span>Status</span>
                      <span>IP</span>
                    </>
                  )}
                </div>
                <div className="panel-table__body">
                  {loading && <div className="panel-table__empty">Loading...</div>}
                  {!loading && apiView === 'keys' &&
                    (entries.length ? (
                      entries.map((entry) => (
                        <div key={entry.id} className="panel-table__row">
                          <span data-label="Label">{entry.name}</span>
                          <span data-label="Key">{maskKey(entry.key)}</span>
                          <span data-label="Allowlist">
                            {Array.isArray(entry.whitelistIps) && entry.whitelistIps.length
                              ? entry.whitelistIps.join(', ')
                              : 'All'}
                          </span>
                          <span data-label="Max time">
                            {entry.maxTime ? `${entry.maxTime}s` : '-'}
                          </span>
                          <span data-label="Max engine">
                            {entry.maxEngine || '-'}
                          </span>
                          <span data-label="Methods">
                            {entry.allowedMethods?.length === allMethodValues.length || entry.allowedMethods?.length === 0
                              ? 'All'
                              : entry.allowedMethods?.length
                                ? entry.allowedMethods.join(', ')
                                : '-'}
                          </span>
                          <span data-label="Auto bind">
                            {entry.autoBind ? 'On' : 'Off'}
                          </span>
                          <span data-label="Action">
                            <div style={{ display: 'flex', gap: '4px' }}>
                              <button
                                className="button button--ghost button--compact"
                                style={{ padding: '4px 8px' }}
                                onClick={() => {
                                  navigator.clipboard.writeText(entry.key);
                                  notify('Key copied to clipboard', 'success');
                                }}
                              >
                                Copy
                              </button>
                              <button
                                className="button button--ghost button--danger button--compact"
                                style={{ padding: '4px 8px' }}
                                onClick={() => handleDelete(entry.id)}
                              >
                                Revoke
                              </button>
                            </div>
                          </span>
                        </div>
                      ))
                    ) : (
                      <div className="panel-table__empty">No keys yet.</div>
                    ))}
                  {!loading && apiView === 'docs' &&
                    (apiDocs.length ? (
                      apiDocs.map((row) => (
                        <div key={row.id} className="panel-table__row">
                          <span data-label="Method">{row.method}</span>
                          <span data-label="Endpoint">{row.path}</span>
                          <span data-label="Description">{row.summary}</span>
                        </div>
                      ))
                    ) : (
                      <div className="panel-table__empty">No docs yet.</div>
                    ))}
                  {!loading && apiView === 'logs' &&
                    (apiLogs.length ? (
                      apiLogs.map((row) => (
                        <div key={row.id} className="panel-table__row">
                          <span data-label="Time">{row.time}</span>
                          <span data-label="Event">{row.event}</span>
                          <span data-label="Status">{row.status}</span>
                          <span data-label="IP">{row.ip}</span>
                        </div>
                      ))
                    ) : (
                      <div className="panel-table__empty">No logs yet.</div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function AdminPlans({ onNotify }) {
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [query, setQuery] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: '',
    display: '',
    time: '600',
    conc: '1',
    expired: '0',
    stock: '0',
    price: '0',
    access: 'Basic',
    apiAccess: false,
    private: false,
    cooldown: '0',
  });

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const formatCurrency = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return '-';
    return `Rp ${new Intl.NumberFormat('id-ID').format(Math.trunc(amount))}`;
  };

  const formatDate = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('id-ID');
  };

  const formatDays = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return 'No expiry';
    return `${amount}d`;
  };

  const formatTime = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return '-';
    return `${amount}s`;
  };

  const previewLabel =
    form.display.trim() || form.name.trim() || 'New plan';
  const previewAccess = form.access || 'Basic';
  const previewTime = formatTime(Number(form.time) || 0);
  const previewConc = Number(form.conc) || 1;
  const previewExpired = formatDays(Number(form.expired) || 0);
  const previewPrice = formatCurrency(Number(form.price) || 0);
  const previewCooldown = formatTime(Number(form.cooldown) || 0);

  const loadPlans = async (search = query) => {
    setLoading(true);
    setError(false);
    try {
      const response = await fetch(
        `${API_BASE}/api/admin/plans?q=${encodeURIComponent(search)}`,
        { credentials: 'include' }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data?.error || 'Failed to load plans');
      }
      setPlans(Array.isArray(data?.plans) ? data.plans : []);
      setLastUpdated(new Date().toISOString());
    } catch (loadError) {
      setPlans([]);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPlans();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadPlans(query);
    }, 400);
    return () => window.clearTimeout(timer);
  }, [query]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (saving) return;
    if (!form.name.trim() || !form.display.trim()) {
      notify('Name and display are required.', 'warning');
      return;
    }
    setSaving(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/plans`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name.trim(),
          display: form.display.trim(),
          time: Number(form.time),
          conc: Number(form.conc),
          expired: Number(form.expired),
          stock: Number(form.stock),
          price: Number(form.price),
          access: form.access,
          apiAccess: form.apiAccess,
          private: form.private,
          cooldown: Number(form.cooldown),
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error;
        if (errorCode === 'plan_exists') {
          notify('Plan name already exists.', 'warning');
        } else if (errorCode === 'invalid_name') {
          notify('Invalid plan name.', 'warning');
        } else if (errorCode === 'invalid_display') {
          notify('Invalid plan display name.', 'warning');
        } else {
          notify('Failed to create plan.', 'error');
        }
        return;
      }
      notify('Plan created.', 'success');
      setForm({
        name: '',
        display: '',
        time: '600',
        conc: '1',
        expired: '0',
        stock: '0',
        price: '0',
        cooldown: '0',
        access: 'Basic',
        apiAccess: false,
        private: false,
      });
      loadPlans();
    } catch (submitError) {
      notify('Failed to create plan.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (planId) => {
    if (!planId) return;
    const confirmed = window.confirm('Delete this plan?');
    if (!confirmed) return;
    try {
      const response = await fetch(`${API_BASE}/api/admin/plans/${planId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error;
        if (errorCode === 'cannot_delete_default') {
          notify('Default plan cannot be deleted.', 'warning');
        } else if (errorCode === 'plan_in_use') {
          notify('Plan is assigned to users.', 'warning');
        } else {
          notify('Failed to delete plan.', 'error');
        }
        return;
      }
      notify('Plan deleted.', 'success');
      loadPlans();
    } catch (deleteError) {
      notify('Failed to delete plan.', 'error');
    }
  };

  return (
    <section className="page admin">
      <div className="panel-shell">
        <div className="panel-card panel-card--form plan-form-card">
          <div className="panel-card__header">
            <h2>Create plan</h2>
            <span className="panel-card__hint">Set plan limits</span>
          </div>
          <form className="panel-form plan-form" onSubmit={handleSubmit}>
            <div className="plan-form__section">
              <div className="plan-form__section-header">
                <span className="plan-form__section-title">Basics</span>
                <span className="plan-form__section-hint">
                  Identity shown to users
                </span>
              </div>
              <div className="plan-form-grid">
                <label className="field">
                  <span>Name</span>
                  <input
                    className="input"
                    type="text"
                    value={form.name}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        name: event.target.value,
                      }))
                    }
                    placeholder="starter"
                  />
                  <span className="field-hint">
                    Unique id, use simple text.
                  </span>
                </label>
                <label className="field">
                  <span>Display</span>
                  <input
                    className="input"
                    type="text"
                    value={form.display}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        display: event.target.value,
                      }))
                    }
                    placeholder="Starter Plan"
                  />
                  <span className="field-hint">
                    This is shown in UI.
                  </span>
                </label>
                <label className="field">
                  <span>Access</span>
                  <select
                    className="input"
                    value={form.access}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        access: event.target.value,
                      }))
                    }
                  >
                    <option value="Basic">Basic</option>
                    <option value="Premium">Premium</option>
                  </select>
                </label>
              </div>
            </div>

            <div className="plan-form__section">
              <div className="plan-form__section-header">
                <span className="plan-form__section-title">Limits</span>
                <span className="plan-form__section-hint">
                  Runtime and concurrency
                </span>
              </div>
              <div className="plan-form-grid">
                <label className="field">
                  <span>Time (seconds)</span>
                  <input
                    className="input"
                    type="number"
                    min="0"
                    step="1"
                    value={form.time}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        time: event.target.value,
                      }))
                    }
                  />
                </label>
                <label className="field">
                  <span>Conc</span>
                  <input
                    className="input"
                    type="number"
                    min="1"
                    step="1"
                    value={form.conc}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        conc: event.target.value,
                      }))
                    }
                  />
                </label>
                <label className="field">
                  <span>Expired (days)</span>
                  <input
                    className="input"
                    type="number"
                    min="0"
                    step="1"
                    value={form.expired}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        expired: event.target.value,
                      }))
                    }
                  />
                </label>
                <label className="field">
                  <span>Cooldown (seconds)</span>
                  <input
                    className="input"
                    type="number"
                    min="0"
                    step="1"
                    value={form.cooldown}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        cooldown: event.target.value,
                      }))
                    }
                  />
                </label>
              </div>
            </div>

            <div className="plan-form__section">
              <div className="plan-form__section-header">
                <span className="plan-form__section-title">Commerce</span>
                <span className="plan-form__section-hint">
                  Stock and pricing
                </span>
              </div>
              <div className="plan-form-grid">
                <label className="field">
                  <span>Stock</span>
                  <input
                    className="input"
                    type="number"
                    min="0"
                    step="1"
                    value={form.stock}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        stock: event.target.value,
                      }))
                    }
                  />
                </label>
                <label className="field">
                  <span>Price</span>
                  <input
                    className="input"
                    type="number"
                    min="0"
                    step="1"
                    value={form.price}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        price: event.target.value,
                      }))
                    }
                  />
                </label>
              </div>
            </div>

            <div className="plan-form__section plan-form__section--flags">
              <div className="plan-form__section-header">
                <span className="plan-form__section-title">Visibility</span>
                <span className="plan-form__section-hint">
                  Access control flags
                </span>
              </div>
              <div className="plan-toggle-grid">
                <label className="plan-toggle">
                  <span className="plan-toggle__text">
                    <span>API access</span>
                    <span className="plan-toggle__hint">
                      Enable API Manager
                    </span>
                  </span>
                  <input
                    type="checkbox"
                    checked={form.apiAccess}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        apiAccess: event.target.checked,
                      }))
                    }
                  />
                </label>
                <label className="plan-toggle">
                  <span className="plan-toggle__text">
                    <span>Private</span>
                    <span className="plan-toggle__hint">
                      Hide from client list
                    </span>
                  </span>
                  <input
                    type="checkbox"
                    checked={form.private}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        private: event.target.checked,
                      }))
                    }
                  />
                </label>
              </div>
            </div>

            <div className="plan-form__footer">
              <div className="plan-form__summary">
                <span className="plan-form__summary-title">Preview</span>
                <span className="plan-form__summary-value">
                  {previewLabel} · {previewAccess} · {previewTime} · Conc{' '}
                  {previewConc} · {previewExpired} · {previewPrice} · CD{' '}
                  {previewCooldown}
                </span>
              </div>
              <div className="admin-detail__actions">
                <button
                  type="submit"
                  className="button button--primary"
                  disabled={saving}
                >
                  {saving ? 'Saving...' : 'Create plan'}
                </button>
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() =>
                    setForm({
                      name: '',
                      display: '',
                      time: '600',
                      conc: '1',
                      expired: '0',
                      stock: '0',
                      price: '0',
                      access: 'Basic',
                      apiAccess: false,
                      private: false,
                    })
                  }
                  disabled={saving}
                >
                  Reset
                </button>
              </div>
            </div>
          </form>
        </div>

        <div className="panel-card panel-card--table admin-card">
          <div className="panel-card__header">
            <div className="panel-card__header-row">
              <div>
                <h2>Plans</h2>
                <span className="panel-card__hint">Plan inventory</span>
              </div>
              <div className="admin-toolbar">
                <input
                  className="input admin-search"
                  type="search"
                  placeholder="Search plan"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                />
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() => loadPlans()}
                >
                  Refresh
                </button>
              </div>
            </div>
            <span className="admin-meta">
              {loading ? 'Loading plans...' : `${plans.length} plan(s)`}{' '}
              {lastUpdated && !loading
                ? `- Updated ${formatDate(lastUpdated)}`
                : ''}
            </span>
          </div>
          <div className="panel-table panel-table--scroll admin-plan-table">
            <div className="panel-table__scroll">
              <div className="panel-table__row panel-table__row--head">
                <span>Plan</span>
                <span>Access</span>
                <span>Time</span>
                <span>Conc</span>
                <span>API</span>
                <span>Expired</span>
                <span>Stock</span>
                <span>Price</span>
                <span>Private</span>
                <span>Created</span>
                <span>Action</span>
              </div>
              <div className="panel-table__body">
                {plans.length ? (
                  plans.map((plan) => (
                    <div key={plan.id} className="panel-table__row">
                      <span data-label="Plan">
                        <div className="admin-user">
                          <div className="admin-user__title">
                            {plan.display || plan.name}
                          </div>
                          <div className="admin-user__meta">
                            {plan.name}
                          </div>
                        </div>
                      </span>
                      <span data-label="Access">{plan.access}</span>
                      <span data-label="Time">{formatTime(plan.time)}</span>
                      <span data-label="Conc">{plan.conc}</span>
                      <span data-label="API">
                        {plan.apiAccess ? 'Yes' : 'No'}
                      </span>
                      <span data-label="Expired">
                        {formatDays(plan.expired)}
                      </span>
                      <span data-label="Stock">{plan.stock}</span>
                      <span data-label="Price">
                        {formatCurrency(plan.price)}
                      </span>
                      <span data-label="Private">
                        {plan.private ? 'Yes' : 'No'}
                      </span>
                      <span data-label="Created">
                        {formatDate(plan.createdAt)}
                      </span>
                      <span data-label="Action">
                        <div className="admin-plan__actions">
                          <button
                            type="button"
                            className="button button--ghost"
                            onClick={() => navigate(`/admin/plans/${plan.id}`)}
                          >
                            Edit
                          </button>
                          <button
                            type="button"
                            className="button button--danger"
                            onClick={() => handleDelete(plan.id)}
                          >
                            Delete
                          </button>
                        </div>
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="panel-table__empty">
                    {loading
                      ? 'Loading...'
                      : error
                        ? 'Unable to load plans.'
                        : 'No plans found.'}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function MethodsList({ onNotify }) {
  const [methods, setMethods] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [query, setQuery] = useState('');
  const [activeLayer, setActiveLayer] = useState('Layer 7');

  const loadMethods = async () => {
    setLoading(true);
    setError(false);
    try {
      const response = await fetch(`${API_BASE}/api/methods`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error();
      const data = await response.json();
      setMethods(data.methods || []);
    } catch (err) {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMethods();
  }, []);

  const filtered = methods.filter((m) => {
    const s = query.toLowerCase();
    const matchesQuery = m.name?.toLowerCase().includes(s) || m.display?.toLowerCase().includes(s);
    const matchesLayer = activeLayer === 'All' || m.layer === activeLayer;
    return matchesQuery && matchesLayer;
  });

  return (
    <section className="page">
      <div className="methods-card-container">
        <div className="methods-toolbar">
          <div className="methods-filter">
             <button 
               className={`methods-filter__item ${activeLayer === 'Layer 7' ? 'is-active' : ''}`}
               onClick={() => setActiveLayer('Layer 7')}
             >
               Layer 7
             </button>
             <button 
               className={`methods-filter__item ${activeLayer === 'Layer 4' ? 'is-active' : ''}`}
               onClick={() => setActiveLayer('Layer 4')}
             >
               Layer 4
             </button>
          </div>
          <div className="admin-toolbar">
            <input
              className="input admin-search"
              type="search"
              placeholder="Search vector..."
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
            <button
              type="button"
              className="button button--ghost"
              onClick={() => loadMethods()}
            >
              Refresh
            </button>
          </div>
        </div>

        {loading ? (
          <div className="methods-status">
            <div className="loading-spinner" />
            <span>Loading power...</span>
          </div>
        ) : error ? (
          <div className="methods-status is-error">
             <AlertTriangle size={24} />
             <span>Failed to load methods.</span>
          </div>
        ) : (
          <div className="methods-grid">
            {filtered.length ? (
              filtered.map((method) => (
                <div key={method.id} className="method-card">
                  <div className="method-card__bg" />
                  <div className="method-card__content">
                    <div className="method-card__header">
                      <div className={`method-card__icon ${method.layer === 'Layer 7' ? 'is-l7' : 'is-l4'}`}>
                        {method.layer === 'Layer 7' ? <Globe size={20} /> : <Zap size={20} />}
                      </div>
                      <div className="method-card__meta">
                        <span className="method-card__layer">{method.layer || 'L7'}</span>
                        <span className={`method-card__badge ${method.access === 'Premium' ? 'is-premium' : 'is-basic'}`}>
                          {method.access}
                        </span>
                      </div>
                    </div>
                    
                    <h3 className="method-card__title">{method.display}</h3>
                    <p className="method-card__description">{method.description || '-'}</p>
                    
                    <div className="method-card__footer">
                       <div className="method-card__stat">
                          <Activity size={14} />
                          <span>Stable</span>
                       </div>
                       {method.apiAccess && (
                         <div className="method-card__stat">
                            <Terminal size={14} />
                            <span>API ready</span>
                         </div>
                       )}
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="methods-empty">
                <FileSearch size={48} />
                <p>No methods matches your criteria.</p>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

function AdminMethods({ onNotify }) {
  const [methods, setMethods] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [query, setQuery] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState({
    name: '',
    display: '',
    description: '',
    access: 'Basic',
    apiAccess: false,
    layer: 'Layer 7',
  });

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const formatDate = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('id-ID');
  };

  const loadMethods = async (search = query) => {
    setLoading(true);
    setError(false);
    try {
      const response = await fetch(
        `${API_BASE}/api/admin/methods?q=${encodeURIComponent(search)}`,
        { credentials: 'include' }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data?.error || 'Failed to load methods');
      }
      setMethods(Array.isArray(data?.methods) ? data.methods : []);
      setLastUpdated(new Date().toISOString());
    } catch (loadError) {
      setMethods([]);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMethods();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadMethods(query);
    }, 400);
    return () => window.clearTimeout(timer);
  }, [query]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (saving) return;
    if (!form.name.trim() || !form.display.trim()) {
      notify('Name and display are required.', 'warning');
      return;
    }
    setSaving(true);
    try {
      if (editingId) {
        const response = await fetch(`${API_BASE}/api/admin/methods/${editingId}`, {
          method: 'PUT',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            display: form.display.trim(),
            description: form.description.trim(),
            access: form.access,
            apiAccess: form.apiAccess,
            layer: form.layer,
          }),
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          notify(data?.error || 'Failed to update method.', 'error');
          return;
        }
        notify('Method updated.', 'success');
      } else {
        const response = await fetch(`${API_BASE}/api/admin/methods`, {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: form.name.trim(),
            display: form.display.trim(),
            description: form.description.trim(),
            access: form.access,
            apiAccess: form.apiAccess,
            layer: form.layer,
          }),
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          const errorCode = data?.error;
          if (errorCode === 'method_exists') {
            notify('Method already exists.', 'warning');
          } else if (errorCode === 'invalid_name') {
            notify('Invalid method name.', 'warning');
          } else if (errorCode === 'invalid_display') {
            notify('Invalid display name.', 'warning');
          } else {
            notify('Failed to create method.', 'error');
          }
          return;
        }
        notify('Method created.', 'success');
      }
      setEditingId(null);
      setForm({
        name: '',
        display: '',
        description: '',
        access: 'Basic',
        apiAccess: false,
        layer: 'Layer 7',
      });
      loadMethods();
    } catch (submitError) {
      notify(editingId ? 'Failed to update method.' : 'Failed to create method.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (methodId) => {
    if (!methodId) return;
    const confirmed = window.confirm('Delete this method?');
    if (!confirmed) return;
    try {
      const response = await fetch(
        `${API_BASE}/api/admin/methods/${methodId}`,
        { method: 'DELETE', credentials: 'include' }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        notify(data?.error || 'Failed to delete method.', 'error');
        return;
      }
      notify('Method deleted.', 'success');
      loadMethods();
    } catch (deleteError) {
      notify('Failed to delete method.', 'error');
    }
  };

  const handleEdit = (method) => {
    setEditingId(method.id);
    setForm({
      name: method.name,
      display: method.display,
      description: method.description || '',
      access: method.access || 'Basic',
      apiAccess: method.apiAccess || false,
      layer: method.layer || 'Layer 7',
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setForm({
      name: '',
      display: '',
      description: '',
      access: 'Basic',
      apiAccess: false,
      layer: 'Layer 7',
    });
  };

  return (
    <section className="page admin">
      <div className="panel-shell">
        <div className="panel-card panel-card--form method-form-card">
          <div className="panel-card__header">
            <h2>{editingId ? 'Edit method' : 'Create method'}</h2>
            <span className="panel-card__hint">
              {editingId ? `Editing: ${form.name}` : 'Panel catalog'}
            </span>
          </div>
          <form className="panel-form method-form" onSubmit={handleSubmit}>
            <div className="plan-form-grid">
              <label className="field">
                <span>Method name</span>
                <input
                  className="input"
                  type="text"
                  value={form.name}
                  disabled={!!editingId}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      name: event.target.value,
                    }))
                  }
                  placeholder="HTTP-CONNECT"
                />
                <span className="field-hint">
                  Used as the internal identifier.
                </span>
              </label>
              <label className="field">
                <span>Display name</span>
                <input
                  className="input"
                  type="text"
                  value={form.display}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      display: event.target.value,
                    }))
                  }
                  placeholder="HTTP Connect"
                />
                <span className="field-hint">
                  This appears in the panel.
                </span>
              </label>
              <label className="field">
                <span>Access</span>
                <select
                  className="input"
                  value={form.access}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      access: event.target.value,
                    }))
                  }
                >
                  <option value="Basic">Basic</option>
                  <option value="Premium">Premium</option>
                </select>
              </label>
              <label className="field">
                <span>Layer</span>
                <select
                  className="input"
                  value={form.layer}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      layer: event.target.value,
                    }))
                  }
                >
                  <option value="Layer 7">Layer 7</option>
                  <option value="Layer 4">Layer 4</option>
                </select>
              </label>
            </div>
            <div className="plan-toggle-grid">
              <label className="plan-toggle">
                <span className="plan-toggle__text">
                  <span>API access</span>
                  <span className="plan-toggle__hint">
                    Enable API use later
                  </span>
                </span>
                <input
                  type="checkbox"
                  checked={form.apiAccess}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      apiAccess: event.target.checked,
                    }))
                  }
                />
              </label>
            </div>
            <div className="plan-form-grid" style={{ gridTemplateColumns: '1fr', marginTop: '16px' }}>
              <label className="field">
                <span>Description</span>
                <textarea
                  className="input"
                  rows="3"
                  style={{ resize: 'vertical', minHeight: '80px', paddingTop: '12px' }}
                  value={form.description}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      description: event.target.value,
                    }))
                  }
                  placeholder="Enter a brief description of this attack vector..."
                />
                <span className="field-hint">
                  This description will be shown in the Method List.
                </span>
              </label>
            </div>
            <div className="admin-detail__actions">
              <button
                type="submit"
                className="button button--primary"
                disabled={saving}
              >
                {saving ? 'Saving...' : editingId ? 'Update method' : 'Create method'}
              </button>
              {editingId ? (
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={handleCancelEdit}
                  disabled={saving}
                >
                  Cancel
                </button>
              ) : (
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() =>
                    setForm({
                      name: '',
                      display: '',
                      description: '',
                      access: 'Basic',
                      apiAccess: false,
                      layer: 'Layer 7',
                    })
                  }
                  disabled={saving}
                >
                  Reset
                </button>
              )}
            </div>
          </form>
        </div>

        <div className="panel-card panel-card--table admin-card">
          <div className="panel-card__header">
            <div className="panel-card__header-row">
              <div>
                <h2>Methods</h2>
                <span className="panel-card__hint">Available methods</span>
              </div>
              <div className="admin-toolbar">
                <input
                  className="input admin-search"
                  type="search"
                  placeholder="Search method"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                />
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() => loadMethods()}
                >
                  Refresh
                </button>
              </div>
            </div>
            <span className="admin-meta">
              {loading
                ? 'Loading methods...'
                : `${methods.length} method(s)`}{' '}
              {lastUpdated && !loading
                ? `- Updated ${formatDate(lastUpdated)}`
                : ''}
            </span>
          </div>
          <div className="panel-table admin-method-table">
            <div className="panel-table__row panel-table__row--head">
              <span>Name</span>
              <span>Display</span>
              <span>Access</span>
              <span>Layer</span>
              <span>API</span>
              <span>Created</span>
              <span>Action</span>
            </div>
            <div className="panel-table__body">
              {methods.length ? (
                methods.map((method) => (
                  <div key={method.id} className="panel-table__row">
                    <span data-label="Name">
                      <div className="admin-user">
                        <div className="admin-user__title">{method.name}</div>
                        <div className="admin-user__meta">
                          Hash {method.hash}
                        </div>
                      </div>
                    </span>
                    <span data-label="Display">{method.display}</span>
                    <span data-label="Access">{method.access}</span>
                    <span data-label="Layer">{method.layer || 'Layer 7'}</span>
                    <span data-label="API">
                      {method.apiAccess ? 'Yes' : 'No'}
                    </span>
                    <span data-label="Created">
                      {formatDate(method.createdAt)}
                    </span>
                    <span data-label="Action">
                       <div className="admin-actions">
                        <button
                          type="button"
                          className="button button--ghost button--sm"
                          onClick={() => handleEdit(method)}
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          className="button button--danger button--sm"
                          onClick={() => handleDelete(method.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </span>
                  </div>
                ))
              ) : (
                <div className="panel-table__empty">
                  {loading
                    ? 'Loading...'
                    : error
                      ? 'Unable to load methods.'
                      : 'No methods found.'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function AdminServers({ onNotify }) {
  const navigate = useNavigate();
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [query, setQuery] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);
  const [saving, setSaving] = useState(false);
  const [methodOptions, setMethodOptions] = useState([]);
  const [methodsLoading, setMethodsLoading] = useState(false);
  const [selectedMethods, setSelectedMethods] = useState([]);
  const [methodMenuOpen, setMethodMenuOpen] = useState(false);
  const methodSelectRef = useRef(null);
  const [form, setForm] = useState({
    name: '',
    apiUrl: '',
    durationMax: '600',
    engine: '1',
    status: 'Online',
  });

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  useEffect(() => {
    if (!methodMenuOpen) return undefined;
    const handleClick = (event) => {
      if (!methodSelectRef.current?.contains(event.target)) {
        setMethodMenuOpen(false);
      }
    };
    const handleKey = (event) => {
      if (event.key === 'Escape') {
        setMethodMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleKey);
    };
  }, [methodMenuOpen]);

  const formatDate = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('id-ID');
  };

  const loadMethods = async () => {
    setMethodsLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/methods`, {
        credentials: 'include',
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data?.error || 'Failed to load methods');
      }
      setMethodOptions(Array.isArray(data?.methods) ? data.methods : []);
    } catch (loadError) {
      setMethodOptions([]);
    } finally {
      setMethodsLoading(false);
    }
  };

  const loadServers = async (search = query) => {
    setLoading(true);
    setError(false);
    try {
      const response = await fetch(
        `${API_BASE}/api/admin/servers?q=${encodeURIComponent(search)}`,
        { credentials: 'include' }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data?.error || 'Failed to load servers');
      }
      setServers(Array.isArray(data?.servers) ? data.servers : []);
      setLastUpdated(new Date().toISOString());
    } catch (loadError) {
      setServers([]);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMethods();
    loadServers();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadServers(query);
    }, 400);
    return () => window.clearTimeout(timer);
  }, [query]);

  const methodLookup = methodOptions.reduce((acc, method) => {
    acc[method.hash] = method.display || method.name || method.hash;
    return acc;
  }, {});

  const selectedLabels = methodOptions
    .filter((method) => selectedMethods.includes(method.hash))
    .map((method) => method.display || method.name || method.hash);
  const allMethodsSelected = selectedMethods.includes('ALL');
  const methodSummary = (() => {
    if (methodsLoading) return 'Loading methods...';
    if (!methodOptions.length) return 'No methods';
    if (!selectedMethods.length) return 'Select method';
    if (allMethodsSelected) return 'All methods';
    if (selectedLabels.length <= 2) return selectedLabels.join(', ');
    return `${selectedLabels.slice(0, 2).join(', ')} +${selectedLabels.length - 2
      }`;
  })();

  const toggleAllMethods = () => {
    setSelectedMethods((prev) => (prev.includes('ALL') ? [] : ['ALL']));
  };

  const toggleMethod = (value) => {
    setSelectedMethods((prev) => {
      if (prev.includes('ALL')) {
        return [value];
      }
      if (prev.includes(value)) {
        return prev.filter((entry) => entry !== value);
      }
      return [...prev, value];
    });
  };

  const formatMethods = (methods) => {
    if (!Array.isArray(methods) || methods.length === 0) return '-';
    if (methods.includes('ALL')) return 'All methods';
    const labels = methods.map((method) => methodLookup[method] || method);
    if (labels.length <= 2) return labels.join(', ');
    return `${labels.slice(0, 2).join(', ')} +${labels.length - 2}`;
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (saving) return;
    if (!form.name.trim()) {
      notify('Server name is required.', 'warning');
      return;
    }
    const apiUrl = form.apiUrl.trim();
    if (!selectedMethods.length) {
      notify('Select at least one method.', 'warning');
      return;
    }
    const durationMax = Number(form.durationMax);
    if (!Number.isFinite(durationMax) || durationMax < 1) {
      notify('Duration max must be at least 1.', 'warning');
      return;
    }
    const engine = Number(form.engine);
    if (!Number.isFinite(engine) || engine < 1) {
      notify('Concurrent must be at least 1.', 'warning');
      return;
    }
    setSaving(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/servers`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name.trim(),
          apiUrl: form.apiUrl.trim(),
          durationMax,
          concurrent: engine,
          status: form.status,
          methods: selectedMethods,
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error;
        if (errorCode === 'invalid_name') {
          notify('Invalid server name.', 'warning');
        } else if (errorCode === 'invalid_url') {
          notify('Invalid API URL.', 'warning');
        } else if (errorCode === 'invalid_methods') {
          notify('Select at least one method.', 'warning');
        } else {
          notify('Failed to create server.', 'error');
        }
        return;
      }
      notify('Server created.', 'success');
      setForm({
        name: '',
        apiUrl: '',
        durationMax: '600',
        engine: '1',
        status: 'Online',
      });
      setSelectedMethods([]);
      loadServers();
    } catch (submitError) {
      notify('Failed to create server.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (serverId) => {
    if (!serverId) return;
    const confirmed = window.confirm('Delete this server?');
    if (!confirmed) return;
    try {
      const response = await fetch(
        `${API_BASE}/api/admin/servers/${serverId}`,
        { method: 'DELETE', credentials: 'include' }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        notify(data?.error || 'Failed to delete server.', 'error');
        return;
      }
      notify('Server deleted.', 'success');
      loadServers();
    } catch (deleteError) {
      notify('Failed to delete server.', 'error');
    }
  };

  return (
    <section className="page admin">
      <div className="panel-shell">
        <div className="panel-card panel-card--form server-form-card">
          <div className="panel-card__header">
            <h2>Create server</h2>
            <span className="panel-card__hint">Routing targets</span>
          </div>
          <form className="panel-form" onSubmit={handleSubmit}>
            <div className="plan-form-grid">
              <label className="field">
                <span>Name server</span>
                <input
                  className="input"
                  type="text"
                  value={form.name}
                  onChange={(event) =>
                    setForm((prev) => ({ ...prev, name: event.target.value }))
                  }
                  placeholder="Primary API"
                />
              </label>
              <label className="field">
                <span>API URL</span>
                <input
                  className="input"
                  type="text"
                  value={form.apiUrl}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      apiUrl: event.target.value,
                    }))
                  }
                  placeholder="https://api.example.com/run"
                />
              </label>
              <label className="field">
                <span>Duration max (sec)</span>
                <input
                  className="input"
                  type="number"
                  min="1"
                  step="1"
                  value={form.durationMax}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      durationMax: event.target.value,
                    }))
                  }
                />
              </label>
              <label className="field">
                <span>Concurrent</span>
                <input
                  className="input"
                  type="number"
                  min="1"
                  step="1"
                  value={form.engine}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      engine: event.target.value,
                    }))
                  }
                />
              </label>
              <div className="field">
                <span>Methods</span>
                <div
                  className={`panel-select api-methods ${methodMenuOpen ? 'is-open' : ''
                    }`}
                  ref={methodSelectRef}
                >
                  <button
                    type="button"
                    className="panel-select__trigger"
                    onClick={() => setMethodMenuOpen((open) => !open)}
                    aria-haspopup="listbox"
                    aria-expanded={methodMenuOpen}
                  >
                    <span className="panel-select__value">{methodSummary}</span>
                    <span className="panel-select__chevron" aria-hidden="true" />
                  </button>
                  {methodMenuOpen && (
                    <div className="panel-select__menu" role="listbox">
                      <button
                        type="button"
                        className={`panel-select__option api-select__option ${allMethodsSelected ? 'is-active' : ''
                          }`}
                        onClick={toggleAllMethods}
                      >
                        <span className="api-select__checkbox" />
                        <span>All methods</span>
                      </button>
                      {methodOptions.map((option) => {
                        const isActive = selectedMethods.includes(option.hash);
                        return (
                          <button
                            key={option.hash}
                            type="button"
                            className={`panel-select__option api-select__option ${isActive ? 'is-active' : ''
                              }`}
                            onClick={() => toggleMethod(option.hash)}
                          >
                            <span className="api-select__checkbox" />
                            <span>{option.display || option.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>
            <label className="field">
              <span>Status</span>
              <select
                className="input"
                value={form.status}
                onChange={(event) =>
                  setForm((prev) => ({
                    ...prev,
                    status: event.target.value,
                  }))
                }
              >
                <option value="Online">Online</option>
                <option value="Offline">Offline</option>
                <option value="Maintenance">Maintenance</option>
              </select>
            </label>
            <div className="admin-detail__actions">
              <button
                type="submit"
                className="button button--primary"
                disabled={saving}
              >
                {saving ? 'Saving...' : 'Create server'}
              </button>
              <button
                type="button"
                className="button button--ghost"
                onClick={() => {
                  setForm({
                    name: '',
                    apiUrl: '',
                    durationMax: '600',
                    engine: '1',
                    status: 'Online',
                  });
                  setSelectedMethods([]);
                }}
                disabled={saving}
              >
                Reset
              </button>
            </div>
          </form>
        </div>

        <div className="panel-card panel-card--table admin-card">
          <div className="panel-card__header">
            <div className="panel-card__header-row">
              <div>
                <h2>Servers</h2>
                <span className="panel-card__hint">Routing list</span>
              </div>
              <div className="admin-toolbar">
                <input
                  className="input admin-search"
                  type="search"
                  placeholder="Search server"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                />
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() => loadServers()}
                >
                  Refresh
                </button>
              </div>
            </div>
            <span className="admin-meta">
              {loading
                ? 'Loading servers...'
                : `${servers.length} server(s)`}{' '}
              {lastUpdated && !loading
                ? `- Updated ${formatDate(lastUpdated)}`
                : ''}
            </span>
          </div>
          <div className="panel-table admin-server-table">
            <div className="panel-table__row panel-table__row--head">
              <span>Name</span>
              <span>API URL</span>
              <span>Duration</span>
              <span>Concurrent</span>
              <span>Methods</span>
              <span>Status</span>
              <span>Action</span>
            </div>
            <div className="panel-table__body">
              {servers.length ? (
                servers.map((server) => (
                  <div key={server.id} className="panel-table__row">
                    <span data-label="Name">
                      <div className="admin-user">
                        <div className="admin-user__title">{server.name}</div>
                        <div className="admin-user__meta">
                          ID {server.id}
                        </div>
                      </div>
                    </span>
                    <span data-label="API URL">{server.apiUrl}</span>
                    <span data-label="Duration">
                      {server.durationMax || '-'}s
                    </span>
                    <span data-label="Concurrent">{server.engine}</span>
                    <span data-label="Methods">
                      {formatMethods(server.methods)}
                    </span>
                    <span data-label="Status">
                      <span
                        className={`status-pill status-pill--${server.status.toLowerCase()}`}
                      >
                        {server.status}
                      </span>
                    </span>
                    <span data-label="Action">
                      <div className="admin-plan__actions">
                        <button
                          type="button"
                          className="button button--ghost"
                          onClick={() =>
                            navigate(`/admin/servers/${server.id}`)
                          }
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          className="button button--danger"
                          onClick={() => handleDelete(server.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </span>
                  </div>
                ))
              ) : (
                <div className="panel-table__empty">
                  {loading
                    ? 'Loading...'
                    : error
                      ? 'Unable to load servers.'
                      : 'No servers found.'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function AdminServerDetail({ onNotify }) {
  const { serverId } = useParams();
  const navigate = useNavigate();
  const [server, setServer] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [methodOptions, setMethodOptions] = useState([]);
  const [methodsLoading, setMethodsLoading] = useState(false);
  const [selectedMethods, setSelectedMethods] = useState([]);
  const [methodMenuOpen, setMethodMenuOpen] = useState(false);
  const methodSelectRef = useRef(null);
  const [form, setForm] = useState({
    name: '',
    apiUrl: '',
    durationMax: '600',
    engine: '1',
    status: 'Online',
  });

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  useEffect(() => {
    if (!methodMenuOpen) return undefined;
    const handleClick = (event) => {
      if (!methodSelectRef.current?.contains(event.target)) {
        setMethodMenuOpen(false);
      }
    };
    const handleKey = (event) => {
      if (event.key === 'Escape') {
        setMethodMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleKey);
    };
  }, [methodMenuOpen]);

  const loadMethods = async () => {
    setMethodsLoading(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/methods`, {
        credentials: 'include',
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data?.error || 'Failed to load methods');
      }
      setMethodOptions(Array.isArray(data?.methods) ? data.methods : []);
    } catch (loadError) {
      setMethodOptions([]);
    } finally {
      setMethodsLoading(false);
    }
  };

  useEffect(() => {
    loadMethods();
  }, []);

  useEffect(() => {
    let active = true;
    const parsedId = Number(serverId);
    if (!Number.isInteger(parsedId)) {
      setError('Invalid server.');
      setLoading(false);
      return undefined;
    }
    const loadServer = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await fetch(
          `${API_BASE}/api/admin/servers/${parsedId}`,
          { credentials: 'include' }
        );
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          throw new Error(data?.error || 'Server not found');
        }
        const item = data?.server || null;
        if (!active) return;
        setServer(item);
        setForm({
          name: item?.name || '',
          apiUrl: item?.apiUrl || '',
          durationMax: String(item?.durationMax ?? '600'),
          engine: String(item?.engine ?? '1'),
          status: item?.status || 'Offline',
        });
        setSelectedMethods(
          Array.isArray(item?.methods) ? item.methods : []
        );
      } catch (loadError) {
        if (active) {
          setServer(null);
          setError('Server not found.');
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    };

    loadServer();
    return () => {
      active = false;
    };
  }, [serverId]);

  const selectedLabels = methodOptions
    .filter((method) => selectedMethods.includes(method.hash))
    .map((method) => method.display || method.name || method.hash);
  const allMethodsSelected = selectedMethods.includes('ALL');
  const methodSummary = (() => {
    if (methodsLoading) return 'Loading methods...';
    if (!methodOptions.length) return 'No methods';
    if (!selectedMethods.length) return 'Select method';
    if (allMethodsSelected) return 'All methods';
    if (selectedLabels.length <= 2) return selectedLabels.join(', ');
    return `${selectedLabels.slice(0, 2).join(', ')} +${selectedLabels.length - 2
      }`;
  })();

  const toggleAllMethods = () => {
    setSelectedMethods((prev) => (prev.includes('ALL') ? [] : ['ALL']));
  };

  const toggleMethod = (value) => {
    setSelectedMethods((prev) => {
      if (prev.includes('ALL')) {
        return [value];
      }
      if (prev.includes(value)) {
        return prev.filter((entry) => entry !== value);
      }
      return [...prev, value];
    });
  };

  const handleSave = async (event) => {
    event.preventDefault();
    if (saving || !server) return;
    if (!form.name.trim()) {
      notify('Server name is required.', 'warning');
      return;
    }
    const apiUrl = form.apiUrl.trim();
    if (!apiUrl) {
      notify('API URL is required.', 'warning');
      return;
    }
    if (!selectedMethods.length) {
      notify('Select at least one method.', 'warning');
      return;
    }
    const durationMax = Number(form.durationMax);
    if (!Number.isFinite(durationMax) || durationMax < 1) {
      notify('Duration max must be at least 1.', 'warning');
      return;
    }
    const engine = Number(form.engine);
    if (!Number.isFinite(engine) || engine < 1) {
      notify('Concurrent must be at least 1.', 'warning');
      return;
    }
    setSaving(true);
    try {
      const response = await fetch(
        `${API_BASE}/api/admin/servers/${server.id}`,
        {
          method: 'PUT',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: form.name.trim(),
            ...(apiUrl ? { apiUrl } : {}),
            durationMax,
            concurrent: engine,
            status: form.status,
            methods: selectedMethods,
          }),
        }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        notify(data?.error || 'Failed to save server.', 'error');
        return;
      }
      setServer(data?.server || server);
      notify('Server updated.', 'success');
    } catch (saveError) {
      notify('Failed to save server.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!server) return;
    const confirmed = window.confirm('Delete this server?');
    if (!confirmed) return;
    try {
      const response = await fetch(
        `${API_BASE}/api/admin/servers/${server.id}`,
        { method: 'DELETE', credentials: 'include' }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        notify(data?.error || 'Failed to delete server.', 'error');
        return;
      }
      notify('Server deleted.', 'success');
      navigate('/admin/servers');
    } catch (deleteError) {
      notify('Failed to delete server.', 'error');
    }
  };

  if (loading) {
    return (
      <section className="page admin">
        <div className="status-card">Loading server...</div>
      </section>
    );
  }

  if (!server) {
    return (
      <section className="page admin">
        <div className="status-card">
          {error || 'Server not found.'}
          <button
            type="button"
            className="button button--ghost admin-detail__back"
            onClick={() => navigate('/admin/servers')}
          >
            Back to servers
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="page admin">
      <div className="panel-shell">
        <div className="panel-card admin-detail server-detail">
          <div className="panel-card__header admin-detail__header">
            <div>
              <h2>Edit server</h2>
              <span className="panel-card__hint">ID {server.id}</span>
            </div>
            <button
              type="button"
              className="button button--ghost"
              onClick={() => navigate('/admin/servers')}
            >
              Back to servers
            </button>
          </div>
          <div className="admin-detail__body">
            <div className="admin-user">
              <div className="admin-user__title">{server.name}</div>
              <div className="admin-user__meta">{server.apiUrl}</div>
            </div>
            <form className="panel-form" onSubmit={handleSave}>
              <div className="plan-form-grid">
                <label className="field">
                  <span>Name server</span>
                  <input
                    className="input"
                    type="text"
                    value={form.name}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        name: event.target.value,
                      }))
                    }
                  />
                </label>
                <label className="field">
                  <span>API URL</span>
                  <input
                    className="input"
                    type="text"
                    value={form.apiUrl}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        apiUrl: event.target.value,
                      }))
                    }
                    placeholder="https://api.example.com/run"
                  />
                </label>
                <label className="field">
                  <span>Duration max (sec)</span>
                  <input
                    className="input"
                    type="number"
                    min="1"
                    step="1"
                    value={form.durationMax}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        durationMax: event.target.value,
                      }))
                    }
                  />
                </label>
                <label className="field">
                  <span>Concurrent</span>
                  <input
                    className="input"
                    type="number"
                    min="1"
                    step="1"
                    value={form.engine}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        engine: event.target.value,
                      }))
                    }
                  />
                </label>
                <label className="field">
                  <span>Status</span>
                  <select
                    className="input"
                    value={form.status}
                    onChange={(event) =>
                      setForm((prev) => ({
                        ...prev,
                        status: event.target.value,
                      }))
                    }
                  >
                    <option value="Online">Online</option>
                    <option value="Offline">Offline</option>
                    <option value="Maintenance">Maintenance</option>
                  </select>
                </label>
              </div>
              <div className="field">
                <span>Methods</span>
                <div
                  className={`panel-select api-methods ${methodMenuOpen ? 'is-open' : ''
                    }`}
                  ref={methodSelectRef}
                >
                  <button
                    type="button"
                    className="panel-select__trigger"
                    onClick={() => setMethodMenuOpen((open) => !open)}
                    aria-haspopup="listbox"
                    aria-expanded={methodMenuOpen}
                  >
                    <span className="panel-select__value">{methodSummary}</span>
                    <span className="panel-select__chevron" aria-hidden="true" />
                  </button>
                  {methodMenuOpen && (
                    <div className="panel-select__menu" role="listbox">
                      <button
                        type="button"
                        className={`panel-select__option api-select__option ${allMethodsSelected ? 'is-active' : ''
                          }`}
                        onClick={toggleAllMethods}
                      >
                        <span className="api-select__checkbox" />
                        <span>All methods</span>
                      </button>
                      {methodOptions.map((option) => {
                        const isActive = selectedMethods.includes(
                          option.hash
                        );
                        return (
                          <button
                            key={option.hash}
                            type="button"
                            className={`panel-select__option api-select__option ${isActive ? 'is-active' : ''
                              }`}
                            onClick={() => toggleMethod(option.hash)}
                          >
                            <span className="api-select__checkbox" />
                            <span>{option.display || option.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
              <div className="admin-detail__actions">
                <button
                  type="submit"
                  className="button button--primary"
                  disabled={saving}
                >
                  {saving ? 'Saving...' : 'Save changes'}
                </button>
                <button
                  type="button"
                  className="button button--danger"
                  onClick={handleDelete}
                  disabled={saving}
                >
                  Delete server
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function AdminNews({ onNotify }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);
  const [query, setQuery] = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    title: '',
    message: '',
    author: '',
  });

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const formatDate = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('id-ID');
  };

  const loadNews = async (search = query) => {
    setLoading(true);
    setError(false);
    try {
      const response = await fetch(
        `${API_BASE}/api/admin/news?q=${encodeURIComponent(search)}`,
        { credentials: 'include' }
      );
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        throw new Error(data?.error || 'Failed to load news');
      }
      setItems(Array.isArray(data?.items) ? data.items : []);
      setLastUpdated(new Date().toISOString());
    } catch (loadError) {
      setItems([]);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadNews();
  }, []);

  useEffect(() => {
    const timer = window.setTimeout(() => {
      loadNews(query);
    }, 400);
    return () => window.clearTimeout(timer);
  }, [query]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (saving) return;
    if (!form.title.trim() || !form.message.trim()) {
      notify('Title and message are required.', 'warning');
      return;
    }
    setSaving(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/news`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: form.title.trim(),
          message: form.message.trim(),
          author: form.author.trim(),
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error;
        if (errorCode === 'invalid_title') {
          notify('Invalid title.', 'warning');
        } else if (errorCode === 'invalid_message') {
          notify('Invalid message.', 'warning');
        } else {
          notify('Failed to create news.', 'error');
        }
        return;
      }
      notify('News published.', 'success');
      setForm((prev) => ({
        ...prev,
        title: '',
        message: '',
      }));
      loadNews();
    } catch (submitError) {
      notify('Failed to create news.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (newsId) => {
    if (!newsId) return;
    const confirmed = window.confirm('Delete this news item?');
    if (!confirmed) return;
    try {
      const response = await fetch(`${API_BASE}/api/admin/news/${newsId}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        notify(data?.error || 'Failed to delete news.', 'error');
        return;
      }
      notify('News deleted.', 'success');
      loadNews();
    } catch (deleteError) {
      notify('Failed to delete news.', 'error');
    }
  };

  return (
    <section className="page admin">
      <div className="panel-shell">
        <div className="panel-card panel-card--form news-form-card">
          <div className="panel-card__header">
            <h2>Create news</h2>
            <span className="panel-card__hint">Publish update</span>
          </div>
          <form className="panel-form news-form" onSubmit={handleSubmit}>
            <div className="news-form-grid">
              <label className="field">
                <span>Title</span>
                <input
                  className="input"
                  type="text"
                  value={form.title}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      title: event.target.value,
                    }))
                  }
                  placeholder="Maintenance window"
                />
              </label>
              <label className="field">
                <span>Author</span>
                <input
                  className="input"
                  type="text"
                  value={form.author}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      author: event.target.value,
                    }))
                  }
                  placeholder="Optional"
                />
                <span className="field-hint">
                  Default: admin username.
                </span>
              </label>
              <label className="field field--full">
                <span>Message</span>
                <textarea
                  className="input news-textarea"
                  rows="4"
                  value={form.message}
                  onChange={(event) =>
                    setForm((prev) => ({
                      ...prev,
                      message: event.target.value,
                    }))
                  }
                  placeholder="Short update that appears on the home page."
                />
              </label>
            </div>
            <div className="admin-detail__actions">
              <button
                type="submit"
                className="button button--primary"
                disabled={saving}
              >
                {saving ? 'Publishing...' : 'Publish news'}
              </button>
              <button
                type="button"
                className="button button--ghost"
                onClick={() =>
                  setForm((prev) => ({
                    ...prev,
                    title: '',
                    message: '',
                  }))
                }
                disabled={saving}
              >
                Reset
              </button>
            </div>
          </form>
        </div>

        <div className="panel-card panel-card--table admin-card">
          <div className="panel-card__header">
            <div className="panel-card__header-row">
              <div>
                <h2>News</h2>
                <span className="panel-card__hint">Latest updates</span>
              </div>
              <div className="admin-toolbar">
                <input
                  className="input admin-search"
                  type="search"
                  placeholder="Search news"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                />
                <button
                  type="button"
                  className="button button--ghost"
                  onClick={() => loadNews()}
                >
                  Refresh
                </button>
              </div>
            </div>
            <span className="admin-meta">
              {loading ? 'Loading news...' : `${items.length} item(s)`}{' '}
              {lastUpdated && !loading
                ? `- Updated ${formatDate(lastUpdated)}`
                : ''}
            </span>
          </div>
          <div className="panel-table admin-news-table">
            <div className="panel-table__row panel-table__row--head">
              <span>Title</span>
              <span>Message</span>
              <span>Author</span>
              <span>Created</span>
              <span>Action</span>
            </div>
            <div className="panel-table__body">
              {items.length ? (
                items.map((item) => (
                  <div key={item.id} className="panel-table__row">
                    <span data-label="Title">
                      <div className="admin-user">
                        <div className="admin-user__title">
                          {item.title}
                        </div>
                        <div className="admin-user__meta">ID {item.id}</div>
                      </div>
                    </span>
                    <span data-label="Message" className="admin-news__message">
                      {item.message}
                    </span>
                    <span data-label="Author">{item.author}</span>
                    <span data-label="Created">
                      {formatDate(item.createdAt)}
                    </span>
                    <span data-label="Action">
                      <div className="admin-plan__actions">
                        <button
                          type="button"
                          className="button button--danger"
                          onClick={() => handleDelete(item.id)}
                        >
                          Delete
                        </button>
                      </div>
                    </span>
                  </div>
                ))
              ) : (
                <div className="panel-table__empty">
                  {loading
                    ? 'Loading...'
                    : error
                      ? 'Unable to load news.'
                      : 'No news found.'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function AdminPlanDetail({ onNotify }) {
  const { planId } = useParams();
  const navigate = useNavigate();
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({
    name: '',
    display: '',
    time: '600',
    conc: '1',
    expired: '0',
    stock: '0',
    price: '0',
    cooldown: '0',
    access: 'Basic',
    apiAccess: false,
    private: false,
  });

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const formatDate = (value) => {
    if (!value) return '-';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return date.toLocaleString('id-ID');
  };

  const formatCurrency = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount)) return '-';
    return `Rp ${new Intl.NumberFormat('id-ID').format(Math.trunc(amount))}`;
  };

  const formatDays = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return 'No expiry';
    return `${amount}d`;
  };

  const formatTime = (value) => {
    const amount = Number(value);
    if (!Number.isFinite(amount) || amount <= 0) return '-';
    return `${amount}s`;
  };

  const previewLabel =
    form.display.trim() ||
    form.name.trim() ||
    plan?.display ||
    plan?.name ||
    'Plan';
  const previewAccess = form.access || plan?.access || 'Basic';
  const previewTime = formatTime(Number(form.time) || 0);
  const previewConc = Number(form.conc) || 1;
  const previewExpired = formatDays(Number(form.expired) || 0);
  const previewPrice = formatCurrency(Number(form.price) || 0);
  const previewCooldown = formatTime(Number(form.cooldown) || 0);

  useEffect(() => {
    let active = true;
    const parsedId = Number(planId);
    if (!Number.isInteger(parsedId)) {
      setError('Invalid plan.');
      setLoading(false);
      return () => { };
    }

    const loadPlan = async () => {
      setLoading(true);
      setError('');
      try {
        const response = await fetch(
          `${API_BASE}/api/admin/plans/${parsedId}`,
          { credentials: 'include' }
        );
        const data = await response.json().catch(() => ({}));
        if (!response.ok) {
          throw new Error(data?.error || 'Plan not found');
        }
        if (active) {
          const nextPlan = data?.plan || null;
          setPlan(nextPlan);
          setForm({
            name: nextPlan?.name || '',
            display: nextPlan?.display || '',
            time: String(nextPlan?.time ?? '600'),
            conc: String(nextPlan?.conc ?? '1'),
            expired: String(nextPlan?.expired ?? '0'),
            stock: String(nextPlan?.stock ?? '0'),
            price: String(nextPlan?.price ?? '0'),
            cooldown: String(nextPlan?.cooldown ?? '0'),
            access: nextPlan?.access || 'Basic',
            apiAccess: Boolean(nextPlan?.apiAccess),
            private: Boolean(nextPlan?.private),
          });
        }
      } catch (loadError) {
        if (active) {
          setPlan(null);
          setError('Plan not found.');
        }
      } finally {
        if (active) setLoading(false);
      }
    };

    loadPlan();

    return () => {
      active = false;
    };
  }, [planId]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!plan || saving) return;
    if (!form.name.trim() || !form.display.trim()) {
      notify('Name and display are required.', 'warning');
      return;
    }
    setSaving(true);
    try {
      const response = await fetch(`${API_BASE}/api/admin/plans/${plan.id}`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name.trim(),
          display: form.display.trim(),
          time: Number(form.time),
          conc: Number(form.conc),
          expired: Number(form.expired),
          stock: Number(form.stock),
          price: Number(form.price),
          cooldown: Number(form.cooldown),
          access: form.access,
          apiAccess: form.apiAccess,
          private: form.private,
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error;
        if (errorCode === 'plan_exists') {
          notify('Plan name already exists.', 'warning');
        } else if (errorCode === 'default_name_locked') {
          notify('Default plan name is locked.', 'warning');
        } else {
          notify('Failed to update plan.', 'error');
        }
        return;
      }
      const updated = data?.plan || plan;
      setPlan(updated);
      notify('Plan updated.', 'success');
    } catch (updateError) {
      notify('Failed to update plan.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!plan) return;
    const confirmed = window.confirm('Delete this plan?');
    if (!confirmed) return;
    try {
      const response = await fetch(`${API_BASE}/api/admin/plans/${plan.id}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) {
        const errorCode = data?.error;
        if (errorCode === 'cannot_delete_default') {
          notify('Default plan cannot be deleted.', 'warning');
        } else if (errorCode === 'plan_in_use') {
          notify('Plan is assigned to users.', 'warning');
        } else {
          notify('Failed to delete plan.', 'error');
        }
        return;
      }
      notify('Plan deleted.', 'success');
      navigate('/admin/plans');
    } catch (deleteError) {
      notify('Failed to delete plan.', 'error');
    }
  };

  if (loading) {
    return (
      <section className="page admin">
        <div className="status-card">Loading plan...</div>
      </section>
    );
  }

  if (error || !plan) {
    return (
      <section className="page admin">
        <div className="status-card">
          {error || 'Plan not found.'}
          <button
            type="button"
            className="button button--ghost admin-detail__back"
            onClick={() => navigate('/admin/plans')}
          >
            Back to plans
          </button>
        </div>
      </section>
    );
  }

  return (
    <section className="page admin">
      <div className="panel-shell">
        <div className="panel-card admin-detail plan-detail">
          <div className="panel-card__header admin-detail__header">
            <div>
              <h2>Edit plan</h2>
              <span className="panel-card__hint">ID {plan.id}</span>
            </div>
            <button
              type="button"
              className="button button--ghost"
              onClick={() => navigate('/admin/plans')}
            >
              Back to plans
            </button>
          </div>
          <div className="admin-detail__body">
            <div className="admin-user">
              <div className="admin-user__title">
                {plan.display || plan.name}
              </div>
              <div className="admin-user__meta">
                Created {formatDate(plan.createdAt)}
              </div>
            </div>
            <form className="panel-form plan-form" onSubmit={handleSubmit}>
              <div className="plan-form__section">
                <div className="plan-form__section-header">
                  <span className="plan-form__section-title">Basics</span>
                  <span className="plan-form__section-hint">
                    Label and access level
                  </span>
                </div>
                <div className="plan-form-grid">
                  <label className="field">
                    <span>Name</span>
                    <input
                      className="input"
                      type="text"
                      value={form.name}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          name: event.target.value,
                        }))
                      }
                    />
                    <span className="field-hint">
                      Unique id, keep simple.
                    </span>
                  </label>
                  <label className="field">
                    <span>Display</span>
                    <input
                      className="input"
                      type="text"
                      value={form.display}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          display: event.target.value,
                        }))
                      }
                    />
                    <span className="field-hint">Shown in UI.</span>
                  </label>
                  <label className="field">
                    <span>Access</span>
                    <select
                      className="input"
                      value={form.access}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          access: event.target.value,
                        }))
                      }
                    >
                      <option value="Basic">Basic</option>
                      <option value="Premium">Premium</option>
                    </select>
                  </label>
                </div>
              </div>

              <div className="plan-form__section">
                <div className="plan-form__section-header">
                  <span className="plan-form__section-title">Limits</span>
                  <span className="plan-form__section-hint">
                    Runtime and concurrency
                  </span>
                </div>
                <div className="plan-form-grid">
                  <label className="field">
                    <span>Time (seconds)</span>
                    <input
                      className="input"
                      type="number"
                      min="0"
                      step="1"
                      value={form.time}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          time: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="field">
                    <span>Conc</span>
                    <input
                      className="input"
                      type="number"
                      min="1"
                      step="1"
                      value={form.conc}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          conc: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="field">
                    <span>Expired (days)</span>
                    <input
                      className="input"
                      type="number"
                      min="0"
                      step="1"
                      value={form.expired}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          expired: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="field">
                    <span>Cooldown (seconds)</span>
                    <input
                      className="input"
                      type="number"
                      min="0"
                      step="1"
                      value={form.cooldown}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          cooldown: event.target.value,
                        }))
                      }
                    />
                  </label>
                </div>
              </div>

              <div className="plan-form__section">
                <div className="plan-form__section-header">
                  <span className="plan-form__section-title">Commerce</span>
                  <span className="plan-form__section-hint">
                    Stock and pricing
                  </span>
                </div>
                <div className="plan-form-grid">
                  <label className="field">
                    <span>Stock</span>
                    <input
                      className="input"
                      type="number"
                      min="0"
                      step="1"
                      value={form.stock}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          stock: event.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="field">
                    <span>Price</span>
                    <input
                      className="input"
                      type="number"
                      min="0"
                      step="1"
                      value={form.price}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          price: event.target.value,
                        }))
                      }
                    />
                  </label>
                </div>
              </div>

              <div className="plan-form__section plan-form__section--flags">
                <div className="plan-form__section-header">
                  <span className="plan-form__section-title">Visibility</span>
                  <span className="plan-form__section-hint">
                    Access control flags
                  </span>
                </div>
                <div className="plan-toggle-grid">
                  <label className="plan-toggle">
                    <span className="plan-toggle__text">
                      <span>API access</span>
                      <span className="plan-toggle__hint">
                        Enable API Manager
                      </span>
                    </span>
                    <input
                      type="checkbox"
                      checked={form.apiAccess}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          apiAccess: event.target.checked,
                        }))
                      }
                    />
                  </label>
                  <label className="plan-toggle">
                    <span className="plan-toggle__text">
                      <span>Private</span>
                      <span className="plan-toggle__hint">
                        Hide from client list
                      </span>
                    </span>
                    <input
                      type="checkbox"
                      checked={form.private}
                      onChange={(event) =>
                        setForm((prev) => ({
                          ...prev,
                          private: event.target.checked,
                        }))
                      }
                    />
                  </label>
                </div>
              </div>

              <div className="plan-form__footer">
                <div className="plan-form__summary">
                  <span className="plan-form__summary-title">Preview</span>
                  <span className="plan-form__summary-value">
                    {previewLabel} · {previewAccess} · {previewTime} · Conc{' '}
                    {previewConc} · {previewExpired} · {previewPrice} · CD{' '}
                    {previewCooldown}
                  </span>
                </div>
                <div className="admin-detail__actions">
                  <button
                    type="submit"
                    className="button button--primary"
                    disabled={saving}
                  >
                    {saving ? 'Saving...' : 'Save changes'}
                  </button>
                  <button
                    type="button"
                    className="button button--danger"
                    onClick={() => handleDelete()}
                    disabled={saving}
                  >
                    Delete plan
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AppShell />
    </BrowserRouter>
  );
}

export default App;
