import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

const API_BASE = import.meta.env.VITE_API_BASE || '';

const errorMessages = {
  invalid_username: 'Username must be 3-32 characters, letters/numbers/underscore.',
  invalid_password: 'Password must be 8-72 characters.',
  invalid_credentials: 'Incorrect username or password.',
  rate_limited: 'Too many attempts. Please wait and try again.',
};

function Login({ onAuth, onNotify }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    username: '',
    password: '',
  });
  const [loading, setLoading] = useState(false);

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const updateField = (field) => (event) => {
    setForm((prev) => ({ ...prev, [field]: event.target.value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (loading) return;
    setLoading(true);

    try {
      const response = await fetch(`${API_BASE}/api/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          username: form.username,
          password: form.password,
        }),
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        const message = errorMessages[data?.error] || 'Login failed.';
        notify(message, 'error');
        return;
      }

      onAuth?.(data.user);
      notify('Login success', 'success');
      navigate('/home');
    } catch (error) {
      notify('Network error. Please try again.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <div className="auth-card">
        <div className="auth-card__header">
          <h2>Login</h2>
        </div>
        <form className="auth-form" onSubmit={handleSubmit}>
          <label className="field">
            <span>Username</span>
            <input
              className="input"
              type="text"
              value={form.username}
              onChange={updateField('username')}
              autoComplete="username"
              required
            />
          </label>
          <label className="field">
            <span>Password</span>
            <input
              className="input"
              type="password"
              value={form.password}
              onChange={updateField('password')}
              autoComplete="current-password"
              required
            />
          </label>
          <button className="button button--primary" type="submit">
            {loading ? 'Signing in...' : 'Login'}
          </button>
        </form>
        <div className="auth-card__footer">
          <span>Need an account?</span>
          <Link to="/register">Register</Link>
        </div>
      </div>
    </div>
  );
}

export default Login;
