import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Captcha from '../components/Captcha.jsx';

const API_BASE = import.meta.env.VITE_API_BASE || '';

const errorMessages = {
  invalid_username: 'Username must be 3-32 characters, letters/numbers/underscore.',
  invalid_password: 'Password must be 8-72 characters.',
  password_mismatch: 'Passwords do not match.',
  invalid_captcha: 'Captcha incorrect or expired. Please try again.',
  user_exists: 'This username is already taken.',
  rate_limited: 'Too many attempts. Please wait and try again.',
};

const getPasswordStrength = (value) => {
  const password = value || '';
  const checks = [
    password.length >= 8,
    /[a-z]/.test(password) && /[A-Z]/.test(password),
    /\d/.test(password),
    /[^A-Za-z0-9]/.test(password),
  ];
  const score = checks.filter(Boolean).length;
  const percent = Math.round((score / checks.length) * 100);

  if (!password) {
    return { label: 'Enter password', percent: 0, tone: 'empty' };
  }
  if (score <= 1) {
    return { label: 'Weak', percent, tone: 'weak' };
  }
  if (score === 2) {
    return { label: 'Fair', percent, tone: 'fair' };
  }
  if (score === 3) {
    return { label: 'Good', percent, tone: 'good' };
  }
  return { label: 'Strong', percent, tone: 'strong' };
};

function Register({ onAuth, onNotify }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    username: '',
    password: '',
    confirmPassword: '',
    captcha: '',
  });
  const [loading, setLoading] = useState(false);
  const [captchaSeed, setCaptchaSeed] = useState(0);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const strength = getPasswordStrength(form.password);

  const notify = (message, tone = 'info') => {
    if (onNotify) {
      onNotify(message, tone);
    } else {
      alert(message);
    }
  };

  const EyeIcon = ({ hidden }) => (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
      <path
        d="M1.5 12s4.5-7 10.5-7 10.5 7 10.5 7-4.5 7-10.5 7S1.5 12 1.5 12Z"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle
        cx="12"
        cy="12"
        r="3.5"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {hidden && (
        <path
          d="M4 4l16 16"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      )}
    </svg>
  );

  const updateField = (field) => (event) => {
    setForm((prev) => ({ ...prev, [field]: event.target.value }));
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (loading) return;

    if (form.password !== form.confirmPassword) {
      notify('Passwords do not match.', 'error');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`${API_BASE}/api/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          username: form.username,
          password: form.password,
          confirmPassword: form.confirmPassword,
          captcha: form.captcha,
        }),
      });

      const data = await response.json().catch(() => ({}));

      if (!response.ok) {
        const message = errorMessages[data?.error] || 'Registration failed.';
        notify(message, 'error');
        if (data?.error === 'invalid_captcha') {
          setCaptchaSeed((seed) => seed + 1);
          setForm((prev) => ({ ...prev, captcha: '' }));
        }
        return;
      }

      onAuth?.(data.user);
      notify('Register success', 'success');
      navigate('/home');
    } catch (error) {
      notify('Network error. Please try again.', 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <div className="auth-card">
        <div className="auth-card__header">
          <h2>Register</h2>
        </div>
        <form className="auth-form" onSubmit={handleSubmit}>
          <label className="field">
            <span>Username</span>
            <input
              className="input"
              type="text"
              value={form.username}
              onChange={updateField('username')}
              autoComplete="username"
              required
            />
          </label>
          <label className="field">
            <span>Password</span>
            <div className="input-group">
              <input
                className="input"
                type={showPassword ? 'text' : 'password'}
                value={form.password}
                onChange={updateField('password')}
                autoComplete="new-password"
                required
              />
              <button
                type="button"
                className="input-toggle"
                onClick={() => setShowPassword((prev) => !prev)}
                aria-pressed={showPassword}
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                <EyeIcon hidden={showPassword} />
                <span className="sr-only">
                  {showPassword ? 'Hide password' : 'Show password'}
                </span>
              </button>
            </div>
            <div
              className="strength"
              data-tone={strength.tone}
              style={{ '--strength': `${strength.percent}%` }}
            >
              <div className="strength__row">
                <span>Password strength</span>
                <span className="strength__label">{strength.label}</span>
              </div>
              <div className="strength__bar" aria-hidden="true" />
              <span className="field-hint">
                Use 8+ characters with a mix of cases, numbers, and symbols.
              </span>
            </div>
          </label>
          <label className="field">
            <span>Retype Password</span>
            <div className="input-group">
              <input
                className="input"
                type={showConfirm ? 'text' : 'password'}
                value={form.confirmPassword}
                onChange={updateField('confirmPassword')}
                autoComplete="new-password"
                required
              />
              <button
                type="button"
                className="input-toggle"
                onClick={() => setShowConfirm((prev) => !prev)}
                aria-pressed={showConfirm}
                aria-label={showConfirm ? 'Hide password' : 'Show password'}
              >
                <EyeIcon hidden={showConfirm} />
                <span className="sr-only">
                  {showConfirm ? 'Hide password' : 'Show password'}
                </span>
              </button>
            </div>
          </label>
          <Captcha
            value={form.captcha}
            onChange={(value) => setForm((prev) => ({ ...prev, captcha: value }))}
            refreshToken={captchaSeed}
            onNotify={onNotify}
          />
          <button className="button button--primary" type="submit">
            {loading ? 'Creating...' : 'Register'}
          </button>
        </form>
        <div className="auth-card__footer">
          <span>Already registered?</span>
          <Link to="/login">Login</Link>
        </div>
      </div>
    </div>
  );
}

export default Register;
