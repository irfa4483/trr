import { useEffect, useState } from 'react';

const API_BASE = import.meta.env.VITE_API_BASE || '';

const RefreshIcon = ({ spinning }) => (
  <svg
    className={`captcha__refresh-icon ${spinning ? 'is-spinning' : ''}`}
    viewBox="0 0 24 24"
    width="18"
    height="18"
    aria-hidden="true"
  >
    <path
      d="M20 12a8 8 0 1 1-2.3-5.7"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <polyline
      points="20 4 20 9 15 9"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

function Captcha({ value, onChange, refreshToken = 0, onNotify, hasError }) {
  const [image, setImage] = useState('');
  const [loading, setLoading] = useState(true);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [error, setError] = useState('');

  const loadCaptcha = async () => {
    setLoading(true);
    setError('');
    setImageLoaded(false);
    try {
      const response = await fetch(`${API_BASE}/api/captcha`, {
        credentials: 'include',
      });
      const data = await response.json();
      if (!response.ok || !data?.image) {
        throw new Error(data?.error || 'captcha_failed');
      }
      setImage(data.image);
    } catch (err) {
      setError('Unable to load captcha.');
      setImage('');
      onNotify?.('Captcha failed to load', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCaptcha();
  }, [refreshToken]);

  const isLoading = loading || !imageLoaded;

  return (
    <div className={`captcha ${hasError ? 'captcha--error' : ''}`}>
      <div className="captcha__row">
        <div
          className={`captcha__image ${
            isLoading ? 'is-loading' : 'is-loaded'
          }`}
        >
          {image ? (
            <img
              src={image}
              alt="Captcha"
              onLoad={() => setImageLoaded(true)}
            />
          ) : (
            <span className="captcha__placeholder">No image</span>
          )}
          {isLoading && <div className="captcha__loader">Loading</div>}
        </div>
        <input
          type="text"
          className={`input captcha__input ${
            hasError ? 'input--error' : ''
          }`}
          value={value}
          onChange={(event) => onChange(event.target.value.toUpperCase())}
          placeholder="A-Z / 0-9"
          autoComplete="off"
          required
        />
        <button
          type="button"
          className={`captcha__refresh ${loading ? 'is-loading' : ''}`}
          onClick={() => {
            loadCaptcha();
            onChange('');
            onNotify?.('Captcha refreshed', 'info');
          }}
          aria-label="Refresh captcha"
          aria-busy={loading}
          disabled={loading}
        >
          <RefreshIcon spinning={loading} />
        </button>
      </div>
      {error && <div className="field-hint field-hint--error">{error}</div>}
    </div>
  );
}

export default Captcha;
